from setuptools import find_packages
from distutils.core import setup
import os
import json

load = open("parameters.json")
f_read = load.read()
params = json.loads(f_read)

requirements = params['install_requires']

if os.path.exists('requirements.txt'):
    requirements = [line.rstrip('\n') for line in open('requirements.txt') if 'pytest' not in line and 'coverage' not in line]

setup(
   include_package_data=True,
   name=params['name'],
   version=params['version'],
   description=params['description'],
   install_requires= requirements,
   url= params["url"],
   packages=find_packages(exclude=["*tests.*", "*tests"]),
   classifiers=[
       "Programming Language :: Python :: 3.7",
       "License :: OSI Approved :: MIT License",
       "Operating System :: OS Independent",
   ],
   python_requires='>=3.7',
   package_dir={params['src']: params['src']},
)
