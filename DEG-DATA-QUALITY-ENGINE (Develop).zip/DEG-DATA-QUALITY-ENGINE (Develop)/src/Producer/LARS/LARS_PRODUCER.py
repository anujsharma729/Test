# Databricks notebook source
# MAGIC  %run ../../utils

# COMMAND ----------

# MAGIC %run ../../rules

# COMMAND ----------

# MAGIC %run ./CREATE_LARS_PRODUCER

# COMMAND ----------

lars_df = lars_df.filter((f.col('Retired Producer') != 1) | f.col('Retired Producer').isNull())
lars_df = lars_df.withColumn('Birth Date', f.date_format((f.col('Birth Date')),"yyyy-MM-dd"))

# COMMAND ----------

completeness_check_columns = [
    'NPN', 'SSN', 'First Name', 'Last Name', 'Birth Date',
    'Business Address: Line 1', 'Business Address: City', 'Business Address: State', 'Business Address: Zip Code',
    'Home Address: Line 1', 'Home Address: City', 'Home Address: State', 'Home Address: Zip Code', 'Phone Number',
    'Email Address'
]
for column in completeness_check_columns:
        lars_df = completeness_check(lars_df, column)

lars_df = uniqueness_check(lars_df, 'SSN')
lars_df = uniqueness_check(lars_df, 'NPN')
lars_df = uniqueness_check(lars_df, 'Email Address')

lars_df = conformity_postalcode_us(lars_df, 'Business Address: Zip Code')
lars_df = conformity_postalcode_us(lars_df, 'Home Address: Zip Code')
lars_df = conformity_ssn(lars_df, 'SSN')
lars_df = conformity_npn(lars_df, 'NPN')
lars_df = conformity_email(lars_df, 'Email Address')
lars_df = conformity_phone(lars_df, 'Phone Number')
# lars_df = conformity_birthdate(lars_df, 'Birth Date')


lars_df = accuracy_ssn(lars_df, 'SSN')
lars_df = accuracy_npn(lars_df, 'NPN')
lars_df = accuracy_phone(lars_df, 'Phone Number')


adult_cutoff = f.add_months(f.current_date(), -12 * 18)
min_birth_date = f.to_date(f.lit('1900-01-01'))

lars_df = lars_df.withColumn(
    'Accuracy: Birth Date',
    f.when(f.col('Birth Date').isNull(), 'fail: must contain non null value')
     .when(f.col('Birth Date') < min_birth_date, 'fail: must be after 1900-01-01')
     .when(f.col('Birth Date') <= adult_cutoff, 'pass: age must be over 18')
     .otherwise('fail: age must be over 18')
)


lars_df = lars_df.withColumn(
    'Retired Producer check',
    f.when(
        f.col('Email Address').isNull() &
        f.col('NPN').isNull() &
        f.col('Phone Number').isNull(),
        'Retired Producer'
    )
)


# COMMAND ----------

tparty_sel = lars_df.select('Completeness: NPN', 'Completeness: SSN', 'Uniqueness: NPN', 'Uniqueness: SSN', 'Conformity: NPN', 'Conformity: SSN','Accuracy: NPN', 'Accuracy: SSN')

tpers_sel = lars_df.select('Completeness: First Name', 'Completeness: Last Name', 'Completeness: Birth Date', 'Accuracy: Birth Date', 'Retired Producer check')

tphne_sel = lars_df.select('Completeness: Phone Number', 'Conformity: Phone Number', 'Accuracy: Phone Number')

telctr_addr_sel = lars_df.select('Completeness: Email Address', 'Uniqueness: Email Address', 'Conformity: Email Address')

tphysc_addr_sel = lars_df.select(
    # Business
    'Completeness: Business Address: Line 1',
    'Completeness: Business Address: City',
    'Completeness: Business Address: State',
    'Completeness: Business Address: Zip Code',
    'Conformity: Business Address: Zip Code',
    # Home
    'Completeness: Home Address: Line 1',
    'Completeness: Home Address: City',
    'Completeness: Home Address: State',
    'Completeness: Home Address: Zip Code',
    'Conformity: Home Address: Zip Code'
)

# COMMAND ----------


from pyspark.sql import Row

threshold_scores = {
    'Birth Date': [
        {'Rule':'must contain non null value', 'Threshold': 0.98},
        {'Rule':'age must be over 18', 'Threshold': 0.99}
    ],
    'Business Address: City': [{'Rule': 'must contain non null value', 'Threshold': 1.0}],
    'Business Address: Line 1': [{'Rule': 'must contain non null value', 'Threshold': 1.0}],
    'Business Address: State': [{'Rule': 'must contain non null value', 'Threshold': 1.0}],
    'Business Address: Zip Code': [
        {'Rule': 'must contain non null value', 'Threshold': 1.0},
        {'Rule': 'must adhere to US postal code format', 'Threshold': 1.0}
    ],
    'Email Address': [
        {'Rule': 'must contain non null value', 'Threshold': 0.85},
        {'Rule': 'must contain unique value', 'Threshold': 0.85},
        {'Rule': 'must adhere to email format (example@gmail.com)', 'Threshold': 0.99}
    ],
    'First Name': [{'Rule': 'must contain non null value', 'Threshold': 1.0}],
    'Home Address: City': [{'Rule': 'must contain non null value', 'Threshold': 1.0}],
    'Home Address: Line 1': [{'Rule': 'must contain non null value', 'Threshold': 1.0}],
    'Home Address: State': [{'Rule': 'must contain non null value', 'Threshold': 1.0}],
    'Home Address: Zip Code': [
        {'Rule': 'must contain non null value', 'Threshold': 1.0},
        {'Rule': 'must adhere to US postal code format', 'Threshold': 1.0}
    ],
    'Last Name': [{'Rule': 'must contain non null value', 'Threshold': 1.0}],
    'NPN': [
        {'Rule': 'must contain non null value', 'Threshold': 1.0},
        {'Rule': 'must contain unique value', 'Threshold': 1.0},
        {'Rule': 'must be a 4-10 digit number', 'Threshold': 1.0},
        {'Rule': 'must not start with zero and contain atleast two digits', 'Threshold': 1.0}
    ],
    'Phone number': [
        {'Rule': 'must contain non null value', 'Threshold': 0.99},
        {'Rule': 'must contain 10 digit phone number', 'Threshold': 0.99},
        {'Rule': 'must not contain repeated number', 'Threshold': 0.95},
        # {'Rule': 'first 3 digits do not match numbers listed and 10 digits', 'Threshold': 0.90}
    ],
    'SSN': [
        {'Rule': 'must contain non null value', 'Threshold': 1.0},
        {'Rule': 'must contain unique value', 'Threshold': 1.0},
        {'Rule': 'must contain 9 digit value', 'Threshold': 1.0},
        {'Rule': 'must conform to irs rules', 'Threshold': 1.0}
    ],
}



# COMMAND ----------


column_to_asset = {
    'npn': 'tparty', 'ssn': 'tparty',
    'first name': 'tpers', 'last name': 'tpers', 'birth date': 'tpers',
    'phone number': 'tphne',
    'email address': 'telctr_addr',
    'business address: line 1': 'tphysc_addr',
    'business address: city': 'tphysc_addr',
    'business address: state': 'tphysc_addr',
    'business address: zip code': 'tphysc_addr',
    'home address: line 1': 'tphysc_addr',
    'home address: city': 'tphysc_addr',
    'home address: state': 'tphysc_addr',
    'home address: zip code': 'tphysc_addr',
}


# COMMAND ----------


rows = []
for col_name, rules in threshold_scores.items():
    col_norm = col_name.strip().lower()
    asset = column_to_asset.get(col_norm)
    if not asset:
        continue
    for entry in rules:
        rows.append(Row(
            workstream=config['work_stream'].lower(),
            source_system=config['data_system'].lower(),
            asset_name=asset.lower(),
            column_name=col_norm,
            data_quality_rule=entry['Rule'].strip().lower(),
            threshold=float(entry['Threshold'])
        ))

thresholds_df = spark.createDataFrame(rows)


# COMMAND ----------

thresholds_df_str = (
    thresholds_df
        .withColumn("workstream",        f.col("workstream").cast("string"))
        .withColumn("source_system",     f.col("source_system").cast("string"))
        .withColumn("asset_name",        f.col("asset_name").cast("string"))
        .withColumn("column_name",       f.col("column_name").cast("string"))
        .withColumn("data_quality_rule", f.col("data_quality_rule").cast("string"))
        .withColumn(
          "threshold",
          f.when((f.col("threshold") % 1) == 0,
                 f.col("threshold").cast("long").cast("string"))
           .otherwise(f.col("threshold").cast("string"))         
      )
)

# COMMAND ----------

uc_write_thresholds(thresholds_df_str, schema='data_quality', asset='thresholds')

# COMMAND ----------


config['asset_name'] = 'tparty'
s_tparty = get_summary(tparty_sel)

config['asset_name'] = 'tpers'
s_tpers = get_summary(tpers_sel)

config['asset_name'] = 'tphne'
s_tphne = get_summary(tphne_sel)

config['asset_name'] = 'telctr_addr'
s_telctr = get_summary(telctr_addr_sel)

config['asset_name'] = 'tphysc_addr'
s_tphys = get_summary(tphysc_addr_sel)

summary_df = s_tparty.union(s_tpers).union(s_tphne).union(s_telctr).union(s_tphys)


# COMMAND ----------

uc_write(summary_df)