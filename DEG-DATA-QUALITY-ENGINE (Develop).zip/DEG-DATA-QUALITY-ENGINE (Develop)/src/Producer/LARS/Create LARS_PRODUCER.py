# Databricks notebook source
# MAGIC  %run ../../utils

# COMMAND ----------

configure_spark()
config = {
    "container": 'gold',
    "parent_dir": 'LARS/parquet/LARS_OWNER',
    'asset_name': '',
    'work_stream': 'Producer',
    'data_system': 'LARS'
}


# COMMAND ----------

config['asset_name'] = 'TPARTY'
tparty = read_asset(**config)
tparty.createOrReplaceTempView('TPARTY')
tparty = spark.sql(
    """
    SELECT PARTY_ID_SEQ_NO, PARTY_ID_NO, PARTY_TYP_CD, NIPR_NO, FED_TAX_ID_NO, CREAT_BY_PRCS_DTM
    FROM TPARTY
    WHERE LAST_UPD_BY_NM IS NULL
      AND PARTY_TYP_CD = 50622
      AND FED_TAX_ID_NO <> 0
    """
)
tparty.createOrReplaceTempView('TPARTY')
tparty = tparty.withColumnRenamed('CREAT_BY_PRCS_DTM', 'ID_NO : Last Update')

# COMMAND ----------

config['asset_name'] = 'TPERS'
tpers = read_asset(**config)
tpers.createOrReplaceTempView('TPERS')
tpers = spark.sql(
    """
    SELECT PERS_ID_SEQ_NO, PERS_ID_NO, PARTY_ID_SEQ_NO, PARTY_ID_NO, FRST_NM, LAST_NM, BTH_DT, RETIRED_IND, CREAT_BY_PRCS_DTM
    FROM TPERS
    WHERE LAST_UPD_BY_NM IS NULL
    """
)
tpers.createOrReplaceTempView('TPERS')
tpers = tpers.withColumnRenamed('CREAT_BY_PRCS_DTM', 'Personal Information : Last Update')

# COMMAND ----------

config['asset_name'] = 'TADDR_ASOC'
taddr_asoc = read_asset(**config)
taddr_asoc.createOrReplaceTempView('TADDR_ASOC')

# COMMAND ----------

taddr_asoc = spark.sql(
    """
    SELECT ADDR_ID_SEQ_NO, ADDR_ID_NO, ADDR_USAG_CD, ADDR_TYP_CD, ENT_ID_NO, CREAT_BY_PRCS_DTM
    FROM TADDR_ASOC
    WHERE LAST_UPD_BY_NM IS NULL
      AND ADDR_ASOC_EXPR_DT IS NULL
    """
)
taddr_asoc.createOrReplaceTempView('TADDR_ASOC')
taddr_asoc = taddr_asoc.withColumnRenamed('CREAT_BY_PRCS_DTM', 'TADDR_ASOC_LAST_UPDATE')

# COMMAND ----------

config['asset_name'] = 'TPHYSC_ADDR'
tphysc_addr = read_asset(**config)
tphysc_addr.createOrReplaceTempView('TPHYSC_ADDR')
tphysc_addr = spark.sql(
    """
    SELECT ADDR_ID_NO, ST_ADDR_LN1_DESC, ST_ADDR_LN2_DESC, CITY_NM, PSTL_JURS_CD, ZIP_CD, CNTRY_NM, CREAT_BY_PRCS_DTM
    FROM TPHYSC_ADDR
    WHERE LAST_UPD_BY_NM IS NULL
    """
)
tphysc_addr.createOrReplaceTempView('TPHYSC_ADDR')
tphysc_addr = tphysc_addr.withColumnRenamed('CREAT_BY_PRCS_DTM', 'TPHYSC_ADDR_LAST_UPDATE')

# COMMAND ----------

config['asset_name'] = 'TELCTR_ADDR'
telctr_addr = read_asset(**config)
telctr_addr.createOrReplaceTempView('TELCTR_ADDR')
telctr_addr = spark.sql(
    """
    SELECT ADDR_ID_SEQ_NO, ADDR_ID_NO, ELCTR_ADDR_CD, ELCTR_ADDR_DESC, CREAT_BY_PRCS_DTM
    FROM TELCTR_ADDR
    WHERE LAST_UPD_BY_NM IS NULL
    """
)
telctr_addr.createOrReplaceTempView('TELCTR_ADDR')
telctr_addr = telctr_addr.withColumnRenamed('CREAT_BY_PRCS_DTM', 'TELCTR_ADDR_LAST_UPDATE')

# COMMAND ----------

config['asset_name'] = 'TPHNE'
tphne = read_asset(**config)
tphne.createOrReplaceTempView('TPHNE')
tphne = spark.sql(
    """
    SELECT ADDR_ID_SEQ_NO, ADDR_ID_NO, PHNE_AREA_CD, PHNE_NO, TELCM_DEVC_CD, CREAT_BY_PRCS_DTM
    FROM TPHNE
    WHERE LAST_UPD_BY_NM IS NULL
      AND TELCM_DEVC_CD = 50601
    """
)
tphne.createOrReplaceTempView('TPHNE')
tphne = tphne.withColumnRenamed('CREAT_BY_PRCS_DTM', 'TPHNE_LAST_UPDATE')

# COMMAND ----------

config['asset_name'] = 'TPERS_ORG_RELTN'
tpers_org_reltn = read_asset(**config)
tpers_org_reltn.createOrReplaceTempView('TPERS_ORG_RELTN')
tpers_org_reltn = spark.sql(
    """
    SELECT DISTINCT PRIM_RELTN_END_DT, PERS_ID_NO
    FROM TPERS_ORG_RELTN
    WHERE LAST_UPD_BY_NM IS NULL
      AND PRIM_RELTN_END_DT IS NULL
    """
)
tpers_org_reltn.createOrReplaceTempView('TPERS_ORG_RELTN')

# COMMAND ----------

taddr_asoc_business = spark.sql(
    """
    SELECT ADDR_ID_NO, ADDR_USAG_CD, ADDR_TYP_CD, ENT_ID_NO, CREAT_BY_PRCS_DTM
    FROM TADDR_ASOC
    WHERE ADDR_TYP_CD = 50219
      AND ADDR_USAG_CD = 50593
    """
)

# COMMAND ----------

taddr_asoc_residential = spark.sql(
    """
    SELECT ADDR_ID_NO, ADDR_USAG_CD, ADDR_TYP_CD, ENT_ID_NO, CREAT_BY_PRCS_DTM
    FROM TADDR_ASOC
    WHERE ADDR_TYP_CD = 50219
      AND ADDR_USAG_CD = 50592
    """
)

# COMMAND ----------

taddr_asoc_phone = spark.sql(
    """
    SELECT ADDR_ID_NO, ADDR_USAG_CD, ADDR_TYP_CD, ENT_ID_NO, CREAT_BY_PRCS_DTM
    FROM TADDR_ASOC
    WHERE ADDR_TYP_CD = 50218
      AND ADDR_USAG_CD = 50593
    """
)

# COMMAND ----------

taddr_asoc_email = spark.sql(
    """
    SELECT ADDR_ID_NO, ADDR_USAG_CD, ADDR_TYP_CD, ENT_ID_NO, CREAT_BY_PRCS_DTM
    FROM TADDR_ASOC
    WHERE ADDR_TYP_CD = 50217
    """
)

# COMMAND ----------

business_address = taddr_asoc_business.join(tphysc_addr, ['ADDR_ID_NO'], 'left')
business_address = business_address.withColumnRenamed('ENT_ID_NO', 'Business Address: ENT_ID_NO')
business_address = business_address.withColumnRenamed('ST_ADDR_LN1_DESC', 'Business Address: Line 1')
business_address = business_address.withColumnRenamed('ST_ADDR_LN2_DESC', 'Business Address: Line 2')
business_address = business_address.withColumnRenamed('CITY_NM', 'Business Address: City')
business_address = business_address.withColumnRenamed('PSTL_JURS_CD', 'Business Address: State')
business_address = business_address.withColumnRenamed('ZIP_CD', 'Business Address: Zip Code')
business_address = business_address.withColumnRenamed('CNTRY_NM', 'Business Address: Country')
business_address = business_address.withColumnRenamed('TPHYSC_ADDR_LAST_UPDATE', 'Business Address: Last Update')

# COMMAND ----------

residential_address = taddr_asoc_residential.join(tphysc_addr, ['ADDR_ID_NO'], 'left')
residential_address = residential_address.withColumnRenamed('ENT_ID_NO', 'Home Address: ENT_ID_NO')
residential_address = residential_address.withColumnRenamed('ST_ADDR_LN1_DESC', 'Home Address: Line 1')
residential_address = residential_address.withColumnRenamed('ST_ADDR_LN2_DESC', 'Home Address: Line 2')
residential_address = residential_address.withColumnRenamed('CITY_NM', 'Home Address: City')
residential_address = residential_address.withColumnRenamed('PSTL_JURS_CD', 'Home Address: State')
residential_address = residential_address.withColumnRenamed('ZIP_CD', 'Home Address: Zip Code')
residential_address = residential_address.withColumnRenamed('CNTRY_NM', 'Home Address: Country')
residential_address = residential_address.withColumnRenamed('TPHYSC_ADDR_LAST_UPDATE', 'Home Address: Last Update')

# COMMAND ----------

phone_number = taddr_asoc_phone.join(tphne, ['ADDR_ID_NO'], 'left')
phone_number = phone_number.withColumnRenamed('ENT_ID_NO', 'Phone: ENT_ID_NO')
phone_number = phone_number.withColumnRenamed('TPHNE_LAST_UPDATE', 'Phone: Last Update')
phone_number = phone_number.filter(phone_number['ADDR_ID_SEQ_NO'].isNotNull())

# COMMAND ----------

email_address = taddr_asoc_email.join(telctr_addr, ['ADDR_ID_NO'], 'left')
email_address = email_address.withColumnRenamed('ENT_ID_NO', 'Email: ENT_ID_NO')
email_address = email_address.withColumnRenamed('TELCTR_ADDR_LAST_UPDATE', 'Email: Last Update')

# COMMAND ----------

df = tparty
df = df.join(tpers,['PARTY_ID_NO'], 'left')
df = df.join(tpers_org_reltn, ['PERS_ID_NO'], 'inner')
df = df.join(business_address, df['PERS_ID_NO'] == business_address['Business Address: ENT_ID_NO'], 'left')
df = df.join(residential_address, df['PERS_ID_NO'] == residential_address['Home Address: ENT_ID_NO'], 'left')
df = df.join(phone_number, df['PERS_ID_NO'] == phone_number['Phone: ENT_ID_NO'], 'left')
df = df.join(email_address, df['PERS_ID_NO'] == email_address['Email: ENT_ID_NO'], 'left')

# COMMAND ----------

# tcodedecode = spark.read.parquet(f'{adls_stem}/tcodedecode', header ='True')
config['asset_name'] = 'tcodedecode'
tcodedecode = read_asset(**config)
tcodedecode.createOrReplaceTempView('TCODEDECODE')
tcodedecode = tcodedecode.select(['CDC_ID_NO','C_CODE'])
tcodedecode = tcodedecode.filter(f.trim(tcodedecode['C_CODE']).isin(US_STATES))

# COMMAND ----------

df = df.join(tcodedecode,df['Business Address: State'] == tcodedecode['CDC_ID_NO'], 'left')
df = df.drop('CDC_ID_NO')
df = df.drop('Business Address: State')
df = df.withColumnRenamed('C_CODE', 'Business Address: State')

# COMMAND ----------

df = df.join(tcodedecode,df['Home Address: State'] == tcodedecode['CDC_ID_NO'], 'left')
df = df.drop('CDC_ID_NO')
df = df.drop('Home Address: State')
df = df.withColumnRenamed('C_CODE', 'Home Address: State')

# COMMAND ----------

df = df.withColumn("Phone Number",f.concat(df['PHNE_AREA_CD'],df['PHNE_NO']))

# COMMAND ----------

df = df.drop('PHNE_AREA_CD')
df = df.drop('PHNE_NO')

# COMMAND ----------

df = df.select('tpers.PERS_ID_NO', 'tpers.PERS_ID_SEQ_NO', 'tparty.PARTY_ID_NO', 'tparty.PARTY_ID_SEQ_NO', 'PARTY_TYP_CD', 'NIPR_NO', 'FED_TAX_ID_NO', 'ID_NO : Last Update', 'FRST_NM', 'LAST_NM', 'BTH_DT', 'Personal Information : Last Update','Business Address: Line 1', 'Business Address: Line 2', 'Business Address: City', 'Business Address: State', 'Business Address: Zip Code', 'Business Address: Country', 'Business Address: Last Update', 'Home Address: Line 1', 'Home Address: Line 2', 'Home Address: City', 'Home Address: State', 'Home Address: Zip Code', 'Home Address: Country',  'Home Address: Last Update','TELCM_DEVC_CD', 'ELCTR_ADDR_DESC', 'Email: Last Update', 'Phone Number', 'Phone: Last Update','RETIRED_IND')
df = df.distinct()

# COMMAND ----------

df = df.select('tpers.PERS_ID_NO', 'tparty.PARTY_ID_NO', 'NIPR_NO', 'FED_TAX_ID_NO', 'ID_NO : Last Update','FRST_NM', 'LAST_NM', 'BTH_DT', 'Personal Information : Last Update', 'Business Address: Line 1', 'Business Address: Line 2', 'Business Address: City', 'Business Address: State', 'Business Address: Zip Code', 'Business Address: Last Update','Home Address: Line 1', 'Home Address: Line 2', 'Home Address: City', 'Home Address: State', 'Home Address: Zip Code', 'Home Address: Last Update', 'ELCTR_ADDR_DESC', 'Email: Last Update', 'Phone Number', 'Phone: Last Update', 'RETIRED_IND')
df = df.distinct()

# COMMAND ----------

df = df.withColumnRenamed('FRST_NM', 'First Name')
df = df.withColumnRenamed('LAST_NM', 'Last Name')
df = df.withColumnRenamed('BTH_DT', 'Birth Date')
df = df.withColumnRenamed('ELCTR_ADDR_DESC', 'Email Address')
df = df.withColumnRenamed('NIPR_NO', 'NPN')
df = df.withColumnRenamed('FED_TAX_ID_NO', 'SSN')
df = df.withColumnRenamed('RETIRED_IND', 'Retired Producer')

# COMMAND ----------

df = df.withColumn('Birth Date', f.date_format((f.col('Birth Date')),"yyyy-MM-dd"))
df = df.withColumn('ID_NO : Last Update', f.date_format((f.col('ID_NO : Last Update')),"yyyy-MM-dd"))
df = df.withColumn('Personal Information : Last Update', f.date_format((f.col('Personal Information : Last Update')),"yyyy-MM-dd"))
df = df.withColumn('Business Address: Last Update', f.date_format((f.col('Business Address: Last Update')),"yyyy-MM-dd"))
df = df.withColumn('Home Address: Last Update', f.date_format((f.col('Home Address: Last Update')),"yyyy-MM-dd"))
df = df.withColumn('Phone: Last Update', f.date_format((f.col('Phone: Last Update')),"yyyy-MM-dd"))
df = df.withColumn('Email: Last Update', f.date_format((f.col('Email: Last Update')),"yyyy-MM-dd"))


# COMMAND ----------

df.write.mode("overwrite").parquet(f"abfss://dataquality@{ENV['storage_account']}.dfs.core.windows.net/Producer/_Custom_Views/LARS_PRODUCER")