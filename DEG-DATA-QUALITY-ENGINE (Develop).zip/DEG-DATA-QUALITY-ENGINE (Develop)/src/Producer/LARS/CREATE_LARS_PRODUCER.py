# Databricks notebook source
# MAGIC  %run ../../utils

# COMMAND ----------

config['work_stream']   = 'Producer'
config['data_system']   = 'Lars'
config['data_owner']    = 'Amanda Murphy'
config['business_unit'] = 'Life (US)'
config['data_domain']   = 'Producer & Distributor'
config['rule_owner']    = 'Amanda Murphy'


tparty_cols = ['PARTY_ID_SEQ_NO', 'PARTY_ID_NO', 'PARTY_TYP_CD', 'NIPR_NO', 'FED_TAX_ID_NO','CREAT_BY_PRCS_DTM', 'LAST_UPD_BY_NM']
tpers_cols = ['PERS_ID_SEQ_NO', 'PERS_ID_NO', 'PARTY_ID_SEQ_NO', 'PARTY_ID_NO','FRST_NM', 'LAST_NM', 'BTH_DT', 'RETIRED_IND','CREAT_BY_PRCS_DTM', 'LAST_UPD_BY_NM']
taddr_asoc_cols = ['ADDR_ID_SEQ_NO', 'ADDR_ID_NO', 'ADDR_USAG_CD', 'ADDR_TYP_CD','ENT_ID_NO', 'ADDR_ASOC_EXPR_DT', 'CREAT_BY_PRCS_DTM', 'LAST_UPD_BY_NM']
tphysc_addr_cols = ['ADDR_ID_NO', 'ST_ADDR_LN1_DESC', 'ST_ADDR_LN2_DESC', 'CITY_NM','PSTL_JURS_CD', 'ZIP_CD', 'CNTRY_NM', 'CREAT_BY_PRCS_DTM', 'LAST_UPD_BY_NM']
telctr_addr_cols = ['ADDR_ID_SEQ_NO', 'ADDR_ID_NO', 'ELCTR_ADDR_CD', 'ELCTR_ADDR_DESC','CREAT_BY_PRCS_DTM', 'LAST_UPD_BY_NM']
tphne_cols = ['ADDR_ID_SEQ_NO', 'ADDR_ID_NO', 'PHNE_AREA_CD', 'PHNE_NO','TELCM_DEVC_CD', 'CREAT_BY_PRCS_DTM', 'LAST_UPD_BY_NM']
tpers_org_cols = ['PRIM_RELTN_END_DT', 'PERS_ID_NO', 'LAST_UPD_BY_NM']
tcodedecode_cols = ['CDC_ID_NO', 'C_CODE']

tparty          = uc_read('silver_lars', 'tparty').select(tparty_cols)
tpers           = uc_read('silver_lars', 'tpers').select(tpers_cols)
taddr_asoc      = uc_read('silver_lars', 'taddr_asoc').select(taddr_asoc_cols)
tphysc_addr     = uc_read('silver_lars', 'tphysc_addr').select(tphysc_addr_cols)
telctr_addr     = uc_read('silver_lars', 'telctr_addr').select(telctr_addr_cols)
tphne           = uc_read('silver_lars', 'tphne').select(tphne_cols)
tpers_org_reltn = uc_read('silver_lars', 'tpers_org_reltn').select(tpers_org_cols)
tcodedecode     = uc_read('silver_lars', 'tcodedecode').select(tcodedecode_cols)


# COMMAND ----------

tparty = (tparty.filter(
        (f.col('LAST_UPD_BY_NM').isNull()) &
        (f.col('PARTY_TYP_CD') == 50622) &
        (f.col('FED_TAX_ID_NO') != 0)).drop('LAST_UPD_BY_NM'))

tpers = tpers.filter(f.col('LAST_UPD_BY_NM').isNull()).drop('LAST_UPD_BY_NM')

taddr_asoc = (taddr_asoc.filter(
        (f.col('LAST_UPD_BY_NM').isNull()) &
        (f.col('ADDR_ASOC_EXPR_DT').isNull())).drop('LAST_UPD_BY_NM'))

tphysc_addr = tphysc_addr.filter(f.col('LAST_UPD_BY_NM').isNull()).drop('LAST_UPD_BY_NM')
telctr_addr = telctr_addr.filter(f.col('LAST_UPD_BY_NM').isNull()).drop('LAST_UPD_BY_NM')

tphne = (tphne.filter(
        (f.col('LAST_UPD_BY_NM').isNull()) &
        (f.col('TELCM_DEVC_CD') == 50601)).drop('LAST_UPD_BY_NM'))

tpers_org_reltn = (tpers_org_reltn.filter(
        (f.col('LAST_UPD_BY_NM').isNull()) &
        (f.col('PRIM_RELTN_END_DT').isNull()))
    .select('PRIM_RELTN_END_DT', 'PERS_ID_NO')
    .distinct())

tcodedecode = tcodedecode.filter(f.trim(f.col('C_CODE')).isin(US_STATES))

# COMMAND ----------

tparty = tparty.withColumnRenamed('CREAT_BY_PRCS_DTM', 'ID_NO : Last Update')
tpers = tpers.withColumnRenamed('CREAT_BY_PRCS_DTM', 'Personal Information : Last Update')
tphysc_addr = tphysc_addr.withColumnRenamed('CREAT_BY_PRCS_DTM', 'TPHYSC_ADDR_LAST_UPDATE')
telctr_addr = telctr_addr.withColumnRenamed('CREAT_BY_PRCS_DTM', 'TELCTR_ADDR_LAST_UPDATE')
tphne = tphne.withColumnRenamed('CREAT_BY_PRCS_DTM', 'TPHNE_LAST_UPDATE')

tparty = tparty.withColumnRenamed('PARTY_ID_SEQ_NO', 'TPARTY_PARTY_ID_SEQ_NO')
tpers  = tpers.withColumnRenamed('PARTY_ID_SEQ_NO', 'TPERS_PARTY_ID_SEQ_NO')

# COMMAND ----------

taddr_asoc_business = (taddr_asoc.filter((f.col('ADDR_TYP_CD') == 50219) & (f.col('ADDR_USAG_CD') == 50593))
    .select('ADDR_ID_NO', 'ADDR_USAG_CD', 'ADDR_TYP_CD', 'ENT_ID_NO', 'CREAT_BY_PRCS_DTM'))

taddr_asoc_residential = (taddr_asoc.filter((f.col('ADDR_TYP_CD') == 50219) & (f.col('ADDR_USAG_CD') == 50592))
    .select('ADDR_ID_NO', 'ADDR_USAG_CD', 'ADDR_TYP_CD', 'ENT_ID_NO', 'CREAT_BY_PRCS_DTM'))

taddr_asoc_phone = (taddr_asoc.filter((f.col('ADDR_TYP_CD') == 50218) & (f.col('ADDR_USAG_CD') == 50593))
    .select('ADDR_ID_NO', 'ADDR_USAG_CD', 'ADDR_TYP_CD', 'ENT_ID_NO', 'CREAT_BY_PRCS_DTM'))

taddr_asoc_email = (taddr_asoc.filter(f.col('ADDR_TYP_CD') == 50217)
    .select('ADDR_ID_NO', 'ADDR_USAG_CD', 'ADDR_TYP_CD', 'ENT_ID_NO', 'CREAT_BY_PRCS_DTM'))

# COMMAND ----------

business_address = (taddr_asoc_business
    .join(tphysc_addr, ['ADDR_ID_NO'], 'left')
    .withColumnRenamed('ENT_ID_NO', 'Business Address: ENT_ID_NO')
    .withColumnRenamed('ST_ADDR_LN1_DESC', 'Business Address: Line 1')
    .withColumnRenamed('ST_ADDR_LN2_DESC', 'Business Address: Line 2')
    .withColumnRenamed('CITY_NM', 'Business Address: City')
    .withColumnRenamed('PSTL_JURS_CD', 'Business Address: State')
    .withColumnRenamed('ZIP_CD', 'Business Address: Zip Code')
    .withColumnRenamed('CNTRY_NM', 'Business Address: Country')
    .withColumnRenamed('TPHYSC_ADDR_LAST_UPDATE', 'Business Address: Last Update'))

residential_address = (taddr_asoc_residential
    .join(tphysc_addr, ['ADDR_ID_NO'], 'left')
    .withColumnRenamed('ENT_ID_NO', 'Home Address: ENT_ID_NO')
    .withColumnRenamed('ST_ADDR_LN1_DESC', 'Home Address: Line 1')
    .withColumnRenamed('ST_ADDR_LN2_DESC', 'Home Address: Line 2')
    .withColumnRenamed('CITY_NM', 'Home Address: City')
    .withColumnRenamed('PSTL_JURS_CD', 'Home Address: State')
    .withColumnRenamed('ZIP_CD', 'Home Address: Zip Code')
    .withColumnRenamed('CNTRY_NM', 'Home Address: Country')
    .withColumnRenamed('TPHYSC_ADDR_LAST_UPDATE', 'Home Address: Last Update'))

phone_number = (taddr_asoc_phone
    .join(tphne, ['ADDR_ID_NO'], 'left')
    .withColumnRenamed('ENT_ID_NO', 'Phone: ENT_ID_NO')
    .withColumnRenamed('TPHNE_LAST_UPDATE', 'Phone: Last Update')
    .filter(f.col('ADDR_ID_SEQ_NO').isNotNull()))

email_address = (taddr_asoc_email
    .join(telctr_addr, ['ADDR_ID_NO'], 'left')
    .withColumnRenamed('ENT_ID_NO', 'Email: ENT_ID_NO')
    .withColumnRenamed('TELCTR_ADDR_LAST_UPDATE', 'Email: Last Update')
)

# COMMAND ----------

df = (tparty
    .join(tpers, ['PARTY_ID_NO'], 'left')
    .join(tpers_org_reltn.select('PERS_ID_NO').distinct(), ['PERS_ID_NO'], 'inner')
    .join(business_address, f.col('PERS_ID_NO') == f.col('Business Address: ENT_ID_NO'), 'left')
    .join(residential_address, f.col('PERS_ID_NO') == f.col('Home Address: ENT_ID_NO'), 'left')
    .join(phone_number, f.col('PERS_ID_NO') == f.col('Phone: ENT_ID_NO'), 'left')
    .join(email_address, f.col('PERS_ID_NO') == f.col('Email: ENT_ID_NO'), 'left'))

df = (df.join(tcodedecode, f.col('Business Address: State') == f.col('CDC_ID_NO'), 'left')
      .drop('CDC_ID_NO', 'Business Address: State')
      .withColumnRenamed('C_CODE', 'Business Address: State'))

df = (df.join(tcodedecode, f.col('Home Address: State') == f.col('CDC_ID_NO'), 'left')
      .drop('CDC_ID_NO', 'Home Address: State')
      .withColumnRenamed('C_CODE', 'Home Address: State'))

df = (df.withColumn('Phone Number', f.concat(f.col('PHNE_AREA_CD'), f.col('PHNE_NO')))
      .drop('PHNE_AREA_CD', 'PHNE_NO'))

df = df.select(
    'PERS_ID_NO', 'TPERS_PARTY_ID_SEQ_NO', 
    'PARTY_ID_NO', 'TPARTY_PARTY_ID_SEQ_NO',
    'PARTY_TYP_CD', 'NIPR_NO', 'FED_TAX_ID_NO', 'ID_NO : Last Update',
    'FRST_NM', 'LAST_NM', 'BTH_DT', 'Personal Information : Last Update',

    'Business Address: Line 1', 'Business Address: Line 2', 'Business Address: City',
    'Business Address: State', 'Business Address: Zip Code', 'Business Address: Country',
    'Business Address: Last Update',

    'Home Address: Line 1', 'Home Address: Line 2', 'Home Address: City',
    'Home Address: State', 'Home Address: Zip Code', 'Home Address: Country',
    'Home Address: Last Update',

    'TELCM_DEVC_CD', 'ELCTR_ADDR_DESC', 'Email: Last Update',
    'Phone Number', 'Phone: Last Update', 'RETIRED_IND'
).distinct()

df = df.select(
    'PERS_ID_NO', 'PARTY_ID_NO', 'NIPR_NO', 'FED_TAX_ID_NO', 'ID_NO : Last Update',
    'FRST_NM', 'LAST_NM', 'BTH_DT', 'Personal Information : Last Update',

    'Business Address: Line 1', 'Business Address: Line 2', 'Business Address: City',
    'Business Address: State', 'Business Address: Zip Code', 'Business Address: Last Update',

    'Home Address: Line 1', 'Home Address: Line 2', 'Home Address: City',
    'Home Address: State', 'Home Address: Zip Code', 'Home Address: Last Update',

    'ELCTR_ADDR_DESC', 'Email: Last Update', 'Phone Number', 'Phone: Last Update',
    'RETIRED_IND'
).distinct()

# COMMAND ----------

df = (df
    .withColumnRenamed('FRST_NM', 'First Name')
    .withColumnRenamed('LAST_NM', 'Last Name')
    .withColumnRenamed('BTH_DT', 'Birth Date')
    .withColumnRenamed('ELCTR_ADDR_DESC', 'Email Address')
    .withColumnRenamed('NIPR_NO', 'NPN')
    .withColumnRenamed('FED_TAX_ID_NO', 'SSN')
    .withColumnRenamed('RETIRED_IND', 'Retired Producer')
)

# COMMAND ----------


df = df.withColumn('Business Address: STATE', f.trim(df['Business Address: STATE']))
df = df.withColumn('Home Address: STATE', f.trim(df['Home Address: STATE']))
df = df.withColumn('First Name', f.trim(df['First Name']))
df = df.withColumn('Last Name', f.trim(df['Last Name']))
df = df.withColumn('NPN', f.trim(df['NPN']))

# COMMAND ----------

date_cols = ['Birth Date', 'ID_NO : Last Update', 'Personal Information : Last Update', 'Business Address: Last Update', 'Home Address: Last Update', 'Phone: Last Update', 'Email: Last Update']
for c in date_cols:
    df = df.withColumn(c, f.date_format(f.col(c), 'yyyy-MM-dd'))

lars_df = df

del (tparty, tpers, taddr_asoc, tphysc_addr, telctr_addr, tphne, tpers_org_reltn,
    taddr_asoc_business, taddr_asoc_residential, taddr_asoc_phone, taddr_asoc_email,
    business_address, residential_address, phone_number, email_address,
    tcodedecode, df)