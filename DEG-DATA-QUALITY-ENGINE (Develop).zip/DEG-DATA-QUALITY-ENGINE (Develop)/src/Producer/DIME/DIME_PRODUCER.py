# Databricks notebook source
# MAGIC  %run ../../utils

# COMMAND ----------

# configure_spark()
# config = {
#     "container": 'gold',
#     "parent_dir": 'life_mdm/parquet/IBMMDM',
#     'asset_name': '',
#     'work_stream': 'Producer',
#     'data_system': 'DIME'
# }
# df = spark.read.parquet(f"abfss://dataquality@{ENV['storage_account']}.dfs.core.windows.net/Producer/_Custom_Views/DIME_PRODUCER", header ='True')

configure_spark()
config = {
    "container": 'dataquality',
    "parent_dir": 'Producer/_Custom_Views',
    'asset_name': 'DIME_PRODUCER',
    'work_stream': 'Producer',
    'data_system': 'DIME'
}

df = read_asset(**config)

# COMMAND ----------

#COMPLETENESS
completeness_check_columns = ['NPN']
for column in completeness_check_columns:
    df = completeness_check(df, column)

# COMMAND ----------

summary_df = get_summary(df, None, **config)
failed_rows_df = get_failed_rows(df)
save_parquet_results(failed_rows_df, summary_df, **config)
