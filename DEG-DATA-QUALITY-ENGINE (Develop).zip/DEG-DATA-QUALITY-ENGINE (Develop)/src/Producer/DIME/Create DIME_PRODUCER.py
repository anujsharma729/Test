# Databricks notebook source
# MAGIC  %run ../../utils

# COMMAND ----------

# #configure_spark()
# config = {
#     "container": 'gold',
#     "parent_dir": 'life_mdm/parquet/IBMMDM',
#     'asset_name': 'DIME_PRODUCER',
#     'work_stream': 'Producer',
#     'data_system': 'DIME'
# }
# container = config['container']
# parent_dir = config['parent_dir']
# adls_stem = f'abfss://{container}@{PROD_ADLS_STORAGE_ACCOUNT}.dfs.core.windows.net/{parent_dir}'


# COMMAND ----------

# tables = ['CONTACT','PERSON','PERSONNAME','IDENTIFIER','CDIDTP','LOCATIONGROUP','ADDRESSGROUP','ADDRESS','CDCOUNTRYTP','CDPROVSTATETP','CDADDRUSAGETP','CONTACTMETHODGROUP','CONTACTMETHOD','CDCONTMETHTP','CDCONTMETHCAT']
# for table in tables:
#     df = spark.read.parquet(f'{adls_stem}/{table}', header ='True')
#     df.createOrReplaceTempView(table)


# COMMAND ----------

tables = ['CONTACT','PERSON','PERSONNAME','IDENTIFIER','CDIDTP','LOCATIONGROUP','ADDRESSGROUP','ADDRESS','CDCOUNTRYTP','CDPROVSTATETP','CDADDRUSAGETP','CONTACTMETHODGROUP','CONTACTMETHOD','CDCONTMETHTP','CDCONTMETHCAT']

for table in tables:
    
    config = {
        "container": "gold",
        "parent_dir": "life_mdm/parquet/IBMMDM",
        "asset_name": '',
        "work_stream": "Producer",
        "data_system": "DIME"
    }

    config['asset_name'] = table
    df = read_asset(**config)
    df.createOrReplaceTempView(table)



# COMMAND ----------

df = spark.sql(
    """
    WITH 
    AGENTCODE_PAYROLL_ID (SELECT CONT_ID FROM IDENTIFIER WHERE ID_TP_CD IN (1000005,1000010,1000030) AND END_DT IS NULL), --Has Agent Code or Payroll Number
    NPN_ID (SELECT CONT_ID, REF_NUM FROM IDENTIFIER WHERE ID_TP_CD = 1000024 AND END_DT IS NULL),
    SSN_ID (SELECT CONT_ID, REF_NUM FROM IDENTIFIER WHERE ID_TP_CD = 1 AND END_DT IS NULL),
    PAYROLL_ID (SELECT CONT_ID, REF_NUM FROM IDENTIFIER WHERE ID_TP_CD = 1000010 AND END_DT IS NULL),
    UUID_ID (SELECT CONT_ID, REF_NUM FROM IDENTIFIER WHERE ID_TP_CD = 1000001 AND END_DT IS NULL),
    SELLER_ID (SELECT CONT_ID, REF_NUM FROM IDENTIFIER WHERE ID_TP_CD = 1000014 AND END_DT IS NULL),
    PERSONNAME (SELECT * FROM PERSONNAME WHERE NAME_USAGE_TP_CD = 1 AND END_DT IS NULL),
    CONTACT (SELECT * FROM CONTACT WHERE INACTIVATED_DT IS NULL)

    SELECT DISTINCT 
        P.CONT_ID,
        SSN_ID.REF_NUM SSN,
        PAYROLL_ID.REF_NUM PAYROLL,
        UUID_ID.REF_NUM UUID,
        SELLER_ID.REF_NUM SELLER,
        P.BIRTH_DT, 
        PN.GIVEN_NAME_ONE FIRST_NAME, 
        PN.LAST_NAME,
        NPN_ID.REF_NUM NPN
    FROM PERSON P
    INNER JOIN PERSONNAME PN ON P.CONT_ID = PN.CONT_ID 
    INNER JOIN CONTACT C ON P.CONT_ID = C.CONT_ID
    INNER JOIN AGENTCODE_PAYROLL_ID ON P.CONT_ID = AGENTCODE_PAYROLL_ID.CONT_ID
    LEFT JOIN SSN_ID ON P.CONT_ID = SSN_ID.CONT_ID
    LEFT JOIN PAYROLL_ID ON P.CONT_ID = PAYROLL_ID.CONT_ID
    LEFT JOIN UUID_ID ON P.CONT_ID = UUID_ID.CONT_ID
    LEFT JOIN SELLER_ID ON P.CONT_ID = SELLER_ID.CONT_ID
    LEFT JOIN NPN_ID ON P.CONT_ID = NPN_ID.CONT_ID
    """
)

# COMMAND ----------

df.write.mode("overwrite").parquet(f"abfss://dataquality@{ENV['storage_account']}.dfs.core.windows.net/Producer/_Custom_Views/DIME_PRODUCER")
