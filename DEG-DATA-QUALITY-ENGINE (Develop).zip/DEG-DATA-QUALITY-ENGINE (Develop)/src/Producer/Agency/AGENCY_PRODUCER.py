# Databricks notebook source
# MAGIC %run ../../utils

# COMMAND ----------

# configure_spark()
# config = {
#     "container": 'gold',
#     "parent_dir": 'agency/parquet/DB2AYP',
#     'asset_name': '',
#     'work_stream': 'Producer',
#     'data_system': 'Agency'
# }
# df = spark.read.parquet(f"abfss://dataquality@{ENV['storage_account']}.dfs.core.windows.net/Producer/_Custom_Views/AGENCY_PRODUCER", header ='True')


configure_spark()
config = {
    "container": 'dataquality',
    "parent_dir": 'Producer/_Custom_Views',
    'asset_name': 'AGENCY_PRODUCER',
    'work_stream': 'Producer',
    'data_system': 'Agency',
    "data_owner": "Amanda Murphy",
    "business_unit": "Life",
    "data_domain": "Producer & Distributor",
    "rule_owner": "Amanda Murphy"
}
df = read_asset(**config)

# COMMAND ----------

consistency_config = {
"container": 'dataquality',
"parent_dir": 'Producer/_Custom_Views',
"asset_name": 'LARS_PRODUCER',
"primary_key": 'SSNTAXID',
"foreign_key": 'SSN',
"work_stream": 'Producer',
"data_system": 'Agency'
}

df2 = read_asset(**consistency_config)

# COMMAND ----------

#CONSISTENCY
df = df.withColumn('SSNTAXID', f.regexp_replace('SSNTAXID', '-', ''))
df = df.join(df2, df['SSNTAXID'] == df2['SSN'], 'inner')

df = df.withColumn('SELPHONENO', f.regexp_replace('SELPHONENO', '-', ''))
df = df.withColumn('SELINTERNET1', f.lower('SELINTERNET1'))
df = df.withColumn('Email Address', f.lower('Email Address'))


df = df.withColumn('SELLERNPN', f.trim(df['SELLERNPN']))
df = df.withColumn('SSNTAXID', f.trim(df['SSNTAXID']))
df = df.withColumn('SELMAILST1', f.trim(df['SELMAILST1']))
df = df.withColumn('SELMAILST2', f.trim(df['SELMAILST2']))
df = df.withColumn('SELMAILCITY', f.trim(df['SELMAILCITY']))
df = df.withColumn('SELMAILSTATE', f.trim(df['SELMAILSTATE']))
df = df.withColumn('SELMAILZIP', f.trim(df['SELMAILZIP']))
df = df.withColumn('SELHOMEST1', f.trim(df['SELHOMEST1']))
df = df.withColumn('SELHOMEST2', f.trim(df['SELHOMEST2']))
df = df.withColumn('SELHOMECITY', f.trim(df['SELHOMECITY']))
df = df.withColumn('SELHOMESTATE', f.trim(df['SELHOMESTATE']))
df = df.withColumn('SELHOMEZIP', f.trim(df['SELHOMEZIP']))
df = df.withColumn('Business Address: STATE', f.trim(df['Business Address: STATE']))
df = df.withColumn('Home Address: STATE', f.trim(df['Home Address: STATE']))
df = df.withColumn('SELINTERNET1', f.trim(df['SELINTERNET1']))

df = df.withColumn('SELGIVENNAME', f.trim(df['SELGIVENNAME']))
df = df.withColumn('SELSURFIRMNAME', f.trim(df['SELSURFIRMNAME']))
df = df.withColumn('First Name', f.trim(df['First Name']))
df = df.withColumn('Last Name', f.trim(df['Last Name']))

df = consistency_check(df, 'LARS_PRODUCER', 'SSNTAXID', 'SSN', 'SELLERNPN', 'NPN')
df = consistency_check(df, 'LARS_PRODUCER', 'SSNTAXID', 'SSN', 'SSNTAXID', 'SSN')

df = consistency_check(df, 'LARS_PRODUCER', 'SSNTAXID', 'SSN', 'SELGIVENNAME', 'First Name')
df = consistency_check(df, 'LARS_PRODUCER', 'SSNTAXID', 'SSN', 'SELSURFIRMNAME', 'Last Name',)

df = consistency_check(df, 'LARS_PRODUCER', 'SSNTAXID', 'SSN', 'SELMAILST1', 'Business Address: Line 1')
# df = consistency_check(df, 'LARS_PRODUCER', 'SSNTAXID', 'SSN', 'SELMAILST2', 'Business Address: Line 2')
df = consistency_check(df, 'LARS_PRODUCER', 'SSNTAXID', 'SSN', 'SELMAILCITY', 'Business Address: City')
df = consistency_check(df, 'LARS_PRODUCER', 'SSNTAXID', 'SSN', 'SELMAILSTATE', 'Business Address: STATE')
df = consistency_check(df, 'LARS_PRODUCER', 'SSNTAXID', 'SSN', 'SELMAILZIP', 'Business Address: Zip Code')
df = consistency_check(df, 'LARS_PRODUCER', 'SSNTAXID', 'SSN', 'SELHOMEST1', 'Home Address: Line 1')
# df = consistency_check(df, 'LARS_PRODUCER', 'SSNTAXID', 'SSN', 'SELHOMEST2', 'Home Address: Line 2')
df = consistency_check(df, 'LARS_PRODUCER', 'SSNTAXID', 'SSN', 'SELHOMECITY', 'Home Address: City')
df = consistency_check(df, 'LARS_PRODUCER', 'SSNTAXID', 'SSN', 'SELHOMESTATE', 'Home Address: STATE')
df = consistency_check(df, 'LARS_PRODUCER', 'SSNTAXID', 'SSN', 'SELHOMEZIP', 'Home Address: Zip Code')

df = consistency_check(df, 'LARS_PRODUCER', 'SSNTAXID', 'SSN', 'SELPHONENO', 'Phone Number')
df = consistency_check(df, 'LARS_PRODUCER', 'SSNTAXID', 'SSN', 'SELINTERNET1', 'Email Address')


df = df.drop(*df2.columns)

# COMMAND ----------

summary_df = get_summary(df, None, **config)
failed_rows_df = get_failed_rows(df)

# COMMAND ----------

# df.coalesce(1).write.option("header",True).csv(f"abfss://dataquality@{ENV['storage_account']}.dfs.core.windows.net/Producer/_test/{TIMESTAMP}/failed_rows_df")

# COMMAND ----------

display(summary_df)

# COMMAND ----------

# save_parquet_results(failed_rows_df, summary_df, **config)
