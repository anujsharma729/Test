# Databricks notebook source
# MAGIC  %run ../../utils

# COMMAND ----------

# MAGIC %run ../LARS/CREATE_LARS_PRODUCER

# COMMAND ----------


config['data_system']   = 'Agency'
config['asset_name'] = 'tayseller'

tayseller  = uc_read('silver_agency','tayseller')
tayslstat  = uc_read('silver_agency','tayslstat')


tayseller_cols = ["SELLERID", "SSNTAXID", "SELLERNPN", "SELSURFIRMNAME", "SELGIVENNAME","SELSURFIRMIND", "SELINITIALS", "SELHOMEST1", "SELHOMEST2", "SELHOMEST3", "SELHOMECITY", "SELHOMESTATE", "SELHOMEZIP", "SELMAILST1", "SELMAILST2", "SELMAILST3", "SELMAILCITY", "SELMAILSTATE", "SELMAILZIP", "SELSHORTNAME", "SELPHONENO", "SELHOUSEDIND", "SELUSRESIND", "SELCELLPHONE", "SELFAXNO", "SELPAGERNO", "SELINTERNET1", "SELINTERNET2", "SELCONVERTIND", "SELREGISTIND", "SELW8IND", "SELW8EXPDATE", "SELW9IND", "SELRESTRICTED","SELUPDDATE", "SELUSERID", "CONTACTNAME1", "ROLE1", "TEL1", "EMAIL1", "CONTACTNAME2", "ROLE2", "TEL2", "EMAIL2","CONTACTNAME3", "ROLE3", "TEL3", "EMAIL3","CONTACTNAME4", "ROLE4", "TEL4", "EMAIL4"]
tayslstat_cols = ["SELLERID", "SLSTATEFFDTE", "SELSTATUS"]


tayseller = tayseller.select(tayseller_cols)
tayslstat = tayslstat.select(tayslstat_cols)
tayseller = tayseller.filter(tayseller.SELSURFIRMIND == 'S')

window_spec = Window.partitionBy("SELLERID")
tayslstat = tayslstat.withColumn("max_date", f.max("SLSTATEFFDTE").over(window_spec)).filter(col("SLSTATEFFDTE") == col("max_date")).drop("max_date")

df = tayslstat.join(tayseller, ['SELLERID'], 'inner')
df = trim(df)

# COMMAND ----------

df = df.withColumn('SSNTAXID', f.regexp_replace('SSNTAXID', '-', ''))
df = df.join(lars_df, df['SSNTAXID'] == lars_df['SSN'], 'inner')

df = df.withColumn('SELPHONENO', f.regexp_replace('SELPHONENO', '-', ''))
df = df.withColumn('SELINTERNET1', f.lower('SELINTERNET1'))
df = df.withColumn('Email Address', f.lower('Email Address'))


df = df.withColumn('SELLERNPN', f.trim(df['SELLERNPN']))
df = df.withColumn('SELLERNPN', f.regexp_replace(df['SELLERNPN'], r'\.0*$', ''))
df = df.withColumn('SSNTAXID', f.trim(df['SSNTAXID']))
df = df.withColumn('SELMAILST1', f.trim(df['SELMAILST1']))
df = df.withColumn('SELMAILST2', f.trim(df['SELMAILST2']))
df = df.withColumn('SELMAILCITY', f.trim(df['SELMAILCITY']))
df = df.withColumn('SELMAILSTATE', f.trim(df['SELMAILSTATE']))
df = df.withColumn('SELMAILZIP', f.trim(df['SELMAILZIP']))
df = df.withColumn('SELHOMEST1', f.trim(df['SELHOMEST1']))
df = df.withColumn('SELHOMEST2', f.trim(df['SELHOMEST2']))
df = df.withColumn('SELHOMECITY', f.trim(df['SELHOMECITY']))
df = df.withColumn('SELHOMESTATE', f.trim(df['SELHOMESTATE']))
df = df.withColumn('SELHOMEZIP', f.trim(df['SELHOMEZIP']))
df = df.withColumn('Business Address: STATE', f.trim(df['Business Address: STATE']))
df = df.withColumn('Home Address: STATE', f.trim(df['Home Address: STATE']))
df = df.withColumn('SELINTERNET1', f.trim(df['SELINTERNET1']))

df = df.withColumn('SELGIVENNAME', f.trim(df['SELGIVENNAME']))
df = df.withColumn('SELSURFIRMNAME', f.trim(df['SELSURFIRMNAME']))
df = df.withColumn('First Name', f.trim(df['First Name']))
df = df.withColumn('Last Name', f.trim(df['Last Name']))

# COMMAND ----------

df = consistency_check(df, 'LARS_PRODUCER', 'SSNTAXID', 'SSN', 'SELLERNPN', 'NPN')
df = consistency_check(df, 'LARS_PRODUCER', 'SSNTAXID', 'SSN', 'SSNTAXID', 'SSN')

df = consistency_check(df, 'LARS_PRODUCER', 'SSNTAXID', 'SSN', 'SELGIVENNAME', 'First Name')
df = consistency_check(df, 'LARS_PRODUCER', 'SSNTAXID', 'SSN', 'SELSURFIRMNAME', 'Last Name',)

df = consistency_check(df, 'LARS_PRODUCER', 'SSNTAXID', 'SSN', 'SELMAILST1', 'Business Address: Line 1')
# df = consistency_check(df, 'LARS_PRODUCER', 'SSNTAXID', 'SSN', 'SELMAILST2', 'Business Address: Line 2')
df = consistency_check(df, 'LARS_PRODUCER', 'SSNTAXID', 'SSN', 'SELMAILCITY', 'Business Address: City')
df = consistency_check(df, 'LARS_PRODUCER', 'SSNTAXID', 'SSN', 'SELMAILSTATE', 'Business Address: STATE')
df = consistency_check(df, 'LARS_PRODUCER', 'SSNTAXID', 'SSN', 'SELMAILZIP', 'Business Address: Zip Code')
df = consistency_check(df, 'LARS_PRODUCER', 'SSNTAXID', 'SSN', 'SELHOMEST1', 'Home Address: Line 1')
# df = consistency_check(df, 'LARS_PRODUCER', 'SSNTAXID', 'SSN', 'SELHOMEST2', 'Home Address: Line 2')
df = consistency_check(df, 'LARS_PRODUCER', 'SSNTAXID', 'SSN', 'SELHOMECITY', 'Home Address: City')
df = consistency_check(df, 'LARS_PRODUCER', 'SSNTAXID', 'SSN', 'SELHOMESTATE', 'Home Address: STATE')
df = consistency_check(df, 'LARS_PRODUCER', 'SSNTAXID', 'SSN', 'SELHOMEZIP', 'Home Address: Zip Code')

df = consistency_check(df, 'LARS_PRODUCER', 'SSNTAXID', 'SSN', 'SELPHONENO', 'Phone Number')
df = consistency_check(df, 'LARS_PRODUCER', 'SSNTAXID', 'SSN', 'SELINTERNET1', 'Email Address')

# COMMAND ----------

summary_df = get_summary(df)

# COMMAND ----------

uc_write(summary_df)