# Databricks notebook source
# MAGIC %run ../../utils

# COMMAND ----------

configure_spark()
config = {
"container": 'gold',
"parent_dir": 'agency/parquet/DB2AYP',
"asset_name": 'Tayseller',
"work_stream": "Producer",
"data_system": "Agency"
}

df = read_asset(**config)
df= df.where("SELSURFIRMIND == 'S'") #This filter selects for individual sellers and filters out firms, which don't have the same CDEs

# COMMAND ----------

#COMPLETENESS
completeness_check_columns = ['SELHOMECITY', 'SELHOMESTATE', 'SELMAILST1', 'SSNTAXID', 'SELHOMEST1', 'SELLERNPN', 'SELGIVENNAME', 'SELMAILCITY', 'SELSURFIRMNAME', 'SELMAILSTATE']
for column in completeness_check_columns:
    df = completeness_check(df, column)

#UNIQUENESS
uniqueness_check_columns = ['SSNTAXID', 'SELLERNPN']
for column in uniqueness_check_columns:
    df = uniqueness_check(df,column)

#CONFORMITY
df = df.withColumn('Conformity: SELLERNPN',
                f.when(df['SELLERNPN'].rlike(r'^\d{4,10}$'), 'pass: must be between 4-10 digits numeric')
                .when((df['SELLERNPN'] == '')|(df['SELLERNPN'].isNull()),'fail: must not contain null value')              
                .otherwise('fail: must be numeric or must be between 4-10 digits numeric'))

#checking for characters
df = df.withColumn('Conformity: SELMAILZIP',
                 f.when(df['SELMAILZIP'].rlike(r'^.{5,10}$'),'pass: must be  any digit numeric')
                 .when((df['SELMAILZIP'] == '')|(df['SELMAILZIP'].isNull()), 
                 'fail: must not contain null value')              
                 .otherwise('fail: must be numeric or must be 5 digits'))
  
#checking for numbers
# df = df.withColumn('Conformity: SELMAILZIP',
#                 f.when(df['SELMAILZIP'].rlike(r'^\d{5}$'),'pass: must be  5 digit numeric')
#                 .when((df['SELMAILZIP'] == '')|(df['SELMAILZIP'].isNull()), 
#                 'fail: must not contain null value')              
#                 .otherwise('fail: must be numeric or must be 5 digits'))
    
# df = df.withColumn('Conformity: SELHOMEZIP',
#                 f.when(df['SELHOMEZIP'].rlike(r'^\d{5}$'),'pass: must be  5 digit numeric')
#                 .when((df['SELHOMEZIP'] == '')|(df['SELHOMEZIP'].isNull()), 
#                 'fail: must not contain null value')              
#                 .otherwise('fail: must be numeric or must be 5 digits'))
				
df = df.withColumn('Conformity: SSNTAXID', f.when(df['SSNTAXID'].rlike(r'^\d{9}$'), 'pass: Must be 9 digit numeric')
                .when((df['SSNTAXID'] == '')|(df['SSNTAXID'].isNull()),'fail: must not contain null value') 			
				.when(df['SSNTAXID'].rlike(r'^(?!000|666|900|999)\d{3}(?!00)\d{2}(?!0000)\d{4}$'),'pass: Must conform to IRS rules')
				.otherwise('fail: Must be 9 digit numeric'))
				
df = df.withColumn('Conformity: SELPHONENO', f.when(df['SELPHONENO'].rlike(r'^\d{10}$'), 'pass: Must be 10 digit numeric')
                .when((df['SELPHONENO'] == '')|(df['SELPHONENO'].isNull()),'fail: must not contain null value')
                .when(df['SELPHONENO'].rlike(r'(\d)\1{4,}'),'fail: Must not have same repeating Number')
				.when(df['SELPHONENO'].rlike(r'^(?!0|111|123|000)\d{10}$'),'pass: First 3 digits do not match numbers listed and 10 digits') 
				.otherwise('fail: Must be 10 digit numeric'))

#CONSISTENCY
consistency_config = {
"container": 'dataquality',
"parent_dir": 'Producer/_Custom_Views',
"asset_name": 'LARS_PRODUCER',
"primary_key": 'SELLERNPN',
"foreign_key": 'NPN',
"work_stream": "Producer",
"data_system": "Agency"
}

df2 = read_asset(**consistency_config)
df = df.join(df2, df['SELLERNPN'] == df2['NPN'], 'left')


df = df.withColumn('SELLERNPN', f.trim(df['SELLERNPN']))
df = df.withColumn('SSNTAXID', f.trim(df['SSNTAXID']))
df = df.withColumn('SELMAILST1', f.trim(df['SELMAILST1']))
df = df.withColumn('SELMAILST2', f.trim(df['SELMAILST2']))
df = df.withColumn('SELMAILCITY', f.trim(df['SELMAILCITY']))
df = df.withColumn('SELMAILSTATE', f.trim(df['SELMAILSTATE']))
df = df.withColumn('SELMAILZIP', f.trim(df['SELMAILZIP']))
df = df.withColumn('SELHOMEST1', f.trim(df['SELHOMEST1']))
df = df.withColumn('SELHOMEST2', f.trim(df['SELHOMEST2']))
df = df.withColumn('SELHOMECITY', f.trim(df['SELHOMECITY']))
df = df.withColumn('SELHOMESTATE', f.trim(df['SELHOMESTATE']))
df = df.withColumn('SELHOMEZIP', f.trim(df['SELHOMEZIP']))
df = df.withColumn('Business Address: STATE', f.trim(df['Business Address: STATE']))
df = df.withColumn('Home Address: STATE', f.trim(df['Home Address: STATE']))


df = consistency_check(df, 'LARS_PRODUCER', 'SELLERNPN', 'NPN', 'SELLERNPN', 'NPN')
df = consistency_check(df, 'LARS_PRODUCER', 'SELLERNPN', 'NPN', 'SSNTAXID', 'SSN',)
df = consistency_check(df, 'LARS_PRODUCER', 'SELLERNPN', 'NPN', 'SELMAILST1', 'Business Address: Line 1')
df = consistency_check(df, 'LARS_PRODUCER', 'SELLERNPN', 'NPN', 'SELMAILST2', 'Business Address: Line 2')
df = consistency_check(df, 'LARS_PRODUCER', 'SELLERNPN', 'NPN', 'SELMAILCITY', 'Business Address: City')
df = consistency_check(df, 'LARS_PRODUCER', 'SELLERNPN', 'NPN', 'SELMAILSTATE', 'Business Address: STATE')
df = consistency_check(df, 'LARS_PRODUCER', 'SELLERNPN', 'NPN', 'SELMAILZIP', 'Business Address: Zip Code')
df = consistency_check(df, 'LARS_PRODUCER', 'SELLERNPN', 'NPN', 'SELHOMEST1', 'Home Address: Line 1')
df = consistency_check(df, 'LARS_PRODUCER', 'SELLERNPN', 'NPN', 'SELHOMEST2', 'Home Address: Line 2')
df = consistency_check(df, 'LARS_PRODUCER', 'SELLERNPN', 'NPN', 'SELHOMECITY', 'Home Address: City')
df = consistency_check(df, 'LARS_PRODUCER', 'SELLERNPN', 'NPN', 'SELHOMESTATE', 'Home Address: STATE')
df = consistency_check(df, 'LARS_PRODUCER', 'SELLERNPN', 'NPN', 'SELHOMEZIP', 'Home Address: Zip Code')

df = df.drop(*df2.columns)

# COMMAND ----------

summary_df = get_summary(df, None, **config)

# COMMAND ----------

failed_rows_df = get_failed_rows(df)

# COMMAND ----------

save_parquet_results(failed_rows_df, summary_df, **config)
