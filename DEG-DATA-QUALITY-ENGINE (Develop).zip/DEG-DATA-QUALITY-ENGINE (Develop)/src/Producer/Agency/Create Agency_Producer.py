# Databricks notebook source
# MAGIC  %run ../../utils

# COMMAND ----------

# configure_spark()
# config = {
#     "container": 'gold',
#     "parent_dir": 'agency/parquet/DB2AYP',
#     'asset_name': 'AGENCY_PRODUCER',
#     'work_stream': 'Producer',
#     'data_system': 'Agency'
# }
# container = 'gold'
# parent_dir = 'agency/parquet/DB2AYP'
# adls_stem = f'abfss://{container}@{PROD_ADLS_STORAGE_ACCOUNT}.dfs.core.windows.net/{parent_dir}'


configure_spark()
config = {
    "container": 'gold',
    "parent_dir": 'agency/parquet/DB2AYP',
    'asset_name': '',
    'work_stream': 'Producer',
    'data_system': 'Agency',
    "data_owner": "Amanda Murphy",
    "business_unit": "Life",
    "data_domain": "Producer & Distributor",
    "rule_owner": "Amanda Murphy"
}


# COMMAND ----------

# tayseller = spark.read.parquet(f'{adls_stem}/Tayseller', header = 'True')
# tayseller.createOrReplaceTempView('Tayseller')
# tayseller = spark.sql(
#     """
#     SELECT SELLERID, SSNTAXID, SELSURFIRMNAME, SELGIVENNAME, SELSURFIRMIND, SELHOMEST1, SELHOMEST2, SELHOMEST3, SELHOMECITY, SELHOMESTATE, SELHOMEZIP, SELMAILST1, SELMAILST2, SELMAILST3, SELMAILCITY, SELMAILSTATE, SELMAILZIP, SELPHONENO, SELHOUSEDIND, SELUSRESIND, SELCELLPHONE, SELFAXNO, SELINTERNET1, SELRESTRICTED, SELUPDDATE, SELUSERID, SELLERNPN
#     FROM TAYSELLER
#     WHERE SELSURFIRMNAME == 'S'
#     """ 
# )
# tayseller.createOrReplaceTempView('Tayseller')

# COMMAND ----------

#same as above
# tayseller = spark.read.parquet(f'{adls_stem}/Tayseller', header = 'True')
config['asset_name'] = 'Tayseller'
tayseller = read_asset(**config)
tayseller.createOrReplaceTempView('Tayseller')
tayseller = spark.sql(
    """
    SELECT SELLERID, SSNTAXID, SELLERNPN, SELSURFIRMNAME, SELGIVENNAME, SELSURFIRMIND, SELINITIALS, SELHOMEST1, SELHOMEST2, SELHOMEST3, SELHOMECITY, SELHOMESTATE, SELHOMEZIP, SELMAILST1, SELMAILST2, SELMAILST3, SELMAILCITY, SELMAILSTATE, SELMAILZIP, SELSHORTNAME, SELPHONENO, SELHOUSEDIND, SELUSRESIND, SELCELLPHONE, SELFAXNO, SELPAGERNO, SELINTERNET1, SELINTERNET2, SELCONVERTIND, SELREGISTIND, SELW8IND, SELW8EXPDATE, SELW9IND, SELRESTRICTED, SELUPDDATE, SELUSERID, CONTACTNAME1, ROLE1, TEL1, EMAIL1, CONTACTNAME2, ROLE2, TEL2, EMAIL2, CONTACTNAME3, ROLE3, TEL3, EMAIL3, CONTACTNAME4, ROLE4, TEL4, EMAIL4
    FROM TAYSELLER
    WHERE SELSURFIRMIND = 'S'
    """
)
tayseller.createOrReplaceTempView('Tayseller')


# COMMAND ----------

#with status option

#tayslstat = spark.read.parquet(f'{adls_stem}/Tayslstat', header = 'True')
#tayslstat.createOrReplaceTempView('Tayslstat')
#tayslstat = spark.sql(
#    """
#    SELECT DISTINCT SELLERID, SLSTATEFFDTE, SELSTATUS
#    FROM TAYSLSTAT t1
#    WHERE SELSTATUS = 'DISABLED  '
#        AND SLSTATEFFDTE = (
#        SELECT MAX(SLSTATEFFDTE)
#        FROM TAYSLSTAT t2
#        WHERE t1.SELLERID = t2.SELLERID
#    )
#    """
#)
#tayslstat.createOrReplaceTempView('Tayslstat')

# COMMAND ----------

# tayslstat = spark.read.parquet(f'{adls_stem}/Tayslstat', header = 'True')

config['asset_name'] = 'Tayslstat'
tayslstat = read_asset(**config)


tayslstat.createOrReplaceTempView('Tayslstat')
tayslstat = spark.sql(
    """
    SELECT DISTINCT SELLERID, SLSTATEFFDTE, SELSTATUS
    FROM TAYSLSTAT t1
    WHERE SLSTATEFFDTE = (
        SELECT MAX(SLSTATEFFDTE)
        FROM TAYSLSTAT t2
        WHERE t1.SELLERID = t2.SELLERID
    )
    """
)
tayslstat.createOrReplaceTempView('Tayslstat')

# COMMAND ----------

seller_id = tayslstat.join(tayseller, ['SELLERID'], 'inner')
#seller_id = seller_id.withColumnRenamed('SELLERID', 'Seller ID')
#seller_id = seller_id.withColumnRenamed('SELSTATUS', 'Status')
#seller_id = seller_id.withColumnRenamed('SLSTATEFFDTE', 'Status Date')
#seller_id = seller_id.withColumnRenamed('SSNTAXID', 'SSN')

# COMMAND ----------

df = seller_id

# COMMAND ----------

df = df.withColumn('SELLERNPN', f.regexp_replace(df['SELLERNPN'], r'\.0*$', ''))

# COMMAND ----------

df.write.mode("overwrite").parquet(f"abfss://dataquality@{ENV['storage_account']}.dfs.core.windows.net/Producer/_Custom_Views/AGENCY_PRODUCER")
