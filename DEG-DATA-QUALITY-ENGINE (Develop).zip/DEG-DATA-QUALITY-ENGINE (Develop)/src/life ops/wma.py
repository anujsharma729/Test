# Databricks notebook source
# MAGIC %run ../utils

# COMMAND ----------

# MAGIC %run ../rules

# COMMAND ----------

# MAGIC %run ./life_utils

# COMMAND ----------

try:
    config['data_system'] = 'wma'
    df = uc_read('silver_wma_fullfidelity', 'cpe001_client')

    cdes = ['CP_PRD_LINE_CD', 'CP_POL_NO', 'CP_CL_FIRST_NM', 'CP_CL_LAST_NM', 'CP_CL_ADDR_LINE1', 'CP_CLIENT_CITY', 'CP_CLIENT_STATE', 'CP_CLIENT_ZIP5', 'CP_CLIENT_BIRTH_DT', 'CP_CLIENT_SSN_TAX_ID']
    roles = ['CP_CLIENT_INSURED_IND', 'CP_CLIENT_PAYOR_IND', 'CP_CLIENT_OWNER_IND', 'CP_CLIENT_BENE_IND']
    df = df.select(*cdes,*roles).distinct()

    df = clean(df)
    rule = "must contain non null value"
    for column in cdes:
        df = df.withColumn(f'Completeness: {column}', f.when((((df['CP_CLIENT_INSURED_IND']== 'Y') | (df['CP_CLIENT_PAYOR_IND']== 'Y') | (df['CP_CLIENT_OWNER_IND']== 'Y') | (df['CP_CLIENT_BENE_IND']== 'Y')) & (df[column].isNull())), f'fail: {rule}').otherwise(f'pass: {rule}'))



    s1 = get_summary(df)
    uc_write(s1)
except Exception as e:
    print(e)

# COMMAND ----------

