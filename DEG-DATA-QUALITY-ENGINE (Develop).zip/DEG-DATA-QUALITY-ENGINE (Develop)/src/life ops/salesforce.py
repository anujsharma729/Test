# Databricks notebook source
# MAGIC %run ../utils

# COMMAND ----------

# MAGIC %run ../rules

# COMMAND ----------

# MAGIC %run ./life_utils

# COMMAND ----------

active_statuses = ['Inforce Premium Paying', 'Paid-Up', 'Reduced Paid-Up', 'Active Guaranteed', 'Extended Term', 'Lapse Pending', 'Pending Death', 'Open', 'Pending Matured', 'Inforce Waiver', 'Do Not Quote', 'Do Not Illustrate', 'Vanish Prem Active', 'Policy Frozen', 'Inforce', 'Paid Up by Death', 'Extended Coverage', 'Partial Acceleration', 'Active Freelook','Full Acceleration', 'Maturity Extended', 'Death Claim Pending', 'activ']

# COMMAND ----------

try:
    config['data_system'] = 'salesforce_life'
    prc = uc_read('silver_salesforce_life_full_fidelity', 'policy_role__c')
    pcc = uc_read('silver_salesforce_life_full_fidelity', 'Policy_Contract__c')
    acc = uc_read('silver_salesforce_life_full_fidelity', 'Account')

    acc_col = ['Id', 'FirstName', 'LastName','LFOPS_Contact_Full_Name__pc','LFOPS_Full_Name__pc', 'IsPersonAccount', 'LFOPS_Email_Address__c','SSN_Suffix__pc', 'SSN_encrypted__pc', 'PersonBirthdate', 'Phone_Number_Day__c', 'LFOPS_SSN_Suffix_TIN_Suffix__c']
    prc_col = ['Id','Account__c','Policy_Contract__c','LFOPS_Policy_Admin_System__c','LFOPS_Primary_Address__c', 'Role_Status__c', 'Role_Type__c']
    pcc_col = ['Id','Admin_Key__c','Admin_System_Name__c', 'Name','Beneficiary_Roles_Count__c','Contract_Status__c', 'Contract_Number__c', 'Current_Admin_System__c', 'LFOPS_Plan_Code__c', 'LFOPS_Policy_Insured__c', 'Policy_Owner__c', 'LFOPS_Policy_Insured__c']
    roles = ['Own002-Owner', 'Insured', 'Beneficiary', 'Payor', 'Primary Beneficiary', 'Secondary Beneficiary', 'INS002-Insured']

    acc = acc.select(*acc_col)
    prc = prc.select(*prc_col)
    pcc = pcc.select(*pcc_col)

    acc = acc.withColumnRenamed('Id', 'Id_acc')
    prc = prc.withColumnRenamed('Id', 'Id_prc')
    pcc = pcc.withColumnRenamed('Id', 'Id_pcc')

    df = prc.join(acc, acc.Id_acc == prc.Account__c, 'left').join(pcc, prc.Policy_Contract__c == pcc.Id_pcc, 'left')

    df = df.filter(df['Contract_Status__c'].isin(active_statuses))
    for column in ['LFOPS_Email_Address__c','SSN_Suffix__pc', 'PersonBirthdate', 'Phone_Number_Day__c','FirstName', 'LastName']:
        df = completeness_with_list_dependency(df, column, 'Role_Type__c', roles)

    df = conformity_email(df, 'LFOPS_Email_Address__c')
    s1 = get_summary(df)
    uc_write(s1)
except Exception as e:
    print(e)


# COMMAND ----------

try:
    df = uc_read('silver_salesforce_life_full_fidelity', 'address__c')
    rule = "must contain non null value for address type: primary residence, mailing or business"
    for column in ['Address_Line_1__c','City__c', 'Country__c', 'Zip_Code__c','State__c']:
        df = completeness_with_list_dependency(df, column, 'Address_Usage_Type__c', ['Primary Residence', 'Mailing', 'Business'], rule)

    s1 = get_summary(df)
    uc_write(s1)
except Exception as e:
    print(e)