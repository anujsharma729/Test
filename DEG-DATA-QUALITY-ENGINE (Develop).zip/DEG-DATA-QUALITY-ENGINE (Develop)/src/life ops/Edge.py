# Databricks notebook source
# MAGIC %run ../utils

# COMMAND ----------

# MAGIC %run ../rules

# COMMAND ----------

pclient_columns = ['PCLI_ID','COMP_ID','PCLI_TYP_CD','BRTH_STPR_CD','OCC_TYP_CD','PCLI_FULL_NM','PCLI_TIN_NUM','PCLI_DLIC_NUM','PCLI_EMAIL_ADDR_TXT','CTRY_CD','EMPLOYER_NM','JH_PCLI_JOB_DUTIES']
pclient = uc_read('silver_edge', 'pclient').select(pclient_columns)

# COMMAND ----------

pclient = pclient.filter(
        (f.col('PCLI_TYP_CD') == 'Insured'))
pclient = pclient.withColumnRenamed('PCLI_TIN_NUM', 'SSN').withColumnRenamed('PCLI_EMAIL_ADDR_TXT', 'Email Address').withColumn('SSN', f.regexp_replace(f.col('SSN'), "-", ""))

# COMMAND ----------

pclient = uniqueness_check(pclient, 'SSN')
pclient = uniqueness_check(pclient, 'Email Address')
pclient = conformity_ssn(pclient, 'SSN')
pclient = conformity_email(pclient, 'Email Address')
pclient = accuracy_ssn(pclient, 'SSN')

# COMMAND ----------

display(pclient)

# COMMAND ----------

config['work_stream']   = 'life ops'
config['data_system']   = 'Edge'
config['asset_name'] = 'pclient'
config['data_owner'] = 'Sarah Young'
config['business_unit'] = 'Life (US)'
config['data_domain'] = 'New Business'
config['rule_owner'] = 'Mara Young'
summary_df = get_summary(pclient)

# COMMAND ----------

display(summary_df)

# COMMAND ----------

pclient_filtered = pclient.filter(pclient["Conformity: Email Address"]=="fail: must adhere to email format (example@gmail.com)")
pclient_filtered = pclient_filtered.drop("Uniqueness: SSN","Accuracy: SSN","Uniqueness: Email Address","Conformity: SSN")
display(pclient_filtered)

# COMMAND ----------

corrected_email = f.col("Email Address")

corrected_email = f.regexp_replace(corrected_email, r"^[\s\t\n\r\x0B\xA0]+|[\s\t\n\r\x0B\xA0]+$", "")
corrected_email = f.regexp_replace(corrected_email, "(?i),(com)", ".$1")
corrected_email = f.regexp_replace(corrected_email, ",$", "")
corrected_email = f.when((f.lower(corrected_email).rlike("^(http|https|www\\.)")),
f.lit(None).cast("string")).otherwise(corrected_email)

corrected_email = f.when(f.lower(f.split(corrected_email, "@").getItem(0)).contains("n/a"),f.lit(None).cast("string")).otherwise(corrected_email)

corrected_email = f.regexp_replace(corrected_email, "(?i)([^.])(com)$", "$1.$2")

corrected_email = f.when(corrected_email.contains("@") & (f.length(f.split(corrected_email, "@").getItem(0)) < 5) & (f.length(f.split(corrected_email, "@").getItem(1)) < 5),f.lit(None).cast("string")).otherwise(corrected_email)

corrected_email = f.when(~corrected_email.contains("@") & f.lower(corrected_email).rlike("ext\\.?\\s*\\d+"),f.lit(None).cast("string")).otherwise(corrected_email)

corrected_email = f.when(~corrected_email.contains("@") & corrected_email.rlike("^\\d+$"),f.lit(None).cast("string")).otherwise(corrected_email)

pclient_filtered = pclient_filtered.withColumn("Corrected Email Address", corrected_email)

display(pclient_filtered)