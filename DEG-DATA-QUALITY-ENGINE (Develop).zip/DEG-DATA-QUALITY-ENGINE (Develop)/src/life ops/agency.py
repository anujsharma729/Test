# Databricks notebook source
# MAGIC %run ../utils

# COMMAND ----------

# MAGIC %run ../rules

# COMMAND ----------

# MAGIC %run ./life_utils

# COMMAND ----------

try:
    config['data_system'] = 'agency'
    tayslstat  = uc_read('silver_agency','tayslstat')
    tayseller  = uc_read('silver_agency','tayseller')

    tayseller_cols=['SELLERID', 'SELSURFIRMNAME', 'SELGIVENNAME', 'SELHOMEST1', 'SELHOMECITY', 'SELHOMESTATE', 'SELHOMEZIP','SELPHONENO', 'EMAIL1','SELSURFIRMIND']
    tayslstat_cols = ['SELLERID', 'SLSTATEFFDTE', 'SELSTATUS']

    tayseller = tayseller.select(tayseller_cols)
    window_spec = Window.partitionBy("SELLERID").orderBy(f.desc("SLSTATEFFDTE"))
    tayslstat = tayslstat.withColumn("row_num", f.row_number().over(window_spec)).filter(f.col("row_num") == 1).drop("row_num")
    df = tayslstat.join(tayseller, ['SELLERID'], 'inner')

    df = clean(df)
    # df = df.withColumn('role', f.when(df.SELSURFIRMIND== 'S', 'Agent').when(df.SELSURFIRMIND== 'F', 'Firm'))

    for column in ['SELHOMEST1', 'SELHOMECITY', 'SELHOMESTATE', 'SELHOMEZIP','SELPHONENO']: #SELINTERNET1', 'SELINTERNET2',
        df = completeness_check(df, column)
    df = completeness_with_dependency(df, 'SELGIVENNAME', 'SELSURFIRMIND', 'S', "must contain non null value for agents")
    df = completeness_with_dependency(df, 'SELSURFIRMNAME', 'SELSURFIRMIND', 'F', "must contain non null value for firms")
    df = conformity_email(df, 'EMAIL1')
    df = df.withColumn('Accuracy: SELHOMEST1', f.when(df.SELHOMEST1 == 'NOT AVAILABLE',"fail: must contain address information").otherwise("pass: must contain address information"))

    s1 = get_summary(df)
    uc_write(s1)
except Exception as e:
    print(e)

# COMMAND ----------

display(s1)