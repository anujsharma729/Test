# Databricks notebook source
# MAGIC %run ../utils

# COMMAND ----------

# MAGIC %run ../rules

# COMMAND ----------

# MAGIC %run ./life_utils

# COMMAND ----------

try:   
    config['data_system'] = 'vpasone'
    vpas = uc_read('silver_vpasone_alpha', 'alphasync')
    vpas_active_status = ['Inforce Premium Paying', 'Paid-Up']
    vpas_cols =['Policy', 'OriginalPolicyNumber', 'PolicyStatus', 'TerminationDate', 'RelationCode', 'EffDate', 'NameID', 'CompanyName', 'CompanyType', 'FirstName', 'MiddleName', 'LastName','Individual/Company', 'Gender', 'DOB', 'SSN', 'TaxNumber', 'DateOfDeath',  'BusinessPhone', 'CellularPhone', 'DigitalPhone', 'ResidencePhone', 'Email', 'BusinessLine1', 'BusinessCity', 'BusinessState', 'BusinessZip', 'BusinessCountry', 'ResidenceLine1','ResidenceCity', 'ResidenceState', 'ResidenceZip', 'ResidenceCountry', 'BenerelationshiptoInsured', 'AgentID', 'AgentType']

    df = vpas.select(*vpas_cols)

    for c in df.columns:
        df = df.withColumn(c, f.upper(f.trim(f.col(c))))
        df = df.withColumn(c, f.when((f.col(c) == "") | (f.col(c) == "?") |(f.col(c).rlike(r"^(0[\s]?){1,}$")), None).otherwise(f.col(c)))

    vpas_role_cde_map = {
        'OWNER': ['FirstName', 'LastName','Full', 'DOB', 'SSN', 'Tax', 'Residence', 'AgentID', 'Email'],
        'INSUR': ['FirstName', 'LastName','Full', 'DOB', 'SSN', 'Contract', "Plan_Code", 'AgentID', 'Email'],
        'BENE': ['FirstName', 'LastName','Full', 'Email', 'EffDate', 'AgentID', 'Email'],
        'AGENT': ['Policy', 'EffDate', 'AgentID'],
        'PAYOR': ['FirstName', 'LastName','Full', 'Residence', 'AgentID', 'Email']
    }

    for column in ['FirstName', 'LastName', 'DOB', 'Gender','SSN', 'ResidenceLine1', 'ResidenceCity', 'ResidenceState', 'ResidenceZip']:
        df = completeness_with_dependency(df, column, 'Individual/Company', 'I')

    for column in ['CompanyName', 'BusinessPhone', 'BusinessLine1', 'BusinessCity', 'BusinessState', 'BusinessZip']:
        df = completeness_with_dependency(df, column, 'Individual/Company', 'C')

    df = conformity_email(df, 'Email')
    df = uniqueness_check(df,['Policy', 'RelationCode', 'NameID', 'AgentID', 'AgentType'])

    s1 = get_summary(df)
    uc_write(s1)
except Exception as e:
    print(e)

# COMMAND ----------

