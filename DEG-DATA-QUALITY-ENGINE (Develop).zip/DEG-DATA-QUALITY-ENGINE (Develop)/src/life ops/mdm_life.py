# Databricks notebook source
# MAGIC %run ../utils

# COMMAND ----------

# MAGIC %run ../rules

# COMMAND ----------

# MAGIC %run ./life_utils

# COMMAND ----------

# def conformity_check_dependency(df,column, dep_col, dep_values, rules):

#     df = withColumn(f'Conformity: {column}', f.when(df[dep_col]))




# df = df.withColumn(f'Conformity: REFERENCE_NUMBER',  f.when(f.col('REFERENCE_NUMBER').contains(" "), 'fail: must adhere to expected format')
#     .when(f.col('REFERENCE_NUMBER').rlike(r'[\u00A0\u1680\u180E\u2000-\u200A\u202F\u205F\u3000\u200B\u2060\uFEFF]'),'pass: must not contain non-breaking space')
#     .when(f.col('REFERENCE_NUMBER').rlike(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'),'pass: must adhere to expected format')
#     .when(f.col('REFERENCE_NUMBER').isNull(), 'pass: must adhere to expected format')
#     .otherwise('fail: must adhere to expected format'))

# COMMAND ----------

from pyspark.sql import functions as f

def conformity_check_rule_dependency(df, dependency_col, rules, rule_value, result_col='rule_check', default_value='default'):
    condition_expr = None

    for dep_value, rule_condition in rules.items():
        cond = f.when(
            f.col(dependency_col) == dep_value,
            f.when(rule_condition, f'pass: {rule_value}')
             .otherwise(f'fail: {rule_value}')
        )
        condition_expr = cond if condition_expr is None else condition_expr.otherwise(cond)

    if condition_expr is None:
        condition_expr = f.lit(default_value)

    return df.withColumn(result_col, condition_expr)

# COMMAND ----------



def uc_read(asset):
    df = spark.sql(f"SELECT * FROM usdo_prod_catalog.silver_azsqlmi_life_mdm.{asset}")
    config['parent_dir'] = f"usdo_prod_catalog.silver_azsqlmi_life_mdm.{asset}"
    config['asset_name'] = asset 
    return df

def conformity_check_rule_dependency(df, dependency_col, rules, rule_value, result_col = 'rule_check', default_value = 'default'):
    condition_expr = None
    for dep_value, rule_condition in rules.items():
        cond = f.when(
            f.col(dependency_col) == dep_value, 
            f.when(rule_condition, f'pass: {rule_value}').otherwise(f'fail: {rule_value}')
        )
        condition_expr = cond if condition_expr is None else condition_expr.otherwise(cond)
    if condition_expr is None:
        condition_expr = f.lit(default_value)

    return df.withColumn(result_col, condition_expr)

# rules = {
#     "1" : f.col('REFERENCE_NUMBER').rlike(r'^\d{10}$'),
#     "2" : f.col('REFERENCE_NUMBER').rlike(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'),

# }

rules = {
    "1": f.col('REFERENCE_NUMBER').isNull() | 
         f.col('REFERENCE_NUMBER').rlike(r'^\d{10}$'),

    "2": f.col('REFERENCE_NUMBER').isNull() | 
         f.col('REFERENCE_NUMBER').rlike(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$')
}


# COMMAND ----------

#BU
cm = uc_read('bucontactmethod').select('CM_ID_PK', 'CONTACT_METHOD_TYPE_CODE', 'REFERENCE_NUMBER', 'LAST_UPDATE_DT', 'LAST_UPDATE_USER', 'PARTY_ID_PK')
p = uc_read('bupersoninfo')
policy = uc_read('bupolicy')
party_role = uc_read('bupolicypartyrole')

#LU
cr = uc_read('lucontmethtypecode').select('CONTACT_METHOD_TYPE_CODE', 'TYPE_CODE_VALUE')
role_type = uc_read('luroletypecode').select('ROLE_TYPE_CODE', 'TYPE_CODE_VALUE').withColumnRenamed('TYPE_CODE_VALUE', 'ROLE_TYPE')
pstatus = uc_read('lupolicystatustypecode').select('POLICY_STATUS_TYPE_CODE', 'TYPE_CODE_VALUE').withColumnRenamed('TYPE_CODE_VALUE', 'POLICY_STATUS')
policy_src_sys = uc_read('lusrcsystypecode').select('SRC_SYS_TYPE_CODE', 'TYPE_CODE_VALUE2').withColumnRenamed('TYPE_CODE_VALUE2', 'SOURCE_SYSTEM')
cm = (cm.orderBy(col("LAST_UPDATE_DT").desc()).dropDuplicates(["PARTY_ID_PK"]))
p = (p.orderBy(col("LAST_UPDATE_DT").desc()).dropDuplicates(["PARTY_ID_PK"]))
party_role = (party_role.orderBy(col("LAST_UPDATE_DT").desc()).dropDuplicates(["PARTY_ID_PK"]))

policy = policy.join(party_role, on='POLICY_ID_PK', how='left').join(pstatus, on='POLICY_STATUS_TYPE_CODE', how='left').join(role_type, on='ROLE_TYPE_CODE', how='left').join(policy_src_sys, on='SRC_SYS_TYPE_CODE', how='left').distinct()

#CONTACT METHOD
try:
    config['asset_name'] = 'bucontactmethod'
    df = cm.join(cr, on='CONTACT_METHOD_TYPE_CODE', how='left')
    df = clean(df)
    df = df.withColumn('REFERENCE_NUMBER', f.when(df.CONTACT_METHOD_TYPE_CODE == '1',f.regexp_replace('REFERENCE_NUMBER', r"[-() ]", "")).otherwise(df.REFERENCE_NUMBER))
    rule_value = 'must contain value in correct format as indicated in contact_method_type_code'
    df = conformity_check_rule_dependency(df, 'CONTACT_METHOD_TYPE_CODE', rules,rule_value, result_col="Conformity: REFERENCE_NUMBER")
    s1 = get_summary(df)
    uc_write(s1)
except Exception as e:
    print(e)

try:
    config['asset_name'] = 'bupersoninfo'
    df = p.select('PARTY_ID_PK', 'GIVEN_NAME_ONE', 'LAST_NAME', 'SSN', 'BIRTH_DT', 'GENDER').distinct()
    df = clean(df)
    for column in ['GIVEN_NAME_ONE', 'LAST_NAME']:
        df = completeness_check(df, column)

    s1 = get_summary(df)
    uc_write(s1)
except Exception as e:
    print(e)   

#ROLE & POLICY BASED RULES
try:
    df = p.join(policy, on='PARTY_ID_PK', how='inner').select('PARTY_ID_PK','GIVEN_NAME_ONE', 'LAST_NAME', 'SSN', 'BIRTH_DT','DECEASED_DT', 'GENDER','POLICY_NUM', 'TERMINATION_DT', 'ISSUE_DT',   'POLICY_STATUS', 'ROLE_TYPE', "SOURCE_SYSTEM").distinct()
    df = completeness_with_list_dependency(df, 'SSN', 'ROLE_TYPE', ['Insured Primary','Insured Rider', 'Ins001-Life Insured','Ins002-Life Insured'])
    df = completeness_with_list_dependency(df, 'BIRTH_DT', 'ROLE_TYPE', ['Insured Primary','Insured Rider', 'Ins001-Life Insured','Ins002-Life Insured'])
    df = df.withColumn('Accuracy: POLICY_STATUS', f.when((df.POLICY_STATUS.isin(['Reinstated', 'Active', 'Reinstated'])) & (df.ROLE_TYPE.isin(['Insured Primary','Insured Rider', 'Ins001-Life Insured','Ins002-Life Insured'])) & (df.DECEASED_DT.isNotNull()), 'fail: insured on active policy must not have death date').otherwise('pass: insured on active policy must not have death date'))

    # display(df)
    s1 = get_summary(df)
    uc_write(s1)
except Exception as e:
    print(e)



# COMMAND ----------

#BU

try:
    address = uc_read('buaddressinfo')
    addresslink = uc_read("bupartyaddresslink").select('ADDR_ID_PK', 'ADDR_TYPE_CODE').distinct()
    #LU
    addrtype = uc_read('luaddrtypecode').select('ADDR_TYPE_CODE', 'TYPE_CODE_VALUE').distinct()
    statetype = uc_read('luprovstatetypecode').select('PROV_STATE_TYPE_CODE', 'TYPE_CODE_VALUE').distinct().withColumnRenamed('TYPE_CODE_VALUE', 'STATE')

    df = address.join(addresslink, on='ADDR_ID_PK', how="left").join(addrtype, on='ADDR_TYPE_CODE', how='left').join(statetype, on='PROV_STATE_TYPE_CODE', how='left').distinct()
    df = completeness_check(df, 'ADDR_LINE_ONE')
    df = completeness_check(df, 'CITY_NAME')
    df = completeness_check(df, 'STATE')
    df = completeness_check(df, 'POSTAL_CODE')

    df = conformity_addr1(df, 'ADDR_LINE_ONE')
    df = conformity_addr2(df, 'ADDR_LINE_TWO')
    df = conformity_addr3(df, 'ADDR_LINE_THREE')
    df = conformity_city(df, 'CITY_NAME')
    df = conformity_state(df, 'STATE')
    df = conformity_postalcode(df, 'POSTAL_CODE')
    config['asset_name'] ='buaddressinfo'
    s1 = get_summary(df)
    uc_write(s1)
except Exception as e:
    print(e)
