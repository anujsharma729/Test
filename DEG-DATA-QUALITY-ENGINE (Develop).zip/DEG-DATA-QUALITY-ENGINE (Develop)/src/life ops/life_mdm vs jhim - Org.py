# Databricks notebook source
# MAGIC %run ../utils

# COMMAND ----------

# MAGIC %run ../rules

# COMMAND ----------

jhim_df_org = spark.sql(
"""
WITH CUSTOMER AS 
(SELECT CUSTOMER_TT_SEQ_NUM,PARTY_ID,ORG_NM AS NAME,PARTY_TYPE_CD,TIN FROM (SELECT ROW_NUMBER() OVER (PARTITION BY PARTY_ID ORDER BY NM_LAST_UPDATE_DT DESC) AS PARTY_RANK,* FROM (SELECT CUSTOMER_TT_SEQ_NUM,PARTY_ID,ORG_NM,PARTY_TYPE_CD,TRIM(regexp_replace(regexp_replace(TIN,' ',''),"-",'')) AS TIN,NM_LAST_UPDATE_DT FROM usdo_prod_catalog.silver_azsqlmi_jhim_cdl.customer_tt WHERE TRIM(regexp_replace(regexp_replace(TIN,' ',''),"-",'')) IS NOT NULL AND PARTY_TYPE_CD = 'O')) WHERE PARTY_RANK = 1),

ADDRESS AS 
(SELECT ADDRESS_TT_SEQ_NUM,ADDRESS_ID,UPPER(ADDR_LINE_1) AS ADDR_LINE_1,UPPER(ADDR_LINE_2) AS ADDR_LINE_2,UPPER(ADDR_LINE_3) AS ADDR_LINE_3,UPPER(CITY_NM) AS CITY_NM,COUNTRY_NM,ZIP_CD,STATE_CD,STATE_NM,ADDRESS_HASH FROM usdo_prod_catalog.silver_azsqlmi_jhim_cdl.address_tt),

CUST_REL AS
(SELECT * FROM (SELECT ROW_NUMBER() OVER (PARTITION BY CUSTOMER_TT_SEQ_NUM,ADDR_USAGE_TP_CD ORDER BY NVL(END_DT,'9999-12-31 23:59:59.999') DESC) AS REL_RANK,NVL(END_DT,'9999-12-31 23:59:59.999') AS UPD_END_DT,* FROM usdo_prod_catalog.silver_azsqlmi_jhim_cdl.party_addr_usage_tt) WHERE REL_RANK = 1),

COMB(
SELECT DISTINCT PARTY_TYPE_CD,NAME,TIN,
ADDR_LINE_1,ADDR_LINE_2,ADDR_LINE_3,CITY_NM,ZIP_CD,STATE_NM,COUNTRY_NM
FROM CUSTOMER CUST INNER JOIN CUST_REL CUST_REL ON TRIM(CUST.CUSTOMER_TT_SEQ_NUM) = TRIM(CUST_REL.CUSTOMER_TT_SEQ_NUM)
INNER JOIN ADDRESS ADDR ON TRIM(ADDR.ADDRESS_TT_SEQ_NUM) = TRIM(CUST_REL.ADDRESS_TT_SEQ_NUM))

SELECT ROW_NUMBER() OVER (PARTITION BY NAME,TIN ORDER BY NAME,TIN,ADDR_LINE_1,ADDR_LINE_2) AS ADDR_RANK_JHIM,PARTY_TYPE_CD,NAME,TIN AS JHIM_TIN,ADDR_LINE_1 AS ADDR_LINE_1_JHIM,ADDR_LINE_2 AS ADDR_LINE_2_JHIM,ADDR_LINE_3 AS ADDR_LINE_3_JHIM,CITY_NM AS CITY_NM_JHIM,ZIP_CD AS ZIP_CD_JHIM,STATE_NM AS STATE_NM_JHIM,COUNTRY_NM AS CNTRY_NM_JHIM FROM (SELECT ROW_NUMBER() OVER (PARTITION BY NAME,TIN,ADDR_LINE_1,ADDR_LINE_2,ADDR_LINE_3,CITY_NM,ZIP_CD ORDER BY NAME,ADDR_LINE_1,ADDR_LINE_2,ADDR_LINE_3,CITY_NM,ZIP_CD,STATE_NM,COUNTRY_NM DESC) AS RANK,* FROM COMB) WHERE RANK = 1

"""
    
)

# COMMAND ----------

display(jhim_df_org)

# COMMAND ----------

life_mdm_df_org = spark.sql(
"""
WITH PARTY AS
(SELECT * FROM (SELECT PARTY_ID_PK,'O' AS PARTY_TYPE_CD,ORG_NAME AS NAME,TRIM(regexp_replace(regexp_replace(TIN,' ',''),"-",'')) AS TIN FROM usdo_prod_catalog.silver_azsqlmi_life_mdm.buorginfo WHERE TRIM(regexp_replace(regexp_replace(TIN,' ',''),"-",'')) IS NOT NULL)),

ADDR AS
(SELECT ADDR.ADDR_ID_PK,UPPER(ADDR.ADDR_LINE_ONE) AS ADDR_LINE_ONE,UPPER(ADDR.ADDR_LINE_TWO) AS ADDR_LINE_TWO,UPPER(ADDR.ADDR_LINE_THREE) AS ADDR_LINE_THREE,UPPER(ADDR.CITY_NAME) AS CITY_NAME,ADDR.PROV_STATE_TYPE_CODE,ADDR.POSTAL_CODE,ADDR.COUNTRY_TYPE_CODE,CTRY.TYPE_CODE_VALUE AS CNTRY_NM,PROV.TYPE_CODE_VALUE AS STATE_NM FROM usdo_prod_catalog.silver_azsqlmi_life_mdm.buaddressinfo ADDR LEFT JOIN usdo_prod_catalog.silver_azsqlmi_life_mdm.lucountrytypecode CTRY ON ADDR.COUNTRY_TYPE_CODE = CTRY.COUNTRY_TYPE_CODE LEFT JOIN usdo_prod_catalog.silver_azsqlmi_life_mdm.luprovstatetypecode PROV ON ADDR.PROV_STATE_TYPE_CODE = PROV.PROV_STATE_TYPE_CODE),

PARTY_REL AS
(SELECT * FROM (SELECT ROW_NUMBER() OVER (PARTITION BY PARTY_ID_PK ORDER BY LAST_UPDATE_DT DESC) AS RANK,PARTY_ADDR_LINK_ID_PK,PARTY_ID_PK,ADDR_ID_PK,ADDR_TYPE_CODE FROM usdo_prod_catalog.silver_azsqlmi_life_mdm.bupartyaddresslink) WHERE RANK =1),

COMB AS (
SELECT DISTINCT PRTY.PARTY_TYPE_CD,PRTY.NAME,TIN,ADDR_LINE_ONE,ADDR_LINE_TWO,ADDR_LINE_THREE,CITY_NAME,POSTAL_CODE,STATE_NM,CNTRY_NM
FROM PARTY PRTY INNER JOIN PARTY_REL REL ON TRIM(PRTY.PARTY_ID_PK) = TRIM(REL.PARTY_ID_PK)
INNER JOIN ADDR addr ON TRIM(addr.ADDR_ID_PK) = TRIM(REL.ADDR_ID_PK))

SELECT ROW_NUMBER() OVER (PARTITION BY NAME,TIN ORDER BY NAME,TIN,ADDR_LINE_ONE,ADDR_LINE_TWO) AS ADDR_RANK_MDM,PARTY_TYPE_CD,NAME,TIN AS MDM_TIN,ADDR_LINE_ONE AS ADDR_LINE_1_MDM,ADDR_LINE_TWO AS ADDR_LINE_2_MDM,ADDR_LINE_THREE AS ADDR_LINE_3_MDM,CITY_NAME AS CITY_NM_MDM,POSTAL_CODE AS ZIP_CD_MDM,STATE_NM AS STATE_NM_MDM,CNTRY_NM AS CNTRY_NM_MDM FROM (SELECT ROW_NUMBER() OVER (PARTITION BY NAME,TIN,ADDR_LINE_ONE,ADDR_LINE_TWO,ADDR_LINE_THREE,CITY_NAME,POSTAL_CODE ORDER BY NAME,ADDR_LINE_ONE,ADDR_LINE_TWO,ADDR_LINE_THREE,CITY_NAME,POSTAL_CODE,STATE_NM,CNTRY_NM DESC) AS RANK,* FROM COMB) WHERE RANK = 1

"""
)

# COMMAND ----------

display(life_mdm_df_org)

# COMMAND ----------

df_org = life_mdm_df_org.join(jhim_df_org, (life_mdm_df_org['MDM_TIN'] == jhim_df_org['JHIM_TIN']  ) & (life_mdm_df_org['NAME'] == jhim_df_org['NAME']) & (life_mdm_df_org['ADDR_RANK_MDM'] == jhim_df_org['ADDR_RANK_JHIM']), 'left')

# COMMAND ----------

df_org = consistency_check(df_org, 'jhim_df_org', 'MDM_TIN', 'JHIM_TIN', 'ADDR_LINE_1_MDM', 'ADDR_LINE_1_JHIM')
df_org = consistency_check(df_org, 'jhim_df_org', 'MDM_TIN', 'JHIM_TIN', 'ADDR_LINE_2_MDM', 'ADDR_LINE_2_JHIM')
df_org = consistency_check(df_org, 'jhim_df_org', 'MDM_TIN', 'JHIM_TIN', 'ADDR_LINE_3_MDM', 'ADDR_LINE_3_JHIM')
df_org = consistency_check(df_org, 'jhim_df_org', 'MDM_TIN', 'JHIM_TIN', 'CITY_NM_MDM', 'CITY_NM_JHIM')
df_org = consistency_check(df_org, 'jhim_df_org', 'MDM_TIN', 'JHIM_TIN', 'ZIP_CD_MDM', 'ZIP_CD_JHIM')
df_org = consistency_check(df_org, 'jhim_df_org', 'MDM_TIN', 'JHIM_TIN', 'STATE_NM_MDM', 'STATE_NM_JHIM')
df_org = consistency_check(df_org, 'jhim_df_org', 'MDM_TIN', 'JHIM_TIN', 'CNTRY_NM_MDM', 'CNTRY_NM_JHIM')

# COMMAND ----------

display(df_org)

# COMMAND ----------

config['parent_dir'] = 'usdo_prod_catalog.silver_azsqlmi_life_mdm.buorginfo'
config['work_stream']   = 'life ops'
config['data_system']   = 'mdm life'
config['asset_name'] = 'buorginfo'
config['data_owner'] = 'Amy Miskavitch'
config['business_unit'] = 'Life (US)'
config['data_domain'] = 'Customer'
config['rule_owner'] = 'Gina Stewart'
config['file_type'] = 'delta'

# COMMAND ----------

summary_df = get_summary(df_org)

# COMMAND ----------

display(summary_df)