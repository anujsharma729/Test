# Databricks notebook source
# MAGIC %run ../utils

# COMMAND ----------

# MAGIC %run ../rules

# COMMAND ----------

# MAGIC %run ./life_utils

# COMMAND ----------

try:
    config['data_system'] = 'ps'
    df = uc_read('bronze_ps', 'ps_jhim_ps_master_delta')
    bene_cols = ['EMPRIMARY_NAME_1','EMPRIMARY_BENEF1_NAME']

    insured_cols = ['EMTAA_I1_TIN','EMTAA_I1_GIVEN','EMTAA_I1_SURNAME', 'EMTAA_MAIL_STREET', 'EMTAA_MAIL_CITY', 'EMTAA_MAIL_STATE_PROVINCE', 'EMTAA_MAIL_ZIP_POSTAL_CODE', 'EMTAA_MAIL_ADDRESS_FOREIGN', 'EMTAA_MAIL_COUNTRY', 'EMTAA_MAIL_PHONE_NUMBER', 'EMBIRDT', 'EMSSNO']
    #insured death date EMCLMDT

    owner_cols = ['EMTAA_SHORT_MAIL_TITLE', 'EMTAA_OWNER_STREET', 'EMTAA_OWNER_CITY', 'EMTAA_OWNER_STATE_PROVINCE', 'EMTAA_OWNER_ZIP_POSTAL_CODE', 'EMTAA_OWNER_ADDRESS_FOREIGN', 'EMTAA_OWNER_COUNTRY', 'EMTAA_OWNER_PHONE_NUMBER', 'EMTAA_OWNER_TIN']

    policy_information = ['EMPOLNO', 'EMPCHCD', 'EMPSTCD', 'EMPOLST']

    df = df.filter((df.EMPOLST == '00') | (df.EMPOLST == '01'))
    df = df.select(*owner_cols, *insured_cols, *bene_cols)

    df = df.withColumn("EMBIRDT",to_date(unix_timestamp(col("EMBIRDT"), "ddMMyyyy").cast("timestamp")))
    df = clean(df)
    for column in df.columns:
        df = completeness_check(df, column)

    s1 = get_summary(df)
    uc_write(s1)
except Exception as e:
    print(e)

# COMMAND ----------

# try:
#     config['data_system'] = 'ps'
#     df = uc_read('bronze_ps', 'ps_jhim_ps_master_delta')
#     bene_cols = ['EMPRIMARY_NAME_1','EMPRIMARY_BENEF1_NAME']

#     insured_cols = ['EMTAA_I1_TIN','EMTAA_I1_GIVEN','EMTAA_I1_SURNAME', 'EMTAA_MAIL_STREET', 'EMTAA_MAIL_CITY', 'EMTAA_MAIL_STATE_PROVINCE', 'EMTAA_MAIL_ZIP_POSTAL_CODE', 'EMTAA_MAIL_ADDRESS_FOREIGN', 'EMTAA_MAIL_COUNTRY', 'EMTAA_MAIL_PHONE_NUMBER', 'EMBIRDT', 'EMSSNO']
#     #insured death date EMCLMDT

#     owner_cols = ['EMTAA_SHORT_MAIL_TITLE', 'EMTAA_OWNER_STREET', 'EMTAA_OWNER_CITY', 'EMTAA_OWNER_STATE_PROVINCE', 'EMTAA_OWNER_ZIP_POSTAL_CODE', 'EMTAA_OWNER_ADDRESS_FOREIGN', 'EMTAA_OWNER_COUNTRY', 'EMTAA_OWNER_PHONE_NUMBER', 'EMTAA_OWNER_TIN']

#     policy_information = ['EMPOLNO', 'EMPCHCD', 'EMPSTCD', 'EMPOLST']

#     df = df.filter((df.EMPOLST == '00') | (df.EMPOLST == '01'))
#     df = df.select(*owner_cols, *insured_cols, *bene_cols)

#     df = df.withColumn("EMBIRDT",to_date(unix_timestamp(col("EMBIRDT"), "ddMMyyyy").cast("timestamp")))
#     df = clean(df)
#     for column in df.columns:
#         df = completeness_check(df, column)

#     s1 = get_summary(df)
#     uc_write(s1)
# except Exception as e:
#     print(e)