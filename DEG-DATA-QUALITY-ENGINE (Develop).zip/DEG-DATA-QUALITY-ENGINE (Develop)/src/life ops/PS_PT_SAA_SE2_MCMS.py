# Databricks notebook source
# MAGIC %run ../utils

# COMMAND ----------

# MAGIC %run ../rules

# COMMAND ----------

# MAGIC %run ./life_utils

# COMMAND ----------

try:
    config['data_system'] = 'ps'
    df = uc_read('bronze_ps', 'ps_jhim_ps_master_delta')
    bene_cols = ['EMPRIMARY_NAME_1','EMPRIMARY_BENEF1_NAME']

    insured_cols = ['EMTAA_I1_TIN','EMTAA_I1_GIVEN','EMTAA_I1_SURNAME', 'EMTAA_MAIL_STREET', 'EMTAA_MAIL_CITY', 'EMTAA_MAIL_STATE_PROVINCE', 'EMTAA_MAIL_ZIP_POSTAL_CODE', 'EMTAA_MAIL_ADDRESS_FOREIGN', 'EMTAA_MAIL_COUNTRY', 'EMTAA_MAIL_PHONE_NUMBER', 'EMBIRDT', 'EMSSNO']
    #insured death date EMCLMDT

    owner_cols = ['EMTAA_SHORT_MAIL_TITLE', 'EMTAA_OWNER_STREET', 'EMTAA_OWNER_CITY', 'EMTAA_OWNER_STATE_PROVINCE', 'EMTAA_OWNER_ZIP_POSTAL_CODE', 'EMTAA_OWNER_ADDRESS_FOREIGN', 'EMTAA_OWNER_COUNTRY', 'EMTAA_OWNER_PHONE_NUMBER', 'EMTAA_OWNER_TIN']

    policy_information = ['EMPOLNO', 'EMPCHCD', 'EMPSTCD', 'EMPOLST']

    df = df.filter((df.EMPOLST == '00') | (df.EMPOLST == '01'))
    df = df.select(*owner_cols, *insured_cols, *bene_cols)

    df = df.withColumn("EMBIRDT",to_date(unix_timestamp(col("EMBIRDT"), "ddMMyyyy").cast("timestamp")))
    df = clean(df)
    for column in df.columns:
        df = completeness_check(df, column)

    s1 = get_summary(df)
    uc_write(s1)
except Exception as e:
    print(e)

# COMMAND ----------

try:
    config['data_system'] = 'pt'
    assets = ['pt_ptdttla', 'pt_ptdttln']

    for asset in assets:
        df = uc_read('silver_pt', asset)
        if asset == 'pt_ptdttla':
            role = 'TTLA_CLIENT_ROLE'
            columns = ['TTLA_POL_NUMBER', 'TTLA_CLIENT_ROLE', 'TTLA_STREET', 'TTLA_CITY', 'TTLA_ZIP_POSTAL_CODE', 'TTLA_STATE_PROVINCE']
        else:
            columns = ['TTLN_POL_NUMBER', 'TTLN_CLIENT_ROLE', 'TTLN_GIVEN_NAMES', 'TTLN_SURNAME']
            role = 'TTLN_CLIENT_ROLE'

        df = df.select(*columns)


        df = df.filter((df[role].startswith('INS')) | (df[role].startswith('OWN')))

        df = df.select(*columns).distinct()
        df = clean(df)
        for column in df.columns:
            df = completeness_check(df, column)

        s1 = get_summary(df)
        uc_write(s1)
except Exception as e:
    print(e)

# COMMAND ----------

try:
    config['data_system'] = 'saa'
    df = uc_read('silver_saa', 'saa_rec001')

    columns = ['CP_CL_FIRST_NM','CP_CL_LAST_NM','CP_CLIENT_BIRTH_DT', 'CP_CLIENT_SSN_TAX_ID', 'CP_CL_ADDR_LINE1', 'CP_CLIENT_CITY', 'CP_CLIENT_STATE', 'CP_CLIENT_ZIP5']

    # df = df.filter((df.CP_CLIENT_INSURED_IND != '') | (df.CP_BENEFICIARY_TYPE_CD != '0'))
    df = df.select(*columns)
    df = clean(df)
    for column in df.columns:
        df = completeness_check(df, column)

    s1 = get_summary(df)
    uc_write(s1)
except Exception as e:
    print(e)

# COMMAND ----------

try:
    config['data_system'] = 'se2'
    assets = ['names', 'address']

    for asset in assets:
        df = uc_read('silver_se2', asset)
        if asset == 'names':
            columns = ['NAM_FST_NAME', 'NAM_LST_NAME', 'NAM_TAX_ID', 'NAM_DOB', 'NAM_GENDER']
        else:
            columns = ['ADDR_LINE1', 'ADDR_CITY', 'ADDR_STATE', 'ADDR_ZIP']

        df = df.select(*columns).distinct()
        df = clean(df)
        for column in df.columns:
            df = completeness_check(df, column)

        s1 = get_summary(df)
        uc_write(s1)
except Exception as e:
    print(e)

# COMMAND ----------

try:
    config['data_system'] = 'mcms'
    assets = ['names', 'address']

    for asset in assets:
        df = uc_read('silver_mcms', 'mcms_cpv3r001')
        
        columns = ["CP_POL_NO", "CP_CLIENT_CITY", "CP_CL_ADDR_LINE1", "CP_CLIENT_STATE", "CP_CLIENT_ZIP5", "CP_CLIENT_BIRTH_DT", "CP_CLIENT_GENDER_CD", "CP_CLIENT_SSN_TAX_ID", "CP_CL_FIRST_NM", "CP_CL_LAST_NM"]
        df = df.select(*columns).distinct()
        df = clean(df)
        for column in df.columns:
            df = completeness_check(df, column)

        s1 = get_summary(df)
        uc_write(s1)
except Exception as e:
    print(e)

# COMMAND ----------

