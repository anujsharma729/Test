# Databricks notebook source
# MAGIC %run ../utils

# COMMAND ----------

import re
import datetime
from pyspark.sql.window import Window
from pyspark.sql.functions import col, row_number, when, lit
REFERENCE_DATE = '1900-01-01'
SYSTEM_DEFAULT = '9999-12-31'
system = "mdm life"

# COMMAND ----------

def syn_read_asset(table_name):
    jdbcUrl = f"jdbc:sqlserver://ihub-usdo-syn-prod.sql.azuresynapse.net:1433;database=syndp001;user={syn_user};password={syn_pw};encrypt=true;trustServerCertificate=false;hostNameInCertificate=*.sql.azuresynapse.net;loginTimeout=30;authentication=ActiveDirectoryPassword"
    synapse_table = f"ltc_buffer.{table_name}"
    df = spark.read.format("jdbc").option("url",jdbcUrl ).option("dbtable",synapse_table).load()
    return df

# def uc_read(asset, schema='silver_azsqlmi_life_mdm'):
#     df = spark.sql(f"SELECT * FROM usdo_prod_catalog.{schema}.{asset}")
#     config['parent_dir'] = f"usdo_prod_catalog.silver_azsqlmi_life_mdm.{asset}"
#     config['asset_name'] = asset 
#     return df

# COMMAND ----------

#CONFIGURATION FOR TABLES

config['work_stream'] = 'life ops'
config['data_system'] =  system
config['data_owner'] = 'Amy Miskavitch'
config['business_unit'] = 'Life (US)'
config['data_domain'] = 'Customer'
config['rule_owner'] = 'Gina Stewart'
# config['parent_dir'] = UC_PATH
config['asset_name'] = asset

# COMMAND ----------

def value_counts(df, column):
    value_counts_df = df.groupBy(column).count().orderBy(f.col("Count").desc(),f.asc(column))
    display(value_counts_df)
    return value_counts_df
    
def print_dataframe_as_dict(spark_df):
    # Collect the DataFrame rows to the driver
    rows = spark_df.collect()
    
    # Convert rows to dictionary
    rows_as_dict = [row.asDict() for row in rows]
    
    # Print the dictionarysystem
    print(rows_as_dict)

def get_current_data(df, ids, dates):
    # Define a window partitioned by the composite key and ordered by date_updated descending
    window_spec = Window.partitionBy(ids).orderBy(col(dates).desc())

    # Add a row number to each partition
    df_with_rownum = df.withColumn("row_num", row_number().over(window_spec))

    # Filter to keep only the first row (most recent date_updated) per group
    filtered_df = df_with_rownum.filter(col("row_num") == 1).drop("row_num")
    return filtered_df

# COMMAND ----------

### FORMAT DATAFRAMES #######
def clean(df):
    for c in df.columns:
        # df = df.withColumn(c, f.lower(f.trim(f.col(c))))
        df = trim(df)
        df = df.withColumn(c, f.regexp_replace(c, r"[-#$!?]", ""))
        df = df.withColumn(c, f.when((f.col(c) == "") | (f.col(c).rlike(r"^(0[\s]?){1,}$")), None).otherwise(f.col(c)))
        df = df.withColumn(c, f.regexp_replace(c, r"[\u00A0\u1680\u180E\u2000-\u200A\u202F\u205F\u3000\u200B\u2060\uFEFF]", ""))

        if 'ADDR' in c:
            df = df.withColumn(c, f.regexp_replace(f.col(c), r'\b[Pp]\.? ?[Oo]\.? ?[Bb]ox\b', 'PO Box'))
            df = df.withColumn(c, f.regexp_replace(f.col(c), r'\bAttn?:?\s?', 'ATTN: '))
            df = df.withColumn(c, f.regexp_replace(f.col(c), r'\bAttention:?\s?:?', 'ATTN: '))
            df = df.withColumn(c, f.regexp_replace(f.col(c), r'\bFbo?:?\s?', 'FBO: '))
            df = df.withColumn(c, f.regexp_replace(f.col(c), r'\bC[/\\]?o:?\s?', 'C/O: '))
        if 'phone' in c.lower() or 'tele' in c.lower() or 'cell' in c.lower():
            df = clean_phonenumbers(df, c)
    return df

def clean_phonenumbers(df, c):
    df = df.withColumn(c, f.regexp_replace(c, r"[-() ]", ""))
    return df

def trim(df, columns=None):
    if columns == None: columns = df.columns
    for column in columns:
        df = df.withColumn(column, f.ltrim(f.rtrim(df[column])))
    return df
    
def format_address(df, columns=None):
    if columns is None:
        columns = df.columns
    for c in columns:
        df = df.withColumn(c, f.initcap(df[c]))
        df = df.withColumn(c, f.regexp_replace(f.col(c), r'\b[Pp]\.? ?[Oo]\.? ?[Bb]ox\b', 'PO Box'))
        df = df.withColumn(c, f.regexp_replace(f.col(c), r'\bAttn?:?\s?', 'ATTN: '))
        df = df.withColumn(c, f.regexp_replace(f.col(c), r'\bAttention:?\s?:?', 'ATTN: '))
        df = df.withColumn(c, f.regexp_replace(f.col(c), r'\bFbo?:?\s?', 'FBO: '))
        df = df.withColumn(c, f.regexp_replace(f.col(c), r'\bC[/\\]?o:?\s?', 'C/O: '))
    return df
def format_names(df, columns=None):
    if columns is None:
        columns = df.columns

    replacements = [
        (r"(?<=\S)&(?=\S)", " & "),
        (r"(?<=\S)& ", " & "),
        (r" &(?=\S)", " & "),
        (r"\.&", ". &"),
        (r"^Mrs\.?\s{1}", "Mrs. "),
        (r"Mrs(?=\b|$)", "Mrs."),
        (r"^Ms\.?\s{1}", "Ms. "),
        (r"^Mr\.?\s{1}", "Mr. "),
        (r"Mr(?=\b|$)", "Mr."),
        (r"^Miss\.?\s{1}", "Miss. "),
        (r"^Dr\.?\s{1}", "Dr. "),
        (r"^Jr\.?\s{1}", "Jr. "),
        (r"Jr(?=\b|$)", "Jr."),
        (r"^Sr\.?\s{1}", "Sr. "),
        (r"^Md\.?\s{1}", "MD. "),
        (r"\s*-\s*", "-"),
        (r"\s*'\s*", "'"),
        (r"\bC[/\\]?o:?\s?", "C/O: "),
        (r"\bC[/\\]?o\b", "C/O: "),
        (r"(\b[A-Z])\b(?![.'-])", r"\1."),
        (r"\b([A-Z])\b(?= \w)", r"\1."),
        (r"\.([A-Za-z])", r". \1")
    ]

    for column in columns:
        df = df.withColumn(column, f.initcap(f.col(column)))
        for pattern, replacement in replacements:
            df = df.withColumn(column, f.regexp_replace(f.col(column), pattern, replacement))

    return df


