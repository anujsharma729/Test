# Databricks notebook source
# MAGIC  %run ../../utils

# COMMAND ----------

config['work_stream'] = 'Distributor'
config['data_system'] = 'Lars'
config['data_owner'] = "Amanda Murphy"
config['business_unit'] = "Life (US)"
config['data_domain'] = "Producer & Distributor"
config['rule_owner'] = "Amanda Murphy"

tparty_cols = ['PARTY_ID_SEQ_NO', 'PARTY_ID_NO', 'PARTY_TYP_CD', 'NIPR_NO', 'FED_TAX_ID_NO']
torg_unit_cols = ['ORG_UNIT_ID_SEQ_NO', 'ORG_UNIT_ID_NO', 'PARTY_ID_SEQ_NO', 'PARTY_ID_NO', 'ORG_NM']
taddr_asoc_cols = ['ADDR_ID_SEQ_NO', 'ADDR_ID_NO', 'ADDR_USAG_CD', 'ADDR_TYP_CD', 'ENT_ID_NO']
t_physc_addr_cols = ['ADDR_ID_NO', 'ST_ADDR_LN1_DESC', 'ST_ADDR_LN2_DESC', 'CITY_NM', 'PSTL_JURS_CD', 'ZIP_CD', 'CNTRY_NM']
t_addr_asoc_business_cols = ['ADDR_ID_NO', 'ADDR_USAG_CD', 'ADDR_TYP_CD', 'ENT_ID_NO']
tcodedecode_cols = ['CDC_ID_NO','C_CODE']

tparty  = uc_read('silver_lars','tparty')
torg_unit  = uc_read('silver_lars','torg_unit')
tphysc_addr  = uc_read('silver_lars','tphysc_addr')
tcodedecode = uc_read('silver_lars', 'tcodedecode')
taddr_asoc  = uc_read('silver_lars','taddr_asoc')
taddr_asoc_business = uc_read('silver_lars','taddr_asoc')

tparty = tparty.filter((tparty.LAST_UPD_BY_NM.isNull()) & (tparty.PARTY_TYP_CD == 50623) & (tparty.FED_TAX_ID_NO != 0))
torg_unit = torg_unit.filter(torg_unit.LAST_UPD_BY_NM.isNull())
taddr_asoc = taddr_asoc.filter((taddr_asoc.LAST_UPD_BY_NM.isNull()) & (taddr_asoc.ADDR_ASOC_EXPR_DT.isNull()))
tphysc_addr = tphysc_addr.filter((tphysc_addr.LAST_UPD_BY_NM.isNull()))
taddr_asoc_business = taddr_asoc.filter((taddr_asoc.ADDR_TYP_CD == 50219) & (taddr_asoc.ADDR_USAG_CD == 50593))
tcodedecode = tcodedecode.filter(f.trim(tcodedecode['C_CODE']).isin(US_STATES))

tparty  = tparty.select(tparty_cols)
torg_unit  = torg_unit.select(torg_unit_cols)
tphysc_addr  = tphysc_addr.select(t_physc_addr_cols)
tcodedecode = tcodedecode.select(tcodedecode_cols)
taddr_asoc  = taddr_asoc.select(taddr_asoc_cols)
taddr_asoc_business = taddr_asoc_business.select(t_addr_asoc_business_cols)

# COMMAND ----------

business_address = taddr_asoc_business.join(tphysc_addr, ['ADDR_ID_NO'], 'left')
business_address = business_address.withColumnRenamed('ENT_ID_NO', 'Business Address: ENT_ID_NO')
business_address = business_address.withColumnRenamed('ST_ADDR_LN1_DESC', 'Business Address: Line 1')
business_address = business_address.withColumnRenamed('ST_ADDR_LN2_DESC', 'Business Address: Line 2')
business_address = business_address.withColumnRenamed('CITY_NM', 'Business Address: City')
business_address = business_address.withColumnRenamed('ZIP_CD', 'Business Address: Zip Code')
business_address = business_address.withColumnRenamed('CNTRY_NM', 'Business Address: Country')

df = tparty.join(torg_unit,['PARTY_ID_NO'], 'left')
df = df.join(business_address, df['ORG_UNIT_ID_NO'] == business_address['Business Address: ENT_ID_NO'], 'left')

df = df.join(tcodedecode,df['PSTL_JURS_CD'] == tcodedecode['CDC_ID_NO'], 'left')
df = df.drop('CDC_ID_NO', 'PSTL_JURS_CD').withColumnRenamed('C_CODE', 'Business Address: State')

df = df.select('NIPR_NO', 'FED_TAX_ID_NO', 'ORG_NM', 'Business Address: Line 1', 'Business Address: Line 2', 'Business Address: City', 'Business Address: State', 'Business Address: Zip Code')
df = df.distinct()

df = df.withColumnRenamed('NIPR_NO', 'NPN')
df = df.withColumnRenamed('FED_TAX_ID_NO', 'TIN')
df = df.withColumnRenamed('ORG_NM', 'Firm Name')

lars_df = df
del taddr_asoc, torg_unit, tphysc_addr, tcodedecode, taddr_asoc_business, df
