# Databricks notebook source
# MAGIC  %run ../../utils

# COMMAND ----------

# MAGIC %run ../../rules

# COMMAND ----------

# MAGIC %run ./CREATE_LARS_DISTRIBUTOR

# COMMAND ----------

# COMPLETENESS
completeness_check_columns = ['NPN','TIN','Firm Name', 'Business Address: Line 1', 'Business Address: City', 'Business Address: State', 'Business Address: Zip Code']
for column in completeness_check_columns:
    lars_df = completeness_check(lars_df, column)

lars_df = uniqueness_check(lars_df, 'TIN')
lars_df = uniqueness_check(lars_df, 'NPN')

lars_df = conformity_postalcode_us(lars_df, 'Business Address: Zip Code')
lars_df = conformity_ssn(lars_df, 'TIN')
lars_df = conformity_npn(lars_df, 'NPN')

t_party = lars_df.select('Completeness: TIN', 'Completeness: NPN', 'Conformity: TIN', 'Conformity: NPN', 'Uniqueness: NPN','Uniqueness: TIN')
t_org_unit = lars_df.select('Completeness: Firm Name')
t_physc_addr = lars_df.select('Completeness: Business Address: City', 'Completeness: Business Address: Line 1', 'Completeness: Business Address: Zip Code', 'Completeness: Business Address: State', 'Conformity: Business Address: Zip Code')  

config['asset_name'] = 'tparty'
s1 = get_summary(t_party)
config['asset_name'] = 'torg_unit'
s2 = get_summary(t_org_unit)
config['asset_name'] = 't_physc_addr'
s3 = get_summary(t_physc_addr)

summary_df = s1.union(s2).union(s3)

# COMMAND ----------

uc_write(summary_df)
