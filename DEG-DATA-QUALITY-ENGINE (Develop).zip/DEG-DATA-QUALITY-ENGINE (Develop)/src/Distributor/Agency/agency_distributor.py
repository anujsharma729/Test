# Databricks notebook source
# MAGIC  %run ../../utils

# COMMAND ----------

# MAGIC %run ../LARS/CREATE_LARS_DISTRIBUTOR

# COMMAND ----------

config['data_system'] = 'Agency'
config['asset_name'] = 'tayseller'

tayseller  = uc_read('silver_agency','tayseller')
tayslstat  = uc_read('silver_agency','tayslstat')

tayseller_cols = ["SELLERID", "SSNTAXID", "SELLERNPN", "SELSURFIRMNAME", "SELSURFIRMIND", "SELHOMEST1", "SELHOMEST2", "SELHOMEST3", "SELHOMECITY", "SELHOMESTATE", "SELHOMEZIP", "SELMAILST1", "SELMAILST2", "SELMAILST3", "SELMAILCITY", "SELMAILSTATE", "SELMAILZIP", "SELSHORTNAME", "SELPHONENO", "SELHOUSEDIND", "SELUSRESIND", "SELCELLPHONE", "SELFAXNO", "SELPAGERNO", "SELINTERNET1", "SELINTERNET2", "SELRESTRICTED", "SELUPDDATE", "SELUSERID", "CONTACTNAME1", "ROLE1", "TEL1", "EMAIL1", "CONTACTNAME2", "ROLE2", "TEL2", "EMAIL2", "CONTACTNAME3", "ROLE3", "TEL3", "EMAIL3", "CONTACTNAME4", "ROLE4", "TEL4", "EMAIL4"]
tayslstat_cols = ["SELLERID", "SLSTATEFFDTE", "SELSTATUS"]

tayseller = tayseller.select(tayseller_cols)
tayslstat = tayslstat.select(tayslstat_cols)
tayseller = tayseller.filter(tayseller.SELSURFIRMIND == 'F')

window_spec = Window.partitionBy("SELLERID")
tayslstat = tayslstat.withColumn("max_date", f.max("SLSTATEFFDTE").over(window_spec)).filter(col("SLSTATEFFDTE") == col("max_date")).drop("max_date")

df = tayslstat.join(tayseller, ['SELLERID'], 'inner')
df = trim(df)

df = df.withColumn('SSNTAXID', f.regexp_replace('SSNTAXID', '-', ''))
df = df.withColumn('SELLERID', f.regexp_replace(df['SELLERID'], r'\.0*$', ''))
df = df.withColumn('SELLERNPN', f.regexp_replace('SELLERNPN', r'\.0*$', ''))

# COMMAND ----------

df = df.withColumn('SELLERNPN', f.trim(df['SELLERNPN']))
df = df.withColumn('SSNTAXID', f.trim(df['SSNTAXID']))
df = df.withColumn('SELMAILST1', f.trim(df['SELMAILST1']))
df = df.withColumn('SELMAILST2', f.trim(df['SELMAILST2']))
df = df.withColumn('SELMAILCITY', f.trim(df['SELMAILCITY']))
df = df.withColumn('SELMAILSTATE', f.trim(df['SELMAILSTATE']))
df = df.withColumn('SELMAILZIP', f.trim(df['SELMAILZIP']))
df = df.withColumn('SELHOMEST1', f.trim(df['SELHOMEST1']))
df = df.withColumn('SELHOMEST2', f.trim(df['SELHOMEST2']))
df = df.withColumn('SELHOMECITY', f.trim(df['SELHOMECITY']))
df = df.withColumn('SELHOMESTATE', f.trim(df['SELHOMESTATE']))
df = df.withColumn('SELHOMEZIP', f.trim(df['SELHOMEZIP']))
df = df.withColumn('SELSURFIRMNAME', f.trim(df['SELSURFIRMNAME']))

# COMMAND ----------

df = df.join(lars_df, df['SSNTAXID'] == lars_df['TIN'], 'inner')

# COMMAND ----------

df = df.withColumn('Business Address: STATE', f.trim(df['Business Address: STATE']))
df = df.withColumn('Firm Name', f.trim(df['Firm Name']))

# COMMAND ----------

df = consistency_check(df, 'lars distributor', 'SSNTAXID', 'TIN', 'SELLERNPN', 'NPN')
df = consistency_check(df, 'lars distributor', 'SSNTAXID', 'TIN', 'SSNTAXID', 'TIN')
df = consistency_check(df, 'lars distributor', 'SSNTAXID', 'TIN', 'SELSURFIRMNAME', 'Firm Name')

# COMMAND ----------

def apply_consistency_check(df):
    df = df.withColumn('CHECK_ST1', f.when((f.col('SELMAILST1').isNull()) | (f.col('SELMAILST1') == ''), f.col('SELHOMEST1')).otherwise(f.col('SELMAILST1')))
    df = df.withColumn('CHECK_CITY', f.when((f.col('SELMAILST1').isNull()) | (f.col('SELMAILST1') == ''), f.col('SELHOMECITY')).otherwise(f.col('SELMAILCITY')))
    df = df.withColumn('CHECK_STATE', f.when((f.col('SELMAILST1').isNull()) | (f.col('SELMAILST1') == ''), f.col('SELHOMESTATE')).otherwise(f.col('SELMAILSTATE')))
    df = df.withColumn('CHECK_ZIP', f.when((f.col('SELMAILST1').isNull()) | (f.col('SELMAILST1') == ''), f.col('SELHOMEZIP')).otherwise(f.col('SELMAILZIP')))

    df = consistency_check(df, 'lars distributor', 'SSNTAXID', 'TIN', 'CHECK_ST1', 'Business Address: Line 1')
    df = consistency_check(df, 'lars distributor', 'SSNTAXID', 'TIN', 'CHECK_CITY', 'Business Address: City')
    df = consistency_check(df, 'lars distributor', 'SSNTAXID', 'TIN', 'CHECK_STATE', 'Business Address: STATE')
    df = consistency_check(df, 'lars distributor', 'SSNTAXID', 'TIN', 'CHECK_ZIP', 'Business Address: Zip Code')

    return df

# COMMAND ----------

df = apply_consistency_check(df)

# COMMAND ----------

summary = get_summary(df)
uc_write(summary)
