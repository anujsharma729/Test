# Databricks notebook source
# MAGIC %run ../../utils

# COMMAND ----------

# MAGIC %run ../ltc_utils

# COMMAND ----------

# MAGIC %run ../../rules

# COMMAND ----------

config['asset_name'] = 'care_tclient_member'
config['data_system'] = 'care'

df = uc_read('care_tclient_member')
df = trim(df)
df = format_date(df, ['LAST_CHANGE_DT', 'MBR_BIRTH_DT'])
df = get_current_data(df,'PERSON_ID', 'LAST_CHANGE_DT')


# COMMAND ----------

# #COMPLETENESS
completeness_check_columns = ['MBR_GENDER_CD', 'MBR_FIRST_NM', 'MBR_LAST_NM', 'MBR_BIRTH_DT']
for column in completeness_check_columns:
    df = completeness_check(df, column)

#CONFORMITY
df = conformity_birthdate(df, 'MBR_BIRTH_DT')
df = conformity_name(df, 'MBR_FIRST_NM')
df = conformity_name(df, 'MBR_LAST_NM')
df = conformity_gender(df, 'MBR_GENDER_CD')

df = accuracy_gender(df, 'MBR_GENDER_CD')
df = accuracy_birthdate(df, 'MBR_BIRTH_DT')

# COMMAND ----------

summary = get_summary(df).display()
# uc_write(summary)
