# Databricks notebook source
# MAGIC %run ./TPLAN_CODE

# COMMAND ----------

# MAGIC %run ./TCERTIFICATE

# COMMAND ----------

# MAGIC %run ./TCOVERAGE_SUMMARY

# COMMAND ----------

# MAGIC %run ./TCLIENT_MEMBER

# COMMAND ----------

# MAGIC %run ./TCOVERAGE_LAYER

# COMMAND ----------

# MAGIC %run ./TPERSON

# COMMAND ----------

# MAGIC %run ./TPERSON_ADDRESS
