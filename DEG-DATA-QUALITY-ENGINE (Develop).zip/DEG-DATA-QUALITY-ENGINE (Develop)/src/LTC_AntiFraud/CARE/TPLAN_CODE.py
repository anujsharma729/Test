# Databricks notebook source
# MAGIC %run ../../utils

# COMMAND ----------

# MAGIC %run ../ltc_utils
# MAGIC

# COMMAND ----------

# MAGIC %run ../../rules

# COMMAND ----------

config['asset_name'] = 'care_tplan_code'
config['data_system'] = 'care'

df = uc_read('care_tplan_code')
df = clean(df)

# COMMAND ----------

#COMPLETENESS
for column in ['POLICY_NBR', 'G_CODE', 'CLIENT_NBR', 'PLAN_CD']:
    df = completeness_check(df, column)

#CONFORMITY

df = conformity_policynumber(df, 'POLICY_NBR', 5, 8)

# df = df.withColumn('Conformity: ELIM_PERIOD1', f.when(df['ELIM_PERIOD1'].isNull(), 'pass: No Entry').when(df['ELIM_PERIOD1'].rlike(r'^\d{1,3}'), 'pass: Must Be Numeric').otherwise('fail: Must Be Numeric'))

# df = df.withColumn('Conformity: YEARS', f.when(df['YEARS'].isNull(), 'pass: No Entry').when(df['YEARS'].rlike(r'^\d{2,4}'), 'pass: Must Be Numeric').otherwise('fail: Must Be Numeric'))

#Lifetime Maximum Benefit
# df = df.withColumn('Conformity: LMB', f.when(df['LMB'].isNull(), 'pass: No Entry').when(df['LMB'].rlike(r'^\d{2,4}'), 'pass: Must Be Numeric').otherwise('fail: Must Be Numeric'))

# df = df.withColumn('Accuracy: ELIM_PERIOD1', f.when(f.substring(df['S_PLAN_KEY'],1,3).cast(IntegerType()) == df['ELIM_PERIOD1'].cast(IntegerType()), 'pass: Must Equal First 3 Characters of S_PLAN_KEY').when(df['ELIM_PERIOD1'].isNull(), 'pass: No Entry').otherwise('fail: Must Equal First 3 Characters of S_PLAN_KEY'))

# COMMAND ----------

#FINISH
summary = get_summary(df)
uc_write(summary)
