# Databricks notebook source
# MAGIC %run ../../ltc_utils

# COMMAND ----------

# MAGIC %run ../../../utils

# COMMAND ----------

t_cov = syn_read_asset('Care_TCOVERAGE_SUMMARY')
tper = syn_read_asset('Care_TPERSON')

t_ins_cov = syn_read_asset('Promise_T_INSURED_COVERAGE')
t_pers = syn_read_asset('Promise_T_PERSON')

# COMMAND ----------

promise_df = t_pers.join(t_ins_cov, t_pers['PERSON_ID'] == t_ins_cov['INSURED_PERSON_ID'], 'left_outer').select('LTC_ID', 'CARE_INSURED_PERSON_ID', 'ADMIN_SOURCE','FIRST_NAME', 'LAST_NAME', 'BIRTH_DATE', 'TAX_ID', 'POLICY_NUMBER', 'PREMIUM_PAYMENT_AMOUNT')
care_df = tper.join(t_cov, on='PERSON_ID', how='left_outer').select('PERSON_ID','LAST_NM','FIRST_NM','BIRTH_DT','DEATH_DT','GENDER_CD','SSN')


# COMMAND ----------

df = promise_df.filter(promise_df['ADMIN_SOURCE'] == 'CARE')
df = df.join(care_df, df['CARE_INSURED_PERSON_ID'] == care_df['PERSON_ID'], 'left').distinct()
# df = df.filter(df["LAST_NM"].isNull())
df = clean(df)
df = df.withColumn('Consistency: PERSON_ID', f.when(df['PERSON_ID'].isNull(), 'fail: Promise Coverage Records From Care Must Exist in Care').otherwise('pass: Promise Coverage Records From Care Must Exist in Care'))
# display(df)

# COMMAND ----------

summary_df = get_summary(df, None, 'Care', 'Care_TCOVERAGE_SUMMARY', 'LTC_AntiFraud')
summary_df.write.parquet(f"abfss://dataquality@{ENV['storage_account']}.dfs.core.windows.net/LTC_AntiFraud/Care/Care_TCOVERAGE_SUMMARY/{TIMESTAMP}/scan_summary")
