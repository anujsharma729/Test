# Databricks notebook source
# MAGIC %run ../../utils

# COMMAND ----------

# MAGIC %run ../ltc_utils

# COMMAND ----------

# MAGIC %run ../../rules

# COMMAND ----------

config['asset_name'] = 'care_tperson'
config['data_system'] = 'care'

df = uc_read('care_tperson')
df = clean(df)
df = format_names(df, ['FIRST_NM', 'LAST_NM'])

# COMMAND ----------

#COMPLETENESS
# Gender is not a required column in Care
completeness_check_columns = ['FIRST_NM', 'LAST_NM', 'BIRTH_DT']
for column in completeness_check_columns:
    df = completeness_check(df, column)

df = df.withColumn('Completeness: SSN', f.when(((df['PERSON_ID'].startswith('T')) | (df['PERSON_ID'].startswith('A')) | (df['PERSON_ID'].startswith('E')) | (df['PERSON_ID'].startswith('N')) | (df['PERSON_ID'].startswith('D'))) & (df["SSN"].isNull()), 'pass: must contain non null value unless the record has a temporary person id').when(df['SSN'].isNull(), 'fail: must contain non null value unless the record has a temporary person id').otherwise('pass: must contain non null value unless the record has a temporary person id'))

# #CONFORMITY
df = conformity_birthdate(df, 'BIRTH_DT')
df = conformity_gender(df, 'GENDER_CD')
df = conformity_deathdate(df, 'DEATH_DT')
df = conformity_email(df, 'EMAIL_ID')
df = conformity_ssn(df, 'SSN')
df = conformity_name(df, 'FIRST_NM')
df = conformity_name(df, 'LAST_NM')

df = accuracy_gender(df, 'GENDER_CD')
df = accuracy_birthdate(df, 'BIRTH_DT')
df = accuracy_deathdate(df, 'DEATH_DT')
                
df = df.withColumn('Accuracy: SSN', check_ssn(df['SSN'], f.lit(None)))

# COMMAND ----------

summary = get_summary(df)
uc_write(summary)

# COMMAND ----------


