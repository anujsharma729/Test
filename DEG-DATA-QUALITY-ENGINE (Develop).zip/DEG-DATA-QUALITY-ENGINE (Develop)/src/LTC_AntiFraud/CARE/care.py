# Databricks notebook source
# MAGIC %run ../../utils

# COMMAND ----------

# MAGIC %run ../ltc_utils

# COMMAND ----------

# MAGIC %run ../../rules

# COMMAND ----------

config['data_system'] = 'care'

#TCERTIFCATE
try:
    df = uc_read('care_tcertificate')
    df = trim(df)
    df = format_date(df, ['LAST_CHANGE_DT', 'CERT_EFF_DT'])
    df = completeness_check(df, 'POLICY_NBR')
    df = df.withColumn('Conformity: POLICY_NBR', f.when(df['POLICY_NBR'].rlike(r'^\d{5}$'), 'pass: must be a 5 or 8 digit number')
            .when(df['POLICY_NBR'].rlike(r'^\d{5}-\d{3}$'), 'pass: must be a 5 or 8 digit number')
            .when(df['POLICY_NBR'] == '28867A', 'pass: must be a 5 or 8 digit number')
            .when(df['POLICY_NBR'].isNull(), 'pass: must be a 5 or 8 digit number').otherwise('fail: must be a 5 or 8 digit number'))

    s1 = get_summary(df)
    uc_write(s1)
except Exception as e:
    print(e)

#TCLEINT_MEMBER
try:
    df = uc_read('care_tclient_member')
    df = trim(df)
    df = format_date(df, ['LAST_CHANGE_DT', 'MBR_BIRTH_DT'])
    df = get_current_data(df,'PERSON_ID', 'LAST_CHANGE_DT')
    for column in ['MBR_GENDER_CD', 'MBR_FIRST_NM', 'MBR_LAST_NM', 'MBR_BIRTH_DT']:
        df = completeness_check(df, column)
    df = conformity_birthdate(df, 'MBR_BIRTH_DT')
    df = conformity_name(df, 'MBR_FIRST_NM')
    df = conformity_name(df, 'MBR_LAST_NM')
    df = conformity_gender(df, 'MBR_GENDER_CD')
    df = accuracy_gender(df, 'MBR_GENDER_CD')
    df = accuracy_birthdate(df, 'MBR_BIRTH_DT')

    s2 = get_summary(df)
    uc_write(s2)
except Exception as e:
    print(e)

#TCOVERAGE_LAYER
try:
    df = uc_read('care_tcoverage_layer')
    df = clean(df)
    df = get_current_data(df,'PERSON_ID', 'LAST_CHANGE_DT')
    df = format_date(df, ['LAST_CHANGE_DT'])
    for column in ['CLIENT_NBR', 'POLICY_NBR', 'PLAN_CD', 'CLIENT_NBR', 'ISSUE_ST_TERR_CD', 'PERSON_ID']: 
        df = completeness_check(df, column)
    df = conformity_policynumber(df, 'POLICY_NBR', 5, 8)
    df = conformity_state(df, 'ISSUE_ST_TERR_CD')
    df = conformity_age(df, 'ISSUE_AGE')
    df = accuarcy_age(df, 'ISSUE_AGE')
    s3 = get_summary(df)
    uc_write(s3)
except Exception as e:
    print(e)

# #TCOVERAGE_SUMMARY
try:
    df = uc_read('care_tcoverage_summary')
    df = clean(df)
    df = df.withColumn('Conformity: LTC_ID', 
        f.when(df['LTC_ID'].rlike(r'^\d+$') & (df['LTC_ID'].rlike(r'^\d{8}$')), 'pass: must be a 8 digit number')                   
        .when(df['LTC_ID'].isNull(),'pass: must be a 8 digit number')           
        .otherwise('fail: must be a 8 digit number'))

    df = df.withColumn('Conformity: PERSON_ID', 
        f.when(df['PERSON_ID'].rlike(r'^\d{9}$'), 'pass: must be a 9 digit number or temporary id number')  
        .when(df['PERSON_ID'].rlike(r'^[A-Z]\d{8}$'),'pass: must be a 9 digit number or temporary id number') 
        .when(df['PERSON_ID'].isNull(),'fail: must be a 9 digit number or temporary id number')
        .otherwise('fail: must be a 9 digit number or temporary id number'))

    s4 = get_summary(df)
    uc_write(s4)
except Exception as e:
    print(e)

#TPERSON
try:
    df = uc_read('care_tperson')
    df = clean(df)
    df = format_names(df, ['FIRST_NM', 'LAST_NM'])
    for column in ['FIRST_NM', 'LAST_NM', 'BIRTH_DT']:
        df = completeness_check(df, column)


    # Gender is not a required column in Care
    for column in ['FIRST_NM', 'LAST_NM', 'BIRTH_DT']:
        df = completeness_check(df, column)

    rule = "must contain non null value unless the record has a temporary person id"
    df = df.withColumn('Completeness: SSN', f.when(((df['PERSON_ID'].startswith('T')) | (df['PERSON_ID'].startswith('A')) | (df['PERSON_ID'].startswith('E')) | (df['PERSON_ID'].startswith('N')) | (df['PERSON_ID'].startswith('D'))) & (df["SSN"].isNull()), f'pass:{rule}').when(df['SSN'].isNull(), f'fail:{rule}').otherwise(f'pass:{rule}'))

    df = conformity_birthdate(df, 'BIRTH_DT')
    df = conformity_gender(df, 'GENDER_CD')
    df = conformity_deathdate(df, 'DEATH_DT')
    df = conformity_email(df, 'EMAIL_ID')
    df = conformity_ssn(df, 'SSN')
    df = conformity_name(df, 'FIRST_NM')
    df = conformity_name(df, 'LAST_NM')
    df = accuracy_gender(df, 'GENDER_CD')
    df = accuracy_birthdate(df, 'BIRTH_DT')
    df = accuracy_deathdate(df, 'DEATH_DT')           
    df = df.withColumn('Accuracy: SSN', check_ssn(df['SSN'], f.lit(None)))
    s5 = get_summary(df)
    uc_write(s5)
except Exception as e:
    print(e)

#TPERSON_ADDRESS
try:
    df = uc_read('care_tperson_address')
    df = get_current_data(df, 'PERSON_ID', 'LAST_CHANGE_DT')
    df = clean(df)
    df = format_address(df, ['ADDR_LINE1','ADDR_LINE2', 'ADDR_LINE3', 'CITY'])
    for column in ['ADDR_LINE1', 'CITY','STATE_TERR_CD','ZIP_CD']:
        df = completeness_check(df, column)
    df = completeness_triple_dependency(df, 'PHONE_NBR', 'WORK_PHONE_NBR', 'CELL_PHONE_NBR')
    df = conformity_addr1(df, 'ADDR_LINE1')
    df = conformity_addr2(df, 'ADDR_LINE2')
    df = conformity_addr3(df, 'ADDR_LINE3')
    df = conformity_city(df, 'CITY')
    df = conformity_state(df, 'STATE_TERR_CD')
    df = conformity_postalcode(df, 'ZIP_CD')
    df = conformity_phone(df, 'PHONE_NBR')
    df = conformity_phone(df, 'WORK_PHONE_NBR')
    df = conformity_phone(df, 'CELL_PHONE_NBR')
    df = accuracy_city(df, 'CITY')
    df = accuracy_phone(df, 'PHONE_NBR')
    df = accuracy_phone(df, 'WORK_PHONE_NBR')
    df = accuracy_phone(df, 'CELL_PHONE_NBR')

    s6 = get_summary(df)
    uc_write(s6)
except Exception as e:
    print(e)

# TPLAN_CODE
try:
    df = uc_read('care_tplan_code')
    df = clean(df)
    for column in ['POLICY_NBR', 'G_CODE', 'CLIENT_NBR', 'PLAN_CD']:
        df = completeness_check(df, column)
    df = conformity_policynumber(df, 'POLICY_NBR', 5, 8)
    s7 = get_summary(df)
    uc_write(s7)
except Exception as e:
    print(e)