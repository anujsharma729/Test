# Databricks notebook source
# MAGIC %run ../../utils

# COMMAND ----------

# MAGIC %run ../SP_utils

# COMMAND ----------

# MAGIC %run ../ltc_utils

# COMMAND ----------

# MAGIC %run ../../rules

# COMMAND ----------

config['asset_name'] = 'care_tperson_address'
config['data_system'] = 'care'

df = uc_read('care_tperson_address')
df = get_current_data(df, 'PERSON_ID', 'LAST_CHANGE_DT')
df = clean(df)
df = format_address(df, ['ADDR_LINE1','ADDR_LINE2', 'ADDR_LINE3', 'CITY'])

# COMMAND ----------

# ***SHAREPOINT

# ctx = authenticate_sharepoint()
# from pyspark.sql import SparkSession

# folder = '/sites/USDG/DQ_LTC_Anti_Fraud'
# ranges = read_from_sp(ctx, 'STATE_ZIP_CODE_RANGES.csv', folder)
# ranges = spark.createDataFrame(ranges)

# df1 = df.join(ranges, df.STATE_TERR_CD == ranges.STATE, how='left').distinct()
# df1 = df1.withColumn("ZIP5", f.substring(f.col("ZIP_CD"), 1, 5).cast(IntegerType()))

# ranges = ranges.withColumn("LOWER_RANGE", f.col("LOWER_RANGE").cast(IntegerType()))
# ranges = ranges.withColumn("UPPER_RANGE", f.col("UPPER_RANGE").cast(IntegerType()))

# df1 = df1.withColumn('Accuracy: ZIP_CD', f.when(((f.col("ZIP5") < f.col("LOWER_RANGE")) | (f.col("ZIP5") > f.col("UPPER_RANGE")) & (f.col("ZIP5") != f.col("LOWER_RANGE")) & (f.col("ZIP5") != f.col("UPPER_RANGE"))), 'fail: ZIP Code within State Range').when(f.col('ZIP5').isNull(), 'fail: ZIP Code within State Range').otherwise('pass: ZIP Code within State Range'))
# s1 = get_summary(df1, None, **config)

# COMMAND ----------

#COMPLETENESS
completeness_check_columns = ['ADDR_LINE1', 'CITY','STATE_TERR_CD','ZIP_CD']
for column in completeness_check_columns:
    df = completeness_check(df, column)
    
df = completeness_triple_dependency(df, 'PHONE_NBR', 'WORK_PHONE_NBR', 'CELL_PHONE_NBR')

# #CONFORMITY
df = conformity_addr1(df, 'ADDR_LINE1')
df = conformity_addr2(df, 'ADDR_LINE2')
df = conformity_addr3(df, 'ADDR_LINE3')
df = conformity_city(df, 'CITY')
df = conformity_state(df, 'STATE_TERR_CD')
df = conformity_postalcode(df, 'ZIP_CD')
df = conformity_phone(df, 'PHONE_NBR')
df = conformity_phone(df, 'WORK_PHONE_NBR')
df = conformity_phone(df, 'CELL_PHONE_NBR')

df = accuracy_city(df, 'CITY')
df = accuracy_phone(df, 'PHONE_NBR')
df = accuracy_phone(df, 'WORK_PHONE_NBR')
df = accuracy_phone(df, 'CELL_PHONE_NBR')

# COMMAND ----------

summary = get_summary(df)
uc_write(summary)
