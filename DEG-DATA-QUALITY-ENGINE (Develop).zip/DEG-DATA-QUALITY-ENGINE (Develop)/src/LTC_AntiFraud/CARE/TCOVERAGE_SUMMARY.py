# Databricks notebook source
# MAGIC %run ../../utils

# COMMAND ----------

# MAGIC %run ../ltc_utils

# COMMAND ----------

# MAGIC %run ../../rules

# COMMAND ----------

config['asset_name'] = 'care_tclient_member'
config['data_system'] = 'care'

df = uc_read('care_tcoverage_summary')

# COMMAND ----------

#COMPLETENESS
completeness_check_columns = ['LTC_ID', 'PERSON_ID', 'CLIENT_NBR']
for column in completeness_check_columns:
    df = completeness_check(df, column)  

#CONFORMITY
df = df.withColumn('Conformity: LTC_ID', 
    f.when(df['LTC_ID'].rlike(r'^\d+$') & (df['LTC_ID'].rlike(r'^\d{8}$')), 'pass: must be a 8 digit number')                   
    .when(df['LTC_ID'].isNull(),'pass: must be a 8 digit number')           
    .otherwise('fail: must be a 8 digit number'))

df = df.withColumn('Conformity: PERSON_ID', 
    f.when(df['PERSON_ID'].rlike(r'^\d{9}$'), 'pass: must be a 9 digit number or temporary id number')  
    .when(df['PERSON_ID'].rlike(r'^[A-Z]\d{8}$'),'pass: must be a 9 digit number or temporary id number') 
    .when(df['PERSON_ID'].isNull(),'fail: must be a 9 digit number or temporary id number')
    .otherwise('fail: must be a 9 digit number or temporary id number'))


# COMMAND ----------

summary = get_summary(df)
uc_write(summary)
