# Databricks notebook source
# MAGIC %run ../../ltc_utils

# COMMAND ----------

# MAGIC %run ../../../utils

# COMMAND ----------

df = syn_read_asset('Care_TPERSON')
df = clean(df)
# display(df)

# COMMAND ----------

# birth_date = df.filter((df['BIRTH_DT'].isNull()) | (df['BIRTH_DT'] <= '1990-01-01'))
# ssn = df.filter(df['SSN'].isNull())
# first_name = df.filter(df['FIRST_NM'].isNull())
# last_name = df.filter(df['LAST_NM'].isNull())

# COMMAND ----------

# column_name = 'SSN_CLEAN'
# column = 'SSN'
# t_norm = syn_read_asset('T_NORM_PERSON')
# df = ssn.join(t_norm, ssn['PERSON_ID'] == t_norm['SOURCE_ID'], "left")
# columns = ['NORM_PERSON_ID', 'SOURCE_ID','SOURCE_SYSTEM', 'SOURCE_TABLE', 'FIRST_NAME_CLEAN', 'LAST_NAME_CLEAN', 'BIRTH_DATE_CLEAN', 'SSN_CLEAN']
# df = df.select('PERSON_ID','NORM_PERSON_ID')
# t_norm_match = syn_read_asset('T_NORM_PERSON_MATCH')
# t_norm_person = syn_read_asset('T_NORM_PERSON').select(columns)
# t_norm = t_norm_person.withColumnRenamed("NORM_PERSON_ID", 'NORM_PERSON_ID_P2').withColumnRenamed(column_name, column_name+'2')
# df = df.join(t_norm_match, (df['NORM_PERSON_ID'] == t_norm_match['NORM_PERSON_ID_1']) | (df['NORM_PERSON_ID'] == t_norm_match['NORM_PERSON_ID_1']), "left" )
# df = df.select('PERSON_ID', 'NORM_PERSON_ID_1', 'NORM_PERSON_ID_2').distinct()
# # df = df.select('NORM_PERSON_ID_1', 'NORM_PERSON_ID_2', 'RULE_NAME').distinct()

# df = df.join(t_norm_person, (t_norm_person['NORM_PERSON_ID'] == df['NORM_PERSON_ID_1']), 'left')
# df = df.join(t_norm, (t_norm['NORM_PERSON_ID_P2'] == df['NORM_PERSON_ID_2']), 'left')
# df = df.withColumn(f'Consistency: {column}', f.when(df[column_name + '2'].isNotNull(), f'pass: {column} has corresponding value in T_NORM_PERSON').otherwise(f'fail: {column}  has corresponding value in T_NORM_PERSON'))

# display(df)

# COMMAND ----------

def check_tnorm_person(df1, column):
    print(column)
    column_name = column +'_CLEAN'
    t_norm = syn_read_asset('T_NORM_PERSON')
    df = df1.join(t_norm, df1['PERSON_ID'] == t_norm['SOURCE_ID'], "left")
    columns = ['NORM_PERSON_ID', 'SOURCE_ID','SOURCE_SYSTEM', 'SOURCE_TABLE', 'FIRST_NAME_CLEAN', 'LAST_NAME_CLEAN', 'BIRTH_DATE_CLEAN', 'SSN_CLEAN', 'DEATH_DATE_CLEAN', 'SEX_CLEAN']
    df = df.select('PERSON_ID','NORM_PERSON_ID')
    t_norm_match = syn_read_asset('T_NORM_PERSON_MATCH')
    t_norm_person = syn_read_asset('T_NORM_PERSON').select(*columns)
    t_norm = t_norm_person.withColumnRenamed("NORM_PERSON_ID", 'NORM_PERSON_ID_P2').withColumnRenamed(column_name, column_name+'2')
    df = df.join(t_norm_match, (df['NORM_PERSON_ID'] == t_norm_match['NORM_PERSON_ID_1']) | (df['NORM_PERSON_ID'] == t_norm_match['NORM_PERSON_ID_1']), "left" )
    df = df.select('PERSON_ID', 'NORM_PERSON_ID_1', 'NORM_PERSON_ID_2')
    # df = df.select('NORM_PERSON_ID_1', 'NORM_PERSON_ID_2', 'RULE_NAME').distinct()

    df = df.join(t_norm_person, (t_norm_person['NORM_PERSON_ID'] == df['NORM_PERSON_ID_1']), 'left')
    df = df.join(t_norm, (t_norm['NORM_PERSON_ID_P2'] == df['NORM_PERSON_ID_2']), 'left')
    df = df.withColumn(f'Consistency: {column}', f.when(df[column_name + '2'].isNotNull(), f'pass: {column} has corresponding value in T_NORM_PERSON').otherwise(f'fail: {column}  has corresponding value in T_NORM_PERSON'))
    return df

# COMMAND ----------

summary_df = None
for column in df.columns:
    if '_DT' in column: df = df.withColumnRenamed(column, column.split('_DT')[0] + '_DATE')
    if '_NM' in column: df = df.withColumnRenamed(column, column.split('_NM')[0] + '_NAME')
    if 'GENDER' in column: df = df.withColumnRenamed(column, 'SEX')

df = df.select(['PERSON_ID', 'LAST_NAME', 'FIRST_NAME', 'BIRTH_DATE', 'DEATH_DATE', 'SEX', 'SSN'])

# COMMAND ----------

for column in df.columns:
    df1 = df.filter((df[column].isNull()) | (df[column] == '1900-01-01') | (df[column] == '9999-12-31'))
    if df1.count() > 0 and column != 'PERSON_ID':
        values = check_tnorm_person(df1, column)
        if values.count() > 0:
            summary = get_summary(values, None, 'Care', 'Care_TPERSON', 'LTC_AntiFraud')
            if summary_df is None: summary_df = summary
            else: summary_df = summary_df.union(summary)

# display(summary_df)
save_parquet_results(None, summary_df, 'LTC_AntiFraud', 'Care', 'Care_TPERSON')

# COMMAND ----------

# check_for_SSN = check_tnorm_person(ssn, 'SSN')
# summary = get_summary(check_for_SSN, None, 'Care', 'Care_TPERSON', 'LTC_AntiFraud')

# # check_for_BDAY = check_tnorm_person(birth_date, 'BIRTH_DATE')
# # summary1 = get_summary(check_for_BDAY, None, 'Care', 'Care_TPERSON', 'LTC_AntiFraud')

# check_for_FNAME = check_tnorm_person(first_name, 'FIRST_NAME').display()
# summary2 = get_summary(check_for_FNAME, None, 'Care', 'Care_TPERSON', 'LTC_AntiFraud')

# check_for_LNAME = check_tnorm_person(last_name, 'LAST_NAME')
# summary3 = get_summary(check_for_LNAME, None, 'Care', 'Care_TPERSON', 'LTC_AntiFraud')

# COMMAND ----------

# summary_df = summary.union(summary1).union(summary2).union(summary3)
# display(summary_df)
