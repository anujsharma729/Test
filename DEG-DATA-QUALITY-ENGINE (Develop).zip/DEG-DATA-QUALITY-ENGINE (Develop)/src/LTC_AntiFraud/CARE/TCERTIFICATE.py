# Databricks notebook source
# MAGIC %run ../../utils

# COMMAND ----------

# MAGIC %run ../ltc_utils

# COMMAND ----------

config['asset_name'] = 'care_tcertificate'
config['data_system'] = 'care'

df = uc_read('care_tcertificate')
df = trim(df)
df = format_date(df, ['LAST_CHANGE_DT', 'CERT_EFF_DT'])


# COMMAND ----------

#COMPLETENESS
df = completeness_check(df, 'POLICY_NBR')

#CONFORMITY
df = df.withColumn('Conformity: POLICY_NBR', f.when(df['POLICY_NBR'].rlike(r'^\d{5}$'), 'pass: must be a 5 or 8 digit number')
        .when(df['POLICY_NBR'].rlike(r'^\d{5}-\d{3}$'), 'pass: must be a 5 or 8 digit number')
        .when(df['POLICY_NBR'] == '28867A', 'pass: must be a 5 or 8 digit number')
        .when(df['POLICY_NBR'].isNull(), 'pass: must be a 5 or 8 digit number').otherwise('fail: must be a 5 or 8 digit number'))

# COMMAND ----------

summary = get_summary(df)
uc_write(summary)
