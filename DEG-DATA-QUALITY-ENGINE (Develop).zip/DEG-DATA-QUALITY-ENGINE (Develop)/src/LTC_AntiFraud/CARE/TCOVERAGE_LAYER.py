# Databricks notebook source
# MAGIC %run ../../utils

# COMMAND ----------

# MAGIC %run ../ltc_utils
# MAGIC

# COMMAND ----------

# MAGIC %run ../../rules

# COMMAND ----------

config['asset_name'] = 'care_tcertificate'
config['data_system'] = 'care'

df = uc_read('care_tcoverage_layer')
df = clean(df)
df = get_current_data(df,'PERSON_ID', 'LAST_CHANGE_DT')
df = format_date(df, 'LAST_CHANGE_DT')

# COMMAND ----------

#COMPLETENESS
for column in ['CLIENT_NBR', 'POLICY_NBR', 'PLAN_CD', 'CLIENT_NBR', 'ISSUE_ST_TERR_CD', 'PERSON_ID']:
        df = completeness_check(df, column)
#CONFORMITY
df = conformity_policynumber(df, 'POLICY_NBR', 5, 8)
df = conformity_state(df, 'ISSUE_ST_TERR_CD')
df = conformity_age(df, 'ISSUE_AGE')
df = accuarcy_age(df, 'ISSUE_AGE')

# COMMAND ----------

summary = get_summary(df)
uc_write(summary)
