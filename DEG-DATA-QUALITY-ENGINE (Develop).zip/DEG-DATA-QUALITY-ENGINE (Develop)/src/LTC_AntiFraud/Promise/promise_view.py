# Databricks notebook source
# MAGIC %run ../../utils

# COMMAND ----------

# MAGIC %run ../ltc_utils

# COMMAND ----------

config['data_system'] = 'promise'
t_person = uc_read('promise_t_person')
t_insured_coverage = uc_read('promise_t_insured_coverage')
t_claim = uc_read('promise_t_claim')
t_claim_status = uc_read('promise_t_claim_status')
t_product = uc_read('promise_t_product')
t_person = uc_read('promise_t_person')

t_person = clean(t_person)
t_claim_status = t_claim_status.filter(t_claim_status.END_DATE.isNull())

t_product = t_product.join(t_insured_coverage, on='PRODUCT_ID', how='left').distinct()
t_claim = t_claim.join(t_claim_status, on='CLAIM_ID', how='left')
t_claim = t_claim.join(t_product, on='INSURED_COVERAGE_ID', how='left')
df = t_person.join(t_claim, on='PERSON_ID', how='left')

person_cols = ['PERSON_ID','FIRST_NAME', 'LAST_NAME', 'BIRTH_DATE','DATE_OF_DEATH','TAX_ID']
policy_cols = ['LTC_ID', 'PRODUCT_ID', 'INSURED_PERSON_ID', 'INSURED_COVERAGE_ID', 'POLICY_NUMBER']
claim_cols = ['CLAIM_ID','CLAIM_NUMBER', 'CLAIM_SYSTEM', 'CLAIM_STATUS_CODE','CLAIM_SUB_STATUS_CODE','CLAIM_REPORTED_DATE', 'END_DATE']
product_cols = ['PRODUCT_ID', 'PRODUCT_NAME', 'PRODUCT_DESCRIPTION', 'TAX_QUALIFIED']

promise = df.select(*person_cols, *policy_cols, *claim_cols, *product_cols)