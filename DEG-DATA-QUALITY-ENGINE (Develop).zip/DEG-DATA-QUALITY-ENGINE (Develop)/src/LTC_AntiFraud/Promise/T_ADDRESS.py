# Databricks notebook source
# MAGIC %run ../../utils

# COMMAND ----------

# MAGIC %run ../ltc_utils

# COMMAND ----------

# MAGIC %run ../../rules

# COMMAND ----------

configure_spark()
config['asset_name'] = 'Promise_T_ADDRESS'
config['data_system'] = 'Promise'
df = uc_read('promise_t_address').drop('UNFORMATTED_PHONE_NUMBER', 'CREATED_DATE', 'PROCESSING_JOB_ID', 'COMMENT')
df = get_current_data(df, 'ADDRESS_ID', 'LAST_MODIFIED_DATE')
df = clean(df)
df = format_address(df, ['ADDRESS_LINE_1', 'ADDRESS_LINE_2', 'ADDRESS_LINE_3', 'CITY'])

# COMMAND ----------

#COMPLETENESS
completeness_check_columns = ['ADDRESS_LINE_1','CITY', 'ZIP_CODE', 'STATE', 'PHONE_NUMBER']
for column in completeness_check_columns:
    df = completeness_check(df, column)

#CONFORMITY
df = conformity_addr1(df, 'ADDRESS_LINE_1')
df = conformity_addr2(df, 'ADDRESS_LINE_2')
df = conformity_addr3(df, 'ADDRESS_LINE_3')
df = conformity_city(df, 'CITY')
df = conformity_phone(df, 'PHONE_NUMBER')
df = conformity_state(df, 'STATE')
df = conformity_postalcode(df, 'ZIP_CODE')

df = accuracy_city(df, 'CITY')

# COMMAND ----------

summary = get_summary(df)
uc_write(summary)
