# Databricks notebook source
# MAGIC %run ../../utils

# COMMAND ----------

# MAGIC %run ../ltc_utils

# COMMAND ----------

# MAGIC %run ../../rules

# COMMAND ----------

configure_spark()
config['asset_name'] = 'promise_t_insured_coverage'
config['data_system'] = 'Promise'

df = uc_read('promise_t_insured_coverage')
df = clean(df)
# df = df.select('ADMIN_SOURCE', 'CARE_INSURED_PERSON_ID', 'ISSUE_AGE', 'LTC_ID', 'POLICY_NUMBER', 'POLICY_TYPE')

# COMMAND ----------

#COMPLETENESS
for column in ['INSURED_COVERAGE_ID', 'ISSUE_JURISDICTION_CODE', 'INSURED_PERSON_ID', 'POLICY_TYPE']:
        df = completeness_check(df, column)

df = df.withColumn('Completeness: POLICY_NUMBER', f.when((df['POLICY_TYPE'] == 'RETAIL') & (df['POLICY_NUMBER'].isNull()), 'fail: retail policies must have policy number').otherwise('pass: retail policies must have policy number'))

#CONFORMITY
df = conformity_policynumber(df, 'POLICY_NUMBER', 7, 9)

df = df.withColumn('Conformity: POLICY_TYPE', f.when(df['POLICY_TYPE'].rlike(r'Retail|Group'), 'pass: must contain retail or group').when(df['POLICY_NUMBER'].isNull(), 'pass: must contain retail or group').otherwise('fail: must contain retail or group'))

# ACCURACY
# df = df.withColumn('Accuracy: ELIMINATION_PERIOD', f.when(df['ELIMINATION_PERIOD'] > 365, 'fail: Elimination Period Must Be Less Than 365 Days').otherwise('pass: Elimination Period Must Be Less Than 365))

# COMMAND ----------

summary = get_summary(df)
uc_write(summary)
