# Databricks notebook source
# MAGIC %run ./T_CLAIM

# COMMAND ----------

# MAGIC %run ./T_ADDRESS

# COMMAND ----------

# MAGIC %run ./T_INSURED_COVERAGE

# COMMAND ----------

# MAGIC %run ./T_PERSON

# COMMAND ----------

# MAGIC %run ./T_PROVIDER
