# Databricks notebook source
# MAGIC %run ../../utils

# COMMAND ----------

# MAGIC %run ../ltc_utils

# COMMAND ----------

# MAGIC %run ../../rules

# COMMAND ----------

configure_spark()
config['asset_name'] = 'promise_t_provider'
config['data_system'] = 'Promise'
df = uc_read('promise_t_provider')
df = clean(df)
df = format_names(df, ['FIRST_NAME', 'LAST_NAME', 'PROVIDER_NAME'])

# COMMAND ----------

#COMPLETENESS
df = df.withColumn('Completeness: PHONE_NUMBER', f.when(df['PHONE_NUMBER'].isNull(), 'fail: must contain non null value').otherwise('pass: must contain non null value'))

for column in ['FIRST_NAME', 'LAST_NAME'] :
    df = df.withColumn(f'Completeness: {column}', f.when((df[column].isNull()) & (df['PROVIDER_CATEGORY_CODE'] == 'Individual'), 'fail: must contain non null value').otherwise('pass: must contain non null value'))

df = df.withColumn('Completeness: PROVIDER_NAME', f.when((df['PROVIDER_NAME'].isNull()) & (df['PROVIDER_CATEGORY_CODE'] == 'Business Entity'), 'fail: must contain non null value').otherwise('pass: must contain non null value'))

#CONFORMITY

df = conformity_name(df, 'FIRST_NAME')
df = conformity_name(df, 'LAST_NAME')
df = conformity_phone(df, 'PHONE_NUMBER')

df = df.withColumn('Conformity: PROVIDER_NAME', f.when(df['PROVIDER_NAME'].rlike(r' {3,}'),'fail: must adhere to expected format')    
    .when(df['PROVIDER_NAME'].rlike(r".*[?@#$%^*¬><!{}:}‹~¿_;:'|+=°®•].*"),"fail: must adhere to expected format")
    .when(df['PROVIDER_NAME'].rlike(r'^[A-Za-z0-9\s]+$'),'pass: must adhere to expected format')
    .when(df['PROVIDER_NAME'].isNull(), 'pass: must adhere to expected format').otherwise('fail: must adhere to expected format'))

# COMMAND ----------

summary = get_summary(df)
uc_write(summary)
