# Databricks notebook source
# MAGIC %run ../../utils

# COMMAND ----------

# MAGIC %run ../ltc_utils

# COMMAND ----------

# MAGIC %run ../../rules

# COMMAND ----------

#TADDRESS
config['data_system'] = 'promise'
try:
    df = uc_read('promise_t_address').drop('UNFORMATTED_PHONE_NUMBER', 'CREATED_DATE', 'PROCESSING_JOB_ID', 'COMMENT')
    df = get_current_data(df, 'ADDRESS_ID', 'LAST_MODIFIED_DATE')
    df = clean(df)
    df = format_address(df, ['ADDRESS_LINE_1', 'ADDRESS_LINE_2', 'ADDRESS_LINE_3', 'CITY'])
    for column in ['ADDRESS_LINE_1','CITY', 'ZIP_CODE', 'STATE', 'PHONE_NUMBER']: df = completeness_check(df, column)
    df = conformity_addr1(df, 'ADDRESS_LINE_1')
    df = conformity_addr2(df, 'ADDRESS_LINE_2')
    df = conformity_addr3(df, 'ADDRESS_LINE_3')
    df = conformity_city(df, 'CITY')
    df = conformity_phone(df, 'PHONE_NUMBER')
    df = conformity_state(df, 'STATE')
    df = conformity_postalcode(df, 'ZIP_CODE')
    df = accuracy_city(df, 'CITY')
    s1 = get_summary(df)
    uc_write(s1)
except Exception as e:
    print(e)

#TCLAIM
try: 
    df = uc_read('promise_t_claim').orderBy('PERSON_ID')
    df = clean(df)

    for column in ['CLAIM_NUMBER', 'CLAIM_SYSTEM', 'CLAIM_EFFECTIVE_DATE','CLAIM_ID', 'PERSON_ID', 'INSURED_COVERAGE_ID']:
        df = completeness_check(df, column)

    df = uniqueness_check(df, 'CLAIM_NUMBER')
    df = df.withColumn('Accuracy: CLAIM_NUMBER',f.when(df['CLAIM_NUMBER'] == 'FIC   119941', 'fail: lifepro claim should not be in promise').otherwise('pass: lifepro claim should not be in promise'))
    s2 = get_summary(df)
    uc_write(s2)
except Exception as e:
    print(e)

#T_INSURED_COVERAGE
try: 
    df = uc_read('promise_t_insured_coverage')
    df = clean(df)
    for column in ['INSURED_COVERAGE_ID', 'ISSUE_JURISDICTION_CODE', 'INSURED_PERSON_ID', 'POLICY_TYPE']:
            df = completeness_check(df, column)
    df = completeness_with_dependency(df, 'POLICY_NUMBER', 'POLICY_TYPE', 'RETAIL', 'retail policies must have policy number')
    df = conformity_policynumber(df, 'POLICY_NUMBER', 7, 9)
    df = accuracy_check_value(df, 'POLICY_TYPE', ['Retail', 'Group'])
    s3 = get_summary(df)
    uc_write(s3)
except Exception as e:
    print(e)

#T_PROVIDER
try:
    df = uc_read('promise_t_provider')
    df = clean(df)
    df = format_names(df, ['FIRST_NAME', 'LAST_NAME', 'PROVIDER_NAME'])
    df = completeness_check(df, 'PHONE_NUMBER')
    df = completeness_with_dependency(df, 'FIRST_NAME', 'PROVIDER_CATEGORY_CODE', 'individual')
    df = completeness_with_dependency(df, 'LAST_NAME', 'PROVIDER_CATEGORY_CODE', 'individual')
    df = completeness_with_dependency(df, 'PROVIDER_NAME', 'PROVIDER_CATEGORY_CODE', 'business Entity')
    df = conformity_name(df, 'FIRST_NAME')
    df = conformity_name(df, 'LAST_NAME')
    df = conformity_phone(df, 'PHONE_NUMBER')
    df = conformity_business(df, 'PROVIDER_NAME')
    s4 = get_summary(df)
    uc_write(s4)
except Exception as e:
    print(e)


# COMMAND ----------

try:
    df = uc_read('promise_t_person')
    df = clean(df)
    df = format_names(df,['FIRST_NAME', 'LAST_NAME', 'FULL_NAME'])
    for column in ['GENDER', 'LAST_NAME', 'BIRTH_DATE', 'FIRST_NAME', 'FULL_NAME']:
        df = completeness_with_dependency(df, column, 'PERSON_TYPE', 'PERSON')
    df = completeness_with_dependency(df, 'ENTITY_NAME', 'PERSON_TYPE', 'Entity')
    df = completeness_triple_dependency(df, 'CELL_PHONE_NUMBER', 'HOME_PHONE_NUMBER', 'WORK_PHONE_NUMBER')

    df = conformity_name(df, 'FIRST_NAME')
    df = conformity_name(df, 'LAST_NAME')
    df = conformity_name(df, 'FULL_NAME')
    df = conformity_birthdate(df, 'BIRTH_DATE')
    df = conformity_deathdate(df, 'DATE_OF_DEATH')
    df = conformity_name(df, 'EMAIL_ADDRESS')
    df = conformity_phone(df, 'CELL_PHONE_NUMBER')
    df = conformity_phone(df, 'HOME_PHONE_NUMBER')
    df = conformity_phone(df, 'WORK_PHONE_NUMBER')
    df = conformity_gender(df, 'GENDER')
    df = conformity_ssn(df, 'TAX_ID')
    df = conformity_business(df, 'ENTITY_NAME')

    df = accuracy_birthdate(df, 'BIRTH_DATE')
    df = accuracy_gender(df, 'GENDER')
    df = accuracy_phone(df, 'CELL_PHONE_NUMBER')
    df = accuracy_phone(df, 'HOME_PHONE_NUMBER')
    df = accuracy_phone(df, 'WORK_PHONE_NUMBER')

    s5 = get_summary(df)
    uc_write(s5)
except Exception as e:
    print(e)
