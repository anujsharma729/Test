# Databricks notebook source
# MAGIC %run ../../utils

# COMMAND ----------

# MAGIC %run ../ltc_utils

# COMMAND ----------

# MAGIC %run ../../rules

# COMMAND ----------

configure_spark()
config['asset_name'] = 'Promise_T_CLAIM'
config['data_system'] = 'Promise'

df = uc_read('promise_t_claim').orderBy('PERSON_ID')
df = clean(df)

# COMMAND ----------

#COMPLETENESS
for column in ['CLAIM_NUMBER', 'CLAIM_SYSTEM', 'CLAIM_EFFECTIVE_DATE','CLAIM_ID', 'PERSON_ID', 'INSURED_COVERAGE_ID']:
    df = completeness_check(df, column)

#UNIQUENESS
df = uniqueness_check(df, 'CLAIM_NUMBER')

#Accuracy
df = df.withColumn('Accuracy: CLAIM_NUMBER',f.when(df['CLAIM_NUMBER'] == 'FIC   119941', 'fail: Lifepro Claim Should Not Be in Promise').otherwise('pass: Lifepro Claim Should Not Be in Promise'))

# COMMAND ----------

summary = get_summary(df)
uc_write(summary)
