# Databricks notebook source
# MAGIC %run ../../utils

# COMMAND ----------

# MAGIC %run ../ltc_utils

# COMMAND ----------

# MAGIC %run ../../rules

# COMMAND ----------

config['asset_name'] = 'promise_t_person'
config['data_system'] = 'Promise'

df = uc_read('promise_t_person')
df = clean(df)
df = format_names(df,['FIRST_NAME', 'LAST_NAME', 'FULL_NAME'])

# COMMAND ----------

def find_claimants(df):
    df = df.select(['PERSON_ID','FIRST_NAME', 'LAST_NAME', 'BIRTH_DATE','DATE_OF_DEATH','TAX_ID'])
    t_ins_cov = uc_read('promise_t_insured_coverage').select('LTC_ID', 'PRODUCT_ID', 'INSURED_PERSON_ID', 'INSURED_COVERAGE_ID', 'POLICY_NUMBER')
    t_prod = uc_read('promise_t_product').select('PRODUCT_ID', 'PRODUCT_NAME', 'PRODUCT_DESCRIPTION', 'TAX_QUALIFIED')
    claim_status_df = uc_read('promise_t_claim_status').select('CLAIM_ID', 'CLAIM_STATUS_CODE','CLAIM_SUB_STATUS_CODE', 'END_DATE')
    claim_df = uc_read('promise_t_claim').withColumnRenamed('PERSON_ID', 'CLAIM_PERSON_ID').select('CLAIM_PERSON_ID','INSURED_COVERAGE_ID','CLAIM_ID', 'CLAIM_NUMBER', 'CLAIM_SYSTEM').distinct()

    t_prod = t_prod.join(t_ins_cov, on='PRODUCT_ID', how='left').distinct()
    claim_df = claim_df.join(claim_status_df, on='CLAIM_ID', how='left_outer').distinct()
    claim_df = claim_df.join(t_prod, on='INSURED_COVERAGE_ID', how='left').distinct()

    df = df.join(claim_df, df['PERSON_ID'] == claim_df['CLAIM_PERSON_ID'], 'left')

    df = df.withColumn('Completeness: TAX_ID', f.when(df['CLAIM_NUMBER'].isNotNull() & df['TAX_ID'].isNull() & df['TAX_QUALIFIED'] == 'true', 'fail: tax qualifying claimant must have ssn').otherwise('pass: tax qualifying claimant must have ssn'))    
    df = df.filter(df['END_DATE'].isNull())
    summary = get_summary(df)
    return summary

# COMMAND ----------

#COMPLETENESS 
tax_id_completeness = find_claimants(df)

completeness_check_columns = ['GENDER', 'LAST_NAME', 'BIRTH_DATE', 'FIRST_NAME', 'FULL_NAME']
for column in completeness_check_columns:
    df = df.withColumn(f'Completeness: {column}', f.when((df[column].isNull()) & (df['PERSON_TYPE'] == 'PERSON'), 'fail: must contain non null value').otherwise('pass: must contain non null value'))

df = df.withColumn('Completeness: ENTITY_NAME', f.when((df['ENTITY_NAME'].isNull()) & (df['PERSON_TYPE'] == 'Entity'), 'fail: must contain non null value').otherwise('pass: must contain non null value'))

df = df.withColumn("Completeness: TELE_NUM, CELL_NUM, FAX_NUM", f.when(((df['CELL_PHONE_NUMBER'].isNull()) & (df['WORK_PHONE_NUMBER'].isNull()) & (df['HOME_PHONE_NUMBER'].isNull())) , 'fail: must contain non null value').otherwise('pass: must contain non null value'))

# #CONFORMITY
df = conformity_name(df, 'FIRST_NAME')
df = conformity_name(df, 'LAST_NAME')
df = conformity_name(df, 'FULL_NAME')
df = conformity_birthdate(df, 'BIRTH_DATE')
df = conformity_deathdate(df, 'DATE_OF_DEATH')
df = conformity_name(df, 'EMAIL_ADDRESS')
df = conformity_phone(df, 'CELL_PHONE_NUMBER')
df = conformity_phone(df, 'HOME_PHONE_NUMBER')
df = conformity_phone(df, 'WORK_PHONE_NUMBER')
df = conformity_gender(df, 'GENDER')
df = conformity_ssn(df, 'TAX_ID')

df = accuracy_birthdate(df, 'BIRTH_DATE')
df = accuracy_gender(df, 'GENDER')
df = accuracy_phone(df, 'CELL_PHONE_NUMBER')
df = accuracy_phone(df, 'HOME_PHONE_NUMBER')
df = accuracy_phone(df, 'WORK_PHONE_NUMBER')

# df = df.withColumn('Conformity: ENTITY_NAME', f.when(df['ENTITY_NAME'].rlike(r' {3,}'),'fail: Must Not Contain 3+ Spaces')    
#     .when(df['ENTITY_NAME'].rlike(r".*[?@#$%^*¬><!{}:}‹~¿_;:'|+=°®•].*"),"fail: Must Not Contain Any Invalid Punctuation [?@#$%^*¬><!{}:'}‹~¿_;:|+=°®•]")
#     .when(df['ENTITY_NAME'].rlike(r'^[estate]$'),"pass: Must Contain 'Estate' Keyword") 
#     .when(df['ENTITY_NAME'].rlike(r'^[A-Za-z0-9\s]+$'),'pass: Must Adhere to Expected Format')
#     .when(df['ENTITY_NAME'].isNull(), 'pass: No Entry').otherwise('fail: Must Adhere to Expected Format'))

# # df = df.withColumn('Conformity: FULL_NAME', check_full_name(f.col('FULL_NAME')))

# #ACCURACY
# df = df.withColumn('Accuracy: FULL_NAME', f.when((df["FULL_NAME"].contains(df["FIRST_NAME"]) & (df["FULL_NAME"].contains(df["LAST_NAME"]))),'pass: Must Contain FIRST_NAME & LAST_NAME').when(df['FULL_NAME'].isNull(), 'pass: No Entry').otherwise('fail: Must Contain FIRST_NAME & LAST_NAME')) 

# df = df.withColumn('Accuracy: TAX_ID', check_ssn('TAX_ID', 'ENTITY_NAME'))

# COMMAND ----------

# FINISH
summary = get_summary(df)
summary_df = summary_df.union(tax_id_completeness)

uc_write(summary)

# COMMAND ----------


