# Databricks notebook source
# MAGIC %run ../utils

# COMMAND ----------

from office365.runtime.auth.authentication_context import AuthenticationContext
from office365.runtime.auth.user_credential import UserCredential
from office365.sharepoint.files.creation_information import FileCreationInformation
from office365.sharepoint.client_context import ClientContext
from office365.runtime.auth.client_credential import ClientCredential
from office365.sharepoint.files.file import File 
import pandas as pd
import tempfile
import io
import os

# COMMAND ----------

def print_folder_contents(ctx, folder_url):
    try:
        folder = ctx.web.get_folder_by_server_relative_url(folder_url)
        fold_names = []
        sub_folders = folder.files #Replace files with folders for getting list of folders
        ctx.load(sub_folders)
        ctx.execute_query()

        for s_folder in sub_folders:
            fold_names.append(s_folder.properties["Name"])
        return fold_names

    except Exception as e:
        print('Problem printing out library contents: ', e)

def save_csv_to_sp(df, ctx):
    # Create a temporary CSV file from the DataFrame
    with tempfile.NamedTemporaryFile(mode='w+', suffix='.csv', delete=False) as tmp:
        df.to_csv(tmp.name, index=False)
        new_file_path = "/tmp/dq_score.csv"
    os.rename(tmp.name, new_file_path)

    # Upload the renamed file to SharePoint
    with open(new_file_path, 'rb') as file_content:
        file_info = FileCreationInformation()
        file_info.content = file_content.read()
        file_info.url = os.path.basename(new_file_path)  # Extract the new file name
        file_info.overwrite = True
        target_folder = ctx.web.get_folder_by_server_relative_url(folder)
        upload_file = target_folder.upload_file(file_info.url, file_info.content).execute_query()

    print(f'File {file_info.url} uploaded to SharePoint folder {folder}')
    os.remove(new_file_path)

def read_from_sp(ctx, file_name, folder):
    file_url = folder + '/' + file_name
    try:
        file = ctx.web.get_file_by_server_relative_url(file_url)
        response = File.open_binary(ctx, file_url)  # Correct method to get the file content
        with io.BytesIO(response.content) as stream:
            df = pd.read_csv(stream, encoding='windows-1254')
            return df
    except Exception as e:
        print('Error reading file from SharePoint:', e)

def get_ws():
    ws =[]
    dir = f"abfss://dataquality@{ENV['storage_account']}.dfs.core.windows.net/"
    output = dbutils.fs.ls(dir)
    for w in output:
        if w.name not in ['KPI/', 'PowerBI/', '_logs/', '_templates/', '_test/']:
            ws.append(w.name)
    return ws

def authenticate_sharepoint():
    client_id = ENV['client_id']
    client_secret = dbutils.secrets.get(scope=ENV['scope'], key=ENV['key'])
    sharepoint_site_url = 'https://mfc.sharepoint.com/sites/USDG'
    client_credentials = ClientCredential(client_id, client_secret)
    ctx = ClientContext(sharepoint_site_url).with_credentials(client_credentials)
    return ctx

# COMMAND ----------

