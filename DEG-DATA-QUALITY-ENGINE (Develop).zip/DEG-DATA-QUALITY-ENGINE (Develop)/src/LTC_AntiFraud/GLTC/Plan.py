# Databricks notebook source
# MAGIC %run ../../utils

# COMMAND ----------

# MAGIC %run ../ltc_utils

# COMMAND ----------

configure_spark()
config['asset_name'] = 'gltc_plan'
config['data_system'] = 'gltc'

df = uc_read('gltc_plan')
df = clean(df)

# COMMAND ----------

#Completeness
columns = ['Master_Case_Number', 'Group_Number', 'Class_Number']
for column in columns:
    df = completeness_check(df, column)

# COMMAND ----------

summary = get_summary(df)
uc_write(summary)
