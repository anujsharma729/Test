# Databricks notebook source
# MAGIC %run ../../utils

# COMMAND ----------

# MAGIC %run ../ltc_utils

# COMMAND ----------

# MAGIC %run ../../rules

# COMMAND ----------

config['asset_name'] = 'gltc_payment_data'
config['data_system'] = 'gltc'

df = uc_read('gltc_payment_data')
df = clean(df)

# COMMAND ----------

#Completeness
columns = ['Claim_ID', 'Check_Amount', 'Pay_Data_First_Name', 'Pay_Data_Last_Name', 'Address1', 'City', 'State', 'ZipCode', 'Status']
for column in columns:
    df = completeness_check(df, column)

df = conformity_addr1(df, 'Address1')
df = conformity_addr2(df, 'Address2')
df = conformity_addr3(df, 'Address3')
df = conformity_state(df, 'state')
df = conformity_city(df, 'city')
df = conformity_postalcode(df, 'ZipCode')

#Uniqueness
#Claim ID must not be unqiue

# COMMAND ----------

summary = get_summary(df)
uc_write(summary)

# COMMAND ----------


