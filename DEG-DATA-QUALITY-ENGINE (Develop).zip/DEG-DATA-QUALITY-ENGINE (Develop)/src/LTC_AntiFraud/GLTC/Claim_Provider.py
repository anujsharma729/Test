# Databricks notebook source
# MAGIC %run ../../utils

# COMMAND ----------

# MAGIC %run ../ltc_utils

# COMMAND ----------

config['asset_name'] = 'gltc_claim_provider'
config['data_system'] = 'gltc'

df = uc_read('gltc_claim_provider')
df = clean(df)

# COMMAND ----------

#Completeness
columns = ['ClaimProviderKey', 'Prov_Counter_Nbr', 'Claim_ID', 'Provider_Tax_ID_Nbr', 'Provider_Zip_Code']
for column in columns:
    df = completeness_check(df, column)

#Uniqueness
# Claim ID not necessarily unique as you can have multiple providers on one claim
# Provider Counter Number should be unique
columns = ['ClaimProviderKey', 'Prov_Counter_Nbr', 'Provider_Tax_ID_Nbr']
for column in columns:
    df = uniqueness_check(df, column)

# COMMAND ----------

summary = get_summary(df)
uc_write(summary)

# COMMAND ----------


