# Databricks notebook source
# MAGIC %run ../../utils

# COMMAND ----------

# MAGIC %run ../ltc_utils

# COMMAND ----------

# MAGIC %run ../../rules

# COMMAND ----------

config['data_system'] = 'gltc'
#CLAIM
df = uc_read('gltc_claim')
columns = ['New_Claim_ID', 'Claim_ID', 'Master_Case_Number', 'Coverage_Option','Claim_Reported_Date', 'Client_Member_ID', 'Claim_Approver']
for column in columns:  df = completeness_check(df, column)
for column in ['New_Claim_ID', 'Claim_ID']: df = uniqueness_check(df, column)
s1 = get_summary(df)
uc_write(s1)


#CLAIM PROVIDER
df = uc_read('gltc_claim_provider')
for column in ['ClaimProviderKey', 'Prov_Counter_Nbr', 'Claim_ID', 'Provider_Tax_ID_Nbr', 'Provider_Zip_Code']: df = completeness_check(df, column)
# Claim ID not necessarily unique as you can have multiple providers on one claim. Provider Counter Number should be unique
for column in ['ClaimProviderKey', 'Prov_Counter_Nbr', 'Provider_Tax_ID_Nbr']:df = uniqueness_check(df, column)
s2 = get_summary(df)
uc_write(s2)


#CLAIMSTATUS
df = uc_read('gltc_claim_status')
df = completeness_check(df, 'Claim_ID')
#Claim ID must not be unique
df = accuracy_check_value(df, 'Claim_Status_Code', ['T','A','P'])
s3 = get_summary(df)
uc_write(s3)


#CLAIMANT
df = uc_read('gltc_claimant')
columns = ['Master_Case_Nbr', 'Group_Nbr', 'Soc_Sec_Nbr', 'Client_Member_ID', 'Residence_State_Code', 'Last_Name', 'First_Name', 'Residence_Address1', 'Residence_City','Residence_Zip_Code','Claimant_Phone_Nbr', 'Sex_Code', 'Birth_Date', 'Issue_Age', 'LTCID']
for column in columns: df = completeness_check(df, column)
df = completeness_triple_dependency(df, 'Claimant_Phone_Nbr', 'Claimant_Work_Phone', 'Claimant_Cell_Phone')
df = conformity_addr1(df, 'Residence_Address1')
df = conformity_addr2(df, 'Residence_Address2')
df = conformity_addr3(df, 'Residence_Address3')
df = conformity_state(df, 'Residence_State_Code')
df = conformity_city(df, 'Residence_City')
df = conformity_postalcode(df, 'Residence_Zip_Code')
df = conformity_email(df, 'Claimant_Email')
df = conformity_ssn(df, 'Soc_Sec_Nbr')
#Client_Member_ID is not unique
df = uniqueness_check(df, 'Soc_Sec_Nbr')
s4 = get_summary(df)
uc_write(s4)


#PAYMENT
df = uc_read('gltc_payment_data')
for column in  ['Claim_ID', 'Check_Amount', 'Pay_Data_First_Name', 'Pay_Data_Last_Name', 'Address1', 'City', 'State', 'ZipCode', 'Status']: df = completeness_check(df, column)
df = conformity_addr1(df, 'Address1')
df = conformity_addr2(df, 'Address2')
df = conformity_addr3(df, 'Address3')
df = conformity_state(df, 'state')
df = conformity_city(df, 'city')
df = conformity_postalcode(df, 'ZipCode')
s5 = get_summary(df)
uc_write(s5)


# COMMAND ----------

