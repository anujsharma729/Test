# Databricks notebook source
# MAGIC %run ../../utils

# COMMAND ----------

# MAGIC %run ../ltc_utils

# COMMAND ----------

# MAGIC %run ../../rules

# COMMAND ----------

config['asset_name'] = 'gltc_claimant'
config['data_system'] = 'gltc'

df = uc_read('gltc_claimant')
df = clean(df)

# COMMAND ----------

#Completeness
columns = ['Master_Case_Nbr', 'Group_Nbr', 'Soc_Sec_Nbr', 'Client_Member_ID', 'Residence_State_Code', 'Last_Name', 'First_Name', 'Residence_Address1', 'Residence_City','Residence_Zip_Code','Claimant_Phone_Nbr', 'Sex_Code', 'Birth_Date', 'Issue_Age', 'LTCID']
for column in columns:
    df = completeness_check(df, column)

df = completeness_triple_dependency(df, 'Claimant_Phone_Nbr', 'Claimant_Work_Phone', 'Claimant_Cell_Phone')

df = conformity_addr1(df, 'Residence_Address1')
df = conformity_addr2(df, 'Residence_Address2')
df = conformity_addr3(df, 'Residence_Address3')
df = conformity_state(df, 'Residence_State_Code')
df = conformity_city(df, 'Residence_City')
df = conformity_postalcode(df, 'Residence_Zip_Code')
df = conformity_email(df, 'Claimant_Email')
df = conformity_ssn(df, 'Soc_Sec_Nbr')

#Uniqueness
#Client_Member_ID is not unique
df = uniqueness_check(df, 'Soc_Sec_Nbr')

# COMMAND ----------

summary = get_summary(df)
# uc_write(summary)

# COMMAND ----------


