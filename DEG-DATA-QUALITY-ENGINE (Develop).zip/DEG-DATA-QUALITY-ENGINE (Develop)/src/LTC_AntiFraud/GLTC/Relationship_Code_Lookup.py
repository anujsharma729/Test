# Databricks notebook source
# MAGIC %run ../../utils

# COMMAND ----------

# MAGIC %run ../ltc_utils

# COMMAND ----------

configure_spark()
config['asset_name'] = 'gltc_relationship_code_lookup'
config['data_system'] = 'gltc'

df = uc_read('gltc_relationship_code_lookup')
df = clean(df)

# COMMAND ----------

#Completeness
columns = ['Relationship', 'Text']
for column in columns:
    df = completeness_check(df, column)

# COMMAND ----------

summary = get_summary(df)
uc_write(summary)
