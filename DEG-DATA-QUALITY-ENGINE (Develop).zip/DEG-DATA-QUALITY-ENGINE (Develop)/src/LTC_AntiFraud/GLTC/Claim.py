# Databricks notebook source
# MAGIC %run ../../utils

# COMMAND ----------

# MAGIC %run ../ltc_utils

# COMMAND ----------

config['asset_name'] = 'gltc_claim'
config['data_system'] = 'gltc'
df = uc_read('gltc_claim')
df = clean(df)

# COMMAND ----------

#Completeness
columns = ['New_Claim_ID', 'Claim_ID', 'Master_Case_Number', 'Coverage_Option','Claim_Reported_Date', 'Client_Member_ID', 'Claim_Approver']
for column in columns:
    df = completeness_check(df, column)

#Uniqueness
columns = ['New_Claim_ID', 'Claim_ID']
for column in columns:
    df = uniqueness_check(df, column)

# COMMAND ----------

summary = get_summary(df)
uc_write(summary)
