# Databricks notebook source
# MAGIC %run ../../utils

# COMMAND ----------

# MAGIC %run ../ltc_utils

# COMMAND ----------

configure_spark()
config['asset_name'] = 'gltc_claim_status'
config['data_system'] = 'gltc'

df = uc_read('gltc_claim_status')
df = clean(df)

# COMMAND ----------

#Completeness
df = completeness_check(df, 'Claim_ID')

#Uniqueness
#Claim ID must not be unique
#Accuracy
df = df.withColumn('Accuracy: Claim_Status_Code', f.when(df['Claim_Status_Code'].rlike(r'^[TAP]$'),'pass: must contain T,A or P').otherwise('fail: must contain T,A or P'))

# COMMAND ----------

summary = get_summary(df)
uc_write(summary)
