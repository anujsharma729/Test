# Databricks notebook source
# MAGIC %run ../../utils

# COMMAND ----------

# MAGIC %run ../ltc_utils

# COMMAND ----------

# MAGIC %run ./Claim

# COMMAND ----------

# MAGIC %run ./Claim_Provider

# COMMAND ----------

# MAGIC %run ./Claim_Status

# COMMAND ----------

# MAGIC %run ./Claimant

# COMMAND ----------

# MAGIC %run ./Payment_Data

# COMMAND ----------

# MAGIC %run ./Plan

# COMMAND ----------

# MAGIC %run ./Relationship_Code_Lookup
