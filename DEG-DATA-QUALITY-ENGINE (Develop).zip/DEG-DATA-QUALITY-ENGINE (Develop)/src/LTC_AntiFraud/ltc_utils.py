# Databricks notebook source
# MAGIC %run ../utils

# COMMAND ----------

import re
import datetime
from pyspark.sql.window import Window
from pyspark.sql.functions import col, row_number, when, lit
REFERENCE_DATE = '1900-01-01'
SYSTEM_DEFAULT = '9999-12-31'
system = "lifepro"

# COMMAND ----------

def syn_read_asset(table_name):
    jdbcUrl = f"jdbc:sqlserver://ihub-usdo-syn-prod.sql.azuresynapse.net:1433;database=syndp001;user={syn_user};password={syn_pw};encrypt=true;trustServerCertificate=false;hostNameInCertificate=*.sql.azuresynapse.net;loginTimeout=30;authentication=ActiveDirectoryPassword"
    synapse_table = f"ltc_buffer.{table_name}"
    df = spark.read.format("jdbc").option("url",jdbcUrl ).option("dbtable",synapse_table).load()
    return df

def uc_read(asset):
    df = spark.sql(f"SELECT * FROM usdo_prod_catalog.silver_ltc_ext.{asset}")
    config['parent_dir'] = f"usdo_prod_catalog.silver_ltc_ext.{asset}"
    config['asset_name'] = asset 
    return df

# COMMAND ----------

#CONFIGURATION FOR TABLES
PRELA = "lifepro20_prela_relationship_master"
PPOLC = "lifepro20_ppolc"
UC_PATH = "usdo_prod_catalog.silver_ltc_ext"
uc_table = "dq_summary_legacy"

config['work_stream'] = 'long term care'
config['data_system'] =  system
config['data_owner'] = 'Charles Wiergersma'
config['business_unit'] = 'Long Term Care (US)'
config['data_domain'] = 'Policy'
config['rule_owner'] = 'Dale Armagost'
# config['parent_dir'] = UC_PATH
config['asset_name'] = asset

adls_path = "ltc_ext/parquet/ltc_buffer/"

# COMMAND ----------

def value_counts(df, column):
    value_counts_df = df.groupBy(column).count().orderBy(f.col("Count").desc(),f.asc(column))
    display(value_counts_df)
    return value_counts_df
    
def print_dataframe_as_dict(spark_df):
    # Collect the DataFrame rows to the driver
    rows = spark_df.collect()
    
    # Convert rows to dictionary
    rows_as_dict = [row.asDict() for row in rows]
    
    # Print the dictionarysystem
    print(rows_as_dict)

def get_current_data(df, ids, dates):
    # Define a window partitioned by the composite key and ordered by date_updated descending
    window_spec = Window.partitionBy(ids).orderBy(col(dates).desc())

    # Add a row number to each partition
    df_with_rownum = df.withColumn("row_num", row_number().over(window_spec))

    # Filter to keep only the first row (most recent date_updated) per group
    filtered_df = df_with_rownum.filter(col("row_num") == 1).drop("row_num")
    return filtered_df

# COMMAND ----------

### FORMAT DATAFRAMES #######
def clean(df):
    for c in df.columns:
        # df = df.withColumn(c, f.lower(f.trim(f.col(c))))
        df = trim(df)
        df = df.withColumn(c, f.regexp_replace(c, r"[-#$!?]", ""))
        df = df.withColumn(c, f.when((f.col(c) == "") | (f.col(c).rlike(r"^(0[\s]?){1,}$")), None).otherwise(f.col(c)))
        

        if 'ADDR' in c:
            df = df.withColumn(c, f.regexp_replace(f.col(c), r'\b[Pp]\.? ?[Oo]\.? ?[Bb]ox\b', 'PO Box'))
            df = df.withColumn(c, f.regexp_replace(f.col(c), r'\bAttn?:?\s?', 'ATTN: '))
            df = df.withColumn(c, f.regexp_replace(f.col(c), r'\bAttention:?\s?:?', 'ATTN: '))
            df = df.withColumn(c, f.regexp_replace(f.col(c), r'\bFbo?:?\s?', 'FBO: '))
            df = df.withColumn(c, f.regexp_replace(f.col(c), r'\bC[/\\]?o:?\s?', 'C/O: '))
        if 'phone' in c.lower() or 'tele' in c.lower() or 'cell' in c.lower():
            df = clean_phonenumbers(df, c)
    return df

def clean_phonenumbers(df, c):
    df = df.withColumn(c, f.regexp_replace(c, r"[-() ]", ""))
    return df

def trim(df, columns=None):
    if columns == None: columns = df.columns
    for column in columns:
        df = df.withColumn(column, f.ltrim(f.rtrim(df[column])))
    return df
    
def format_address(df, columns=None):
    if columns is None:
        columns = df.columns
    for c in columns:
        df = df.withColumn(c, f.initcap(df[c]))
        df = df.withColumn(c, f.regexp_replace(f.col(c), r'\b[Pp]\.? ?[Oo]\.? ?[Bb]ox\b', 'PO Box'))
        df = df.withColumn(c, f.regexp_replace(f.col(c), r'\bAttn?:?\s?', 'ATTN: '))
        df = df.withColumn(c, f.regexp_replace(f.col(c), r'\bAttention:?\s?:?', 'ATTN: '))
        df = df.withColumn(c, f.regexp_replace(f.col(c), r'\bFbo?:?\s?', 'FBO: '))
        df = df.withColumn(c, f.regexp_replace(f.col(c), r'\bC[/\\]?o:?\s?', 'C/O: '))
    return df
def format_names(df, columns=None):
    if columns is None:
        columns = df.columns

    replacements = [
        (r"(?<=\S)&(?=\S)", " & "),
        (r"(?<=\S)& ", " & "),
        (r" &(?=\S)", " & "),
        (r"\.&", ". &"),
        (r"^Mrs\.?\s{1}", "Mrs. "),
        (r"Mrs(?=\b|$)", "Mrs."),
        (r"^Ms\.?\s{1}", "Ms. "),
        (r"^Mr\.?\s{1}", "Mr. "),
        (r"Mr(?=\b|$)", "Mr."),
        (r"^Miss\.?\s{1}", "Miss. "),
        (r"^Dr\.?\s{1}", "Dr. "),
        (r"^Jr\.?\s{1}", "Jr. "),
        (r"Jr(?=\b|$)", "Jr."),
        (r"^Sr\.?\s{1}", "Sr. "),
        (r"^Md\.?\s{1}", "MD. "),
        (r"\s*-\s*", "-"),
        (r"\s*'\s*", "'"),
        (r"\bC[/\\]?o:?\s?", "C/O: "),
        (r"\bC[/\\]?o\b", "C/O: "),
        (r"(\b[A-Z])\b(?![.'-])", r"\1."),
        (r"\b([A-Z])\b(?= \w)", r"\1."),
        (r"\.([A-Za-z])", r". \1")
    ]

    for column in columns:
        df = df.withColumn(column, f.initcap(f.col(column)))
        for pattern, replacement in replacements:
            df = df.withColumn(column, f.regexp_replace(f.col(column), pattern, replacement))

    return df


# COMMAND ----------

@f.udf
def check_ssn(number, entity):
    if number is None: return 'pass: No Entry'
    area = number[:3]
    group = number[3:5]
    serial = number [5:]

    #TIN - Individual Taxpayer Identification Number for foreign nationals and other individuals who are not elligible for a SSN to comply with U.S. tax laws
    #SSN - Social Security Number for all US citizens and elligible residents
    #EIN - Employer Identification Number
    #ATIN - Adoption Identificaiton Number 
    #Source = https://www.irs.gov/pub/irs-pdf/p4164.pdf

    if (len(number) == 9) & (number.isnumeric()) & (entity is None):
        #TIN Must start with 9
        if (number[0] == '9'):
            if ((50 <= int(group) <= 65) or (70 <= int(group) <= 88) or (90 <= int(group) <= 92) or (94 <= int(group) <= 99)):
                return 'pass: must conform to irs rules'
            elif (number[0] == '9') & (int(group) == 93):
                return 'pass: must conform to irs rules'
            else: return 'fail: must conform to irs rules'
        
        #SSN Cannot Start with 9
        elif area == '000' or area == '666': 
            #area three digits (area number) cannot be 000 or 666 or start with 9
            return 'fail: must conform to irs rules'
        elif group == '00':
            #group two digits (Group Number) cannot start with 00
            return 'fail: must conform to irs rules'
        elif serial == '0000':
            return 'fail: must conform to irs rules'
        return 'pass: must conform to irs rules'

    elif (len(number) == 9) & (number.isnumeric()) & (entity is not None) : #EIN
        if (number[0] == '00') | (number[0] == '07') | (number[0] == '08') | (number[0] == '09'):
            return 'fail: must conform to irs rules'
        elif number[:2] == '98':
            return 'pass: must conform to irs rules'
        return 'pass: must conform to irs rules'
    
    elif any(char.isalpha() for char in number):
            return 'fail: must conform to irs rules' 
    else:
        return 'fail: must conform to irs rules'

# COMMAND ----------

@f.udf
def check_compeleteness_double_dependency(first, last, business, relationship):
    if first is None and last is None:
        if business is None:
            if relationship is not None: return 'fail: Policy Holder Must Have This Field Completed'
            else: return 'fail: First Name, Last Name and Business Name Cannot All Be Blank'
        else: 
            if relationship is not None: return 'fail: Policy Holder Cannot Have Business Name Field Completed'
            else: return 'pass: First Name, Last Name and Business Name Cannot All Be Blank'
    elif (first is None and last is not None):
        if relationship is not None: return 'fail: Policy Holder Must have Completed First Name'
        else: return 'fail: Must Contain Completed First Name & Last Name'
    elif (first is not None and last is None):
        if relationship is not None: return 'fail: Policy Holder Must have Completed Last Name'
        else: return 'fail: Must Contain Completed First Name & Last Name'
    elif first is not None and last is not None: 
        return 'pass: Must Contain Completed First Name & Last Name'

# COMMAND ----------

@f.udf
def is_accurate_claim_number(number):
    company_codes = {'FIC   ', 'FBIC  ', 'FFLIC ', 'BCBSSC', 'FDLTY ', 'JH    ', 'JHLH  '}
    cspp_codes = {'JHC2','JHLHL', 'JHC', 'JHLHC'}

    if len(number) == 12 and (number[:6] in company_codes) and (number[6:].isnumeric()):
        return f'pass: must contain valid cspp/company code'
    elif number.startswith('R') and len(number) == 9 and number[1:].isnumeric():
        return 'pass: must contain valid cspp/company code'
    elif number.startswith('C-') and len(number) == 8:
        return 'pass: must contain valid cspp/company code'
    if len(number) < 6:
        return 'fail: must contain valid cspp/company code'
    elif number.split(' ')[0] in cspp_codes:
        return f'pass: must contain valid cspp/company code'
    elif (number[:6].endswith(" ")):
        return 'fail: must contain valid cspp/company code'
    for code in cspp_codes:
        if code in number: return f'pass: must contain valid cspp/company code'
    return 'fail: must contain valid cspp/company code'

# COMMAND ----------

def get_prela(df, join_type = None, relate_code = None, distinct_nameid = False):
    prela_df = read_asset(**prela_config)
    if (join_type is None) & (relate_code is None) & (distinct_nameid is False):
        return prela_df
    if relate_code is not None:
        filtered_df = prela_df.filter(prela_df['RELATE_CODE'] == relate_code)
    if distinct_nameid: 
        filtered_df = prela_df.select('NAME_ID').distinct()
    if join_type is not None:
        columns = df.columns
        prela_df = prela_df.withColumnRenamed('NAME_ID', 'PRELA_NAME_ID')
        filtered_df = df.join(prela_df, df['NAME_ID'] == prela_df["PRELA_NAME_ID"], join_type)
        filtered_df = filtered_df.withColumn("In Prela (Y/N)", f.when(filtered_df['RELATE_CODE'].isNotNull(), "Y").otherwise("N"))
        filtered_df = filtered_df.select('In Prela (Y/N)', *columns)
    return filtered_df
