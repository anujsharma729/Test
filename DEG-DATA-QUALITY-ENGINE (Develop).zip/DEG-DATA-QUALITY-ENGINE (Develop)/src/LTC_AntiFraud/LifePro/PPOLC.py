# Databricks notebook source
# MAGIC %run ../../utils

# COMMAND ----------

# MAGIC %run ../ltc_utils

# COMMAND ----------

# MAGIC %run ../../rules

# COMMAND ----------

config['asset_name'] = 'lifepro20_ppolc'

df = uc_read('lifepro20_ppolc').select('POLICY_NUMBER', 'PRODUCT_CODE', 'CONTRACT_CODE', 'ISSUE_STATE', 'ANNUAL_PREMIUM', 'BILLING_MODE', 'LAST_CHANGE_DATE','APPLICATION_DATE', 'PAID_TO_DATE', 'ISSUE_DATE', 'CONTRACT_DATE')
df = get_current_data(df, 'POLICY_NUMBER', 'LAST_CHANGE_DATE')
df = clean(df)
for column in ['LAST_CHANGE_DATE', 'APPLICATION_DATE', 'PAID_TO_DATE', 'ISSUE_DATE', 'CONTRACT_DATE']:
    df = df.withColumn(column, f.to_date(f.col(column).cast("string"), "yyyyMMdd"))

# COMMAND ----------

#COMPLETENESS
CDE = ['POLICY_NUMBER', 'PRODUCT_CODE', 'CONTRACT_CODE', 'ISSUE_STATE', 'ANNUAL_PREMIUM']
for column in CDE: 
        df = completeness_check(df, column)

#CONFORMITY
df = conformity_policynumber(df, 'POLICY_NUMBER')

df = df.withColumn("Conformity: ANNUAL_PREMIUM",f.when(f.col("ANNUAL_PREMIUM").cast("double").isNotNull(), 'pass: must contain decimal value').otherwise('fail: must contain decimal value'))

#ACCURACY

# CONTRACT_CODE Status for Policy: A - ACTIVE, P - PENDING, T - TERMINATED, S - SUSPENDED 
df = accuracy_check_value(df, 'CONTRACT_CODE', =['A', 'T', 'S', 'P'])

# CONTRACT_REASON Substatus for policy: DC - Death Claim, LP - Lapsed, RI - Reinstated, SR - Surrendered

#BILLING_MODE Code representing the premium payment period/term [1: Monthly, 3: Quarterly, 6: Semi-Annually, 12: Annually]
df = accuracy_check_value(df, 'BILLING_MODE', ["1", "3", "6", "12"])

df = accuracy_check_value(df, 'ISSUE_STATE', US_STATES)

#ANNUAL PREMIUM = MODE_PREMIUM * BILLING_MODE
# df = df.withColumn("annual_premium_calculated", f.when(f.col("BILLING_MODE") == 1, f.col("MODE_PREMIUM") * 12)  # Monthly payments
#     .when(f.col("BILLING_MODE") == 12, f.col("MODE_PREMIUM") * 1)  # Yearly payment
#     .when(f.col("BILLING_MODE") == 3, f.col("MODE_PREMIUM") * 4)  # Quarterly payments
#     .when(f.col("BILLING_MODE") == 6, f.col("MODE_PREMIUM") * 2)  # Semi-annual payments
#     .otherwise(None))  # Handle unexpected BILLING_MODE values
    

# COMMAND ----------

summary= get_summary(df)
uc_write(summary)

# COMMAND ----------


