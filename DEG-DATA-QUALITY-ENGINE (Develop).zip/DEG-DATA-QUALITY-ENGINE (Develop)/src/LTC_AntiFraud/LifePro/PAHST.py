# Databricks notebook source
# MAGIC %run ../../utils
# MAGIC

# COMMAND ----------

# MAGIC %run ../ltc_utils

# COMMAND ----------

# MAGIC %run ../../rules

# COMMAND ----------

config['asset_name'] = 'lifepro20_pahst'
df = uc_read('lifepro20_pahst')
# df = get_current_data(df, 'ADDRESS_ID', ['DATE_STAMP', 'TIME_STAMP'])
df = clean(df)
df = format_address(df, ['ADDR_LINE_1', 'ADDR_LINE_2', 'ADDR_LINE_3', 'CITY'])

# COMMAND ----------

#COMPLETENESS
completeness_check_columns = ['ADDR_LINE_1', 'City', 'STATE', 'ZIP']
for column in completeness_check_columns:
    df = completeness_check(df, column)

#CONFORMITY
df = conformity_addr1(df, 'ADDR_LINE_1')
df = conformity_addr2(df, 'ADDR_LINE_2')
df = conformity_addr3(df, 'ADDR_LINE_3')
df = conformity_city(df, 'City')
df = conformity_state(df, 'STATE')
df = conformity_postalcode(df, 'ZIP')
df = accuracy_city(df, 'City')

# COMMAND ----------

summary = get_summary(df)
uc_write(summary)
