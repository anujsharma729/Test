# Databricks notebook source
# MAGIC %run ../../utils

# COMMAND ----------

# MAGIC %run ../ltc_utils

# COMMAND ----------

# MAGIC %run ../../rules

# COMMAND ----------

config['asset_name'] = 'lifepro20_plhst'
df = uc_read(config['asset_name'])
# df = get_current_data(df, 'NAME_ID', ['DATE_STAMP', 'TIME_STAMP'], 'ADDRESS_ID')
df = clean(df)

prela = uc_read('lifepro20_prela_relationship_master')
prela = prela.filter(prela['RELATE_CODE'] == 'IN').distinct()
df = df.join(prela, on='NAME_ID', how='left_outer')

# COMMAND ----------

for column in ["TELE_NUM", "CELL_NUM", "FAX_NUM"]:
    df = df.withColumn(f'Completeness: {column}', f.when(df['RELATE_CODE'].isNotNull() & df['TELE_NUM'].isNull() & df['CELL_NUM'].isNull() & df['FAX_NUM'].isNull(), 'fail: policy holder must have atleast one phone number').otherwise('pass: policy holder must have atleast one phone number'))

    df = conformity_phone(df, column)
    df = accuracy_phone(df, column)

# COMMAND ----------

summary = get_summary(df)
uc_write(summary)
