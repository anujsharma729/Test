# Databricks notebook source
# MAGIC %run ../../utils

# COMMAND ----------

# MAGIC %run ../../rules

# COMMAND ----------

# MAGIC %run ../ltc_utils

# COMMAND ----------

ppolc = uc_read('lifepro20_ppolc').select('POLICY_NUMBER', 'CONTRACT_CODE', 'CONTRACT_REASON')
ppolc = trim(ppolc)
prela = uc_read('lifepro20_prela_relationship_master')
prela = prela.filter(prela['RELATE_CODE'] == 'IN').distinct()

#PAHST
try:
    df = uc_read('lifepro20_pahst')
    df = clean(df)
    df = format_address(df, ['ADDR_LINE_1', 'ADDR_LINE_2', 'ADDR_LINE_3', 'CITY'])

    for column in ['ADDR_LINE_1', 'City', 'STATE', 'ZIP']:
        df = completeness_check(df, column)

    df = conformity_addr1(df, 'ADDR_LINE_1')
    df = conformity_addr2(df, 'ADDR_LINE_2')
    df = conformity_addr3(df, 'ADDR_LINE_3')
    df = conformity_city(df, 'City')
    df = conformity_state(df, 'STATE')
    df = conformity_postalcode(df, 'ZIP')
    df = accuracy_city(df, 'City')
    s1 = get_summary(df)
    uc_write(s1)
except Exception as e:
    print(e)

#PAGNT
try: 
    df = uc_read('lifepro20_pagnt_agent_master')
    for column in ['COMPANY_CODE', 'STATUS_CODE','AGENT_NUMBER']:
        df = completeness_check(df, column)
    s2 = get_summary(df)
    uc_write(s2)
except Exception as e:
    print(e)
    #PCNFO
try:
    df = uc_read('lifepro20_pcnfo')
    df = clean(df)
    df = df.filter(df.DATE_UPDATED.isNull())
    for column in  ['COMPANY_CODE', 'POLICY_NUMBER', 'CNFO_STATUS', 'EFFECTIVE_DATE']:
        df = completeness_check(df, column)
    df = uniqueness_check(df, 'POLICY_NUMBER')
    df = conformity_policynumber(df, 'POLICY_NUMBER')
    s3 = get_summary(df)
    uc_write(s3)
except Exception as e:
    print(e)

#PCLMH
try: 
    df = uc_read('lifepro20_pclmh')
    df = clean(df)
    for column in ['COMPANY_CODE', 'POLICY_NO', 'CLAIM_NO', 'CLAIM_DETAIL_SEQ']:
        df = completeness_check(df, column)

    #CLAIM_DETAIL_SEQ represents payment transactions. Each CLAIM_NO should have a unique CLAIM_DETAIL_SEQ but they can also have multiple CDS
    df = uniqueness_check(df, ['CLAIM_NO','CLAIM_DETAIL_SEQ']) #can filter to most recent date
    s4 = get_summary(df)
    uc_write(s4)
except Exception as e:
    print(e)

#PHLST
try:
    df = uc_read('lifepro20_plhst')
    df = clean(df)
    df = df.join(prela, on='NAME_ID', how='inner')

    df = completeness_triple_dependency(df, "TELE_NUM", "CELL_NUM", "FAX_NUM")
    for column in ["TELE_NUM", "CELL_NUM", "FAX_NUM"]:
        df = conformity_phone(df, column)
        df = accuracy_phone(df, column)
    s5 = get_summary(df)
    uc_write(s5)
except Exception as e:
    print(e)

#PPBEN
try:
    df = uc_read('lifepro20_ppben_policy_benefits')
    df = clean(df)
    for column in ['POLICY_NUMBER', 'STATUS_CODE', 'COMPANY_CODE', 'PLAN_CODE', 'PBEN_ID']:
        df = completeness_check(df, column)

    df = conformity_policynumber(df, 'POLICY_NUMBER')
    df = conformity_check_alphabetic_value(df, 'STATUS_CODE')
    df = accuracy_check_value(df, 'STATUS_CODE', ["A", "T", "P"])
    s6 = get_summary(df)
    uc_write(s6)
except Exception as e:
    print(e)

#PPOLC
try:
    df = uc_read('lifepro20_ppolc')
    df = get_current_data(df, 'POLICY_NUMBER', 'LAST_CHANGE_DATE')
    df = df.select('POLICY_NUMBER', 'PRODUCT_CODE', 'CONTRACT_CODE', 'ISSUE_STATE', 'ANNUAL_PREMIUM', 'BILLING_MODE', 'PAID_TO_DATE', 'ISSUE_DATE', 'CONTRACT_DATE')
    df = clean(df)
    for column in ['POLICY_NUMBER', 'PRODUCT_CODE', 'CONTRACT_CODE', 'ISSUE_STATE', 'ANNUAL_PREMIUM']: 
        df = completeness_check(df, column)
    df = conformity_policynumber(df, 'POLICY_NUMBER')
    df = accuracy_check_value(df, 'CONTRACT_CODE', ['A', 'T', 'S', 'P'])
    df = accuracy_check_value(df, 'BILLING_MODE', ["1", "3", "6", "12"])
    df = accuracy_state_us(df, 'ISSUE_STATE')
    s7 = get_summary(df)
    uc_write(s7)
except Exception as e:
    print(e)

# COMMAND ----------

# PCLMR
try:
    df = uc_read('lifepro20_pclmr_claim_master_record')
    df = clean(df)

    for column in df.columns: 
        if 'DATE_' in column:
            df = format_dates(df, column)

    df = df.join(ppolc, on='POLICY_NUMBER', how='left')
    completeness_check_columns = ['POLICY_NUMBER', 'CLAIM_NUMBER', 'COMPANY_CODE', 'PATIENT_NAME_ID', 'INSURED_NAME_ID']
    for column in completeness_check_columns:
        df = completeness_check(df, column)

    df = uniqueness_check(df, 'CLAIM_NUMBER')

    df = conformity_policynumber(df, 'POLICY_NUMBER')
    rule = "must be company/cspp code followed by spaces for first 6 characters"
    df = df.withColumn("Conformity: CLAIM_NUMBER", f.when(df['CLAIM_NUMBER'].rlike(r'^[A-Z ]{1,6}\d{1,8}$'), f'pass: {rule}')
        .when(df['CLAIM_NUMBER'].rlike(r'^[JHC2]+[ ]{1,2}\d{1,6}'), f'pass: {rule}')
        .when(df['CLAIM_NUMBER'].rlike(r'^C-\d{1,6}$'), f'pass: {rule}')
        .when(df['CLAIM_NUMBER'].isNull(), f'pass: {rule}').otherwise(f'fail: {rule}'))

    #[1: Incomplete, 2: Pending, 3: Open, 4: Closed, 5: Re-Opened, 6: Rejected, 7: History]
    df = accuarcy_between(df, 'STATUS_CODE', 1, 7)
    df = df.withColumn('Accuracy: CLAIM_NUMBER', is_accurate_claim_number(df['CLAIM_NUMBER']))
    df = df.withColumn('Accuracy: STATUS_CODE', f.when((df['CONTRACT_CODE'] == 'T') & (df['STATUS_CODE'].isin([1, 2, 3, 5])), 'fail: claims cannot be pending or active for terminated policies').otherwise('pass: claims cannot be pending or active for terminated policies'))
    df = df.withColumn('Timeliness: STATUS_CODE', f.when((df['STATUS_CODE'] == 2) & (f.datediff(f.current_date(), df['DATE_ADDED']) > 60), 'fail: claims must be opened/closed within 60 days').otherwise('pass: claims must be opened/closed within 60 days'))
    s8 = get_summary(df)
    uc_write(s8)
except Exception as e:
    print(e)

# COMMAND ----------

#PNAME
try:
    df = uc_read('lifepro20_pname')
    df = clean(df)
    df = format_dates(df, ['DATE_OF_BIRTH', 'DEATH_DATE'])
    df = format_names(df, ['INDIVIDUAL_FIRST', 'INDIVIDUAL_LAST'])

    df = df.join(prela, on='NAME_ID', how='left_outer')

    for column in ['DATE_OF_BIRTH', 'SSN_BTC_HASH', 'SEX_CODE']:
        df = completeness_with_dependency(df, column, 'RELATE_CODE', 'IN')

    df = completeness_triple_dependency(df, 'INDIVIDUAL_FIRST', 'INDIVIDUAL_LAST', 'NAME_BUSINESS')
    df = completeness_with_dependency(df, 'INDIVIDUAL_FIRST', "RELATE_CODE", 'IN', "policy holder must have completed first name")
    df = completeness_with_dependency(df, 'INDIVIDUAL_LAST', "RELATE_CODE", 'IN', 'policy holder must have completed last name')

    
    df = conformity_name(df, 'INDIVIDUAL_FIRST')
    df = conformity_name(df, 'INDIVIDUAL_LAST')
    df = conformity_business(df, 'NAME_BUSINESS')
    df = conformity_deathdate(df, 'DEATH_DATE')
    df = conformity_birthdate(df, 'DATE_OF_BIRTH')
    df = conformity_gender(df, 'SEX_CODE')
    df = conformity_ssn(df, 'SSN_BTC_HASH')

    df = df.withColumn('Accuarcy: SSN_BTC_HASH',  f.when(df['SSN_BTC_HASH'] == df['NAME_ID'], 'fail: must not be NAME_ID'))
    df = accuracy_birthdate(df, 'DATE_OF_BIRTH')
    df = accuracy_deathdate(df, 'DEATH_DATE')
    df = accuracy_gender(df, 'SEX_CODE')
    s9 = get_summary(df)
    uc_write(s9)
except Exception as e:
    print(e)
