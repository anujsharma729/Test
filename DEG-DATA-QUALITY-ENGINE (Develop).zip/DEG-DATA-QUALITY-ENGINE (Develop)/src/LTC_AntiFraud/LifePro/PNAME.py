# Databricks notebook source
# MAGIC %run ../../utils

# COMMAND ----------

# MAGIC %run ../ltc_utils

# COMMAND ----------

# MAGIC %run ../../rules

# COMMAND ----------

config['asset_name'] = 'lifepro20_pname'
df = uc_read('lifepro20_pname')
df = clean(df)
df = df.withColumn("DATE_OF_BIRTH", f.to_date(f.col("DATE_OF_BIRTH").cast("string"), 'yyyyMMdd'))
df = df.withColumn("DEATH_DATE", f.to_date(f.col("DEATH_DATE").cast("string"), 'yyyyMMdd'))
df = format_names(df, ['INDIVIDUAL_FIRST', 'INDIVIDUAL_LAST'])

prela = uc_read('lifepro20_prela_relationship_master')
prela = prela.filter(prela['RELATE_CODE'] == 'IN').drop('IDENTIFYING_ALPHA').distinct()
df = df.join(prela, on='NAME_ID', how='left_outer')

# COMMAND ----------

#COMPLETENESS
completeness_check_columns = ['DATE_OF_BIRTH', 'SSN_BTC_HASH', 'SEX_CODE']
compelteness_double_dependency_colums = ['INDIVIDUAL_FIRST', "INDIVIDUAL_LAST", 'NAME_BUSINESS']

for column in completeness_check_columns:
    df = df.withColumn(f'Completeness: {column}', f.when((f.col('RELATE_CODE').isNotNull()) & f.col(column).isNull(), 'fail: Policy Holder Must Have This Field Completed').otherwise('pass: Policy Holder Must Have This Field Completed'))

for column in compelteness_double_dependency_colums:
    df = df.withColumn('Completeness: ' + column, check_compeleteness_double_dependency(f.col('INDIVIDUAL_FIRST'), f.col('INDIVIDUAL_LAST'), f.col('NAME_BUSINESS'),f.col('RELATE_CODE')))

#CONFORMITY
df = conformity_name(df, 'INDIVIDUAL_FIRST')
df = conformity_name(df, 'INDIVIDUAL_LAST')

df = df.withColumn('Conformity: NAME_BUSINESS', f.when(df['NAME_BUSINESS'].rlike(r' {3,}'),'fail: Must Not Contain 3+ Spaces')
    .when(df['NAME_BUSINESS'].rlike(r'^[A-Za-z0-9\s]+$'),'fail: Must Not Contain Double Spaces')
    .when(df['NAME_BUSINESS'].rlike(r".*[?@#$%^&*¬><!{}:'}‹~¿_–`;:'|+=°®•].*"),"fail: Must Not Contain Any Invalid Punctuation .*[?@#$%^&*¬><!{}:'‹~¿_–`;:'|+=°®•].*")
    .when(df['NAME_BUSINESS'].rlike(r'^[A-Za-z0-9\s]+$'),'pass: Must adhere to Expected Format')
    .when(df['NAME_BUSINESS'].isNull(), 'pass: No Entry').otherwise('fail: Must adhere to Expected Format'))

df = conformity_deathdate(df, 'DEATH_DATE')
df = conformity_birthdate(df, 'DATE_OF_BIRTH')
df = conformity_gender(df, 'SEX_CODE')
df = conformity_ssn(df, 'SSN_BTC_HASH')

df = df.withColumn('Accuarcy: SSN_BTC_HASH',  f.when(df['SSN_BTC_HASH'] == df['NAME_ID'], 'fail: must not be NAME_ID'))
df = accuracy_birthdate(df, 'DATE_OF_BIRTH')
df = accuracy_deathdate(df, 'DEATH_DATE')
df = accuracy_gender(df, 'SEX_CODE')

df = df.withColumn('Accuracy: SSN_BTC_HASH', check_ssn(f.col("SSN_BTC_HASH"), f.col('NAME_BUSINESS')))

df = df.withColumn('Accuracy: NAME_BUSINESS', f.when(df['NAME_BUSINESS'] == 'NONE', 'fail: must contain business name').otherwise('pass: must contain business name'))


# COMMAND ----------

def find_missing_ssn_in_promise(df):
    df = df.select(['NAME_ID', 'INDIVIDUAL_FIRST','INDIVIDUAL_LAST', 'DATE_OF_BIRTH','SSN_BTC_HASH', 'RELATE_CODE','Completeness: SSN_BTC_HASH'])

    plhst = syn_read_asset('Lifepro_PLHST').select('NAME_ID', 'ADDRESS_ID')
    df = df.join(plhst, on='NAME_ID', how='left_outer').distinct()

    address = syn_read_asset('Promise_T_ADDRESS').select('LIFEPRO_ADDRESS_ID', 'ADDRESS_ID')
    address_usage = syn_read_asset('Promise_T_PERSON_ADDRESS_USAGE').select('PERSON_ID', 'ADDRESS_ID')
    address = address.join(address_usage, on='ADDRESS_ID', how='left_outer').distinct()
    t_pers = syn_read_asset('Promise_T_PERSON').select(['PERSON_ID', 'FIRST_NAME','LAST_NAME', 'TAX_ID', 'BIRTH_DATE'])
    t_pers = clean(t_pers)

    address = address.join(t_pers, on='PERSON_ID', how='left')

    df = df.join(address, df['ADDRESS_ID'] == address['LIFEPRO_ADDRESS_ID'], 'left')
    # t_pers = format_names(t_pers, ['FIRST_NAME', 'LAST_NAME'])

    # df = df.join(t_pers, (df['INDIVIDUAL_FIRST'] == t_pers['FIRST_NAME']) & (df['INDIVIDUAL_LAST'] == t_pers['LAST_NAME']), 'left_outer')
    df = df.filter(df['Completeness: SSN_BTC_HASH'].contains('fail')).drop('Completeness: SSN_BTC_HASH')
    df = df.filter((df['TAX_ID'].isNotNull()) & (df['INDIVIDUAL_FIRST'] == df['FIRST_NAME'])).distinct()
    return df

# COMMAND ----------

def find_missing_ssn_in_promise(df):
    df = df.select(['NAME_ID', 'INDIVIDUAL_FIRST','INDIVIDUAL_LAST', 'DATE_OF_BIRTH','SSN_BTC_HASH', 'RELATE_CODE','Completeness: SSN_BTC_HASH'])

    t_pers = syn_read_asset('Promise_T_PERSON').select(['PERSON_ID', 'FIRST_NAME','LAST_NAME', 'TAX_ID', 'BIRTH_DATE'])
    t_pers = clean(t_pers)
    t_pers = format_names(t_pers, ['FIRST_NAME', 'LAST_NAME'])

    df = df.join(t_pers, (df['INDIVIDUAL_FIRST'] == t_pers['FIRST_NAME']) & (df['INDIVIDUAL_LAST'] == t_pers['LAST_NAME']), 'left_outer')
    df = df.filter(df['Completeness: SSN_BTC_HASH'].contains('fail')).distinct()
    df =  df.filter((df['TAX_ID'].isNotNull()))
    return df

# COMMAND ----------

summary= get_summary(df)
uc_write(summary)

# COMMAND ----------

# %run ./SSN_Queries

# COMMAND ----------

# query_summary = get_combined_summaries(queries, df, total_rows, same_cols_list, diff_cols_list, **config)
# summary_df = summary_df.union(query_summary)
# save_parquet_results(failed_rows_df, summary_df, **config)
