# Databricks notebook source
# MAGIC %run ../../utils

# COMMAND ----------

# MAGIC %run ../ltc_utils

# COMMAND ----------

config['asset_name'] = 'lifepro20_pclmh'
df = uc_read(config['asset_name'])
df = clean(df)

# COMMAND ----------

#Completeness
columns = ['COMPANY_CODE', 'POLICY_NO', 'CLAIM_NO', 'CLAIM_DETAIL_SEQ']
for column in columns:
    df = completeness_check(df, column)

#Uniqueness
#CLAIM_DETAIL_SEQ represents payment transactions. Each CLAIM_NO should have a unique CLAIM_DETAIL_SEQ but they can also have multiple CDS
df = uniqueness_check(df, ['CLAIM_NO','CLAIM_DETAIL_SEQ']) #can filter to most recent date

# COMMAND ----------

summary = get_summary(df)
uc_write(summary)
