# Databricks notebook source
# MAGIC %run ../../utils

# COMMAND ----------

# MAGIC %run ../ltc_utils

# COMMAND ----------

# MAGIC %run ../../rules

# COMMAND ----------

config['asset_name'] = 'lifepro20_ppben_policy_benefits'
df = uc_read(config['asset_name'])
df = clean(df)

# COMMAND ----------

#COMPLETENESS
columns = ['POLICY_NUMBER', 'STATUS_CODE', 'COMPANY_CODE', 'PLAN_CODE', 'PBEN_ID']
for column in columns:
        df = completeness_check(df, column)

#CONFORMITY
df = conformity_policynumber(df, 'POLICY_NUMBER')

df = df.withColumn('Conformity: STATUS_CODE', f.when(df['STATUS_CODE'].rlike(r'^[A-Z]$'),'pass: must contain single alphabetic character').when(df['STATUS_CODE'].isNull(), 'pass: must contain single alphabetic character').otherwise('fail: must contain single alphabetic character'))

df = df.withColumn('Accuracy: STATUS_CODE', f.when(df['STATUS_CODE'].rlike(r'^[ATP]$'),'pass: must contain A, T or P').when(df['STATUS_CODE'].isNull(), 'pass: must contain A, T or P').otherwise('fail: must contain A, T or P'))

# COMMAND ----------

summary= get_summary(df)
uc_write(summary)
