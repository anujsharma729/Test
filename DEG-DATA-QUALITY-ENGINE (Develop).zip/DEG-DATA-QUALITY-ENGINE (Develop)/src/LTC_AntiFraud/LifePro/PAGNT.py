# Databricks notebook source
# MAGIC %run ../../utils

# COMMAND ----------

# MAGIC %run ../ltc_utils

# COMMAND ----------

config['asset_name'] = 'lifepro20_pagnt_agent_master'
df = uc_read('lifepro20_pagnt_agent_master')

#Completeness
columns = ['COMPANY_CODE', 'STATUS_CODE','AGENT_NUMBER']
for column in columns:
    df = completeness_check(df, column)

summary = get_summary(df)
uc_write(summary)
