# Databricks notebook source
# MAGIC %run ../../utils

# COMMAND ----------

# MAGIC %run ../../rules

# COMMAND ----------

# MAGIC %run ../ltc_utils

# COMMAND ----------

ppolc = uc_read('lifepro20_ppolc')
prela = uc_read('lifepro20_prela_relationship_master')
pagnt = uc_read('lifepro20_pagnt_agent_master')
plhst = uc_read('lifepro20_plhst')
pname = uc_read('lifepro20_pname')
ppben = uc_read('lifepro20_ppben_policy_benefits')
pclmr = uc_read('lifepro20_pclmr_claim_master_record')
pahst = uc_read('lifepro20_pahst')

ppolc = clean(ppolc)
prela = clean(prela)
pahst = clean(pahst)
prela = clean(prela)
plhst = clean(plhst)
pname = clean(pname)
ppben = clean(ppben)
pclmr = clean(pclmr)

ppolc = ppolc.withColumn('IDENTIFYING_ALPHA',f.concat(ppolc.COMPANY_CODE,ppolc.POLICY_NUMBER))
#[1: Incomplete, 2: Pending, 3: Open, 4: Closed, 5: Re-Opened, 6: Rejected, 7: History]
pclmr = pclmr.withColumn('CLAIM_STATUS',f.when(pclmr['STATUS_CODE']=='1', 'Incomplete').when(pclmr['STATUS_CODE']=='2', 'Pending').when(pclmr['STATUS_CODE']=='3', 'Open').when(pclmr['STATUS_CODE']=='4', 'Closed').when(pclmr['STATUS_CODE']=='5', 'Re-Opened').when(pclmr['STATUS_CODE']=='6', 'Rejected').when(pclmr['STATUS_CODE']=='7', 'History'))
ppben = ppben.withColumn('POLICY_STATUS', f.when(ppben['STATUS_CODE']=='T', 'Terminated').when(ppben['STATUS_CODE']=='A', 'Active').otherwise('Unknown'))

ppolc = get_current_data(ppolc, 'POLICY_NUMBER', 'LAST_CHANGE_DATE')
pahst = get_current_data(pahst, 'ADDRESS_ID', 'DATE_STAMP')
plhst = get_current_data(plhst, 'ADDRESS_ID', 'DATE_STAMP')

df = pname.join(prela, on='NAME_ID', how='left')
df = df.join(ppolc, on='IDENTIFYING_ALPHA', how='left')
df = df.join(plhst, on='NAME_ID', how='left')
df = df.join(pahst, on='ADDRESS_ID', how='left')
df = df.join(ppben, on=['COMPANY_CODE', 'POLICY_NUMBER'])
df = df.join(pclmr, (df['NAME_ID']==pclmr['INSURED_NAME_ID']) & (df['POLICY_NUMBER']==pclmr['POLICY_NUMBER']), how='left')


person_cols = ['NAME_ID', 'INDIVIDUAL_FIRST', 'INDIVIDUAL_LAST', 'NAME_BUSINESS', 'SSN_BTC_HASH','DATE_OF_BIRTH', 'DEATH_DATE','SEX_CODE', 'RELATE_CODE']
address_cols = ['ADDRESS_ID','ADDR_LINE_1', 'ADDR_LINE_2', "ADDR_LINE_3", 'CITY', 'STATE', pahst['ZIP'], pahst['COUNTY_CODE'], 'COUNTRY']
policy_cols = [ppolc['POLICY_NUMBER'], 'POLICY_STATUS', 'PAYMENT_CODE', ppolc['ISSUE_DATE']] #BENEFIT_TYPE
claim_cols = ['CLAIM_NUMBER',pclmr['CLAIM_STATUS'],'SENDER_ID']
contact_cols = ['TELE_NUM', 'CELL_NUM', 'FAX_NUM', 'PERSONAL_EMAIL_ADR', 'BUSINESS_EMAIL_ADR']

lifepro = df.select(*person_cols, *address_cols, *policy_cols, *claim_cols, *contact_cols).distinct()


# COMMAND ----------


person = spark.sql(f"SELECT * FROM usdo_prod_catalog.gold_knowledge_graph.t_norm_person")
ppc =spark.sql(f"SELECT * FROM usdo_prod_catalog.gold_knowledge_graph.t_norm_person_policy_crosswalk").select('NORM_PERSON_ID', 'EDGE_NAME', 'POLICY_NUMBER')
np =spark.sql(f"SELECT * FROM usdo_prod_catalog.gold_knowledge_graph.t_norm_policy").select('POLICY_NUMBER', 'POLICY_STATUS').distinct()


person = person.join(ppc, on='NORM_PERSON_ID', how='left').join(np, on='POLICY_NUMBER', how='left')
# person = person.filter(person.EDGE_NAME == 'IS_COVERED_BY')

person = person.select('SOURCE_ID', 'SOURCE_ID_COLUMN', 'SOURCE_SYSTEM', 'FIRST_NAME', 'LAST_NAME', 'BIRTH_DATE', 'SSN','SEX', 'DEATH_DATE', 'POLICY_NUMBER','EDGE_NAME', 'POLICY_STATUS')
