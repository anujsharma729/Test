# Databricks notebook source
def find_matching_rows(df, same_cols: list, diff_col: str):
    total_rows = df.count()
    df_count = df.groupBy(*same_cols, diff_col).count()
    df_result = df_count.groupBy(*same_cols).count().filter(f.col('count') > 1)
    df_result = df.join(df_result.select(*same_cols), on=same_cols, how='inner')
    df_result = df_result.withColumn(f'Consistency: {same_cols[0]}', f.lit('fail: Must Not Contain Matching {} with Non-matching {} '.format(", ".join(same_cols), diff_col)))
    print(df_result.count())
    display(df_result)
    summary = get_query_summary(df_result, total_rows, **config)
    return summary

def summarize_matching_rows(df, same_cols_list, diff_cols_list):
    total_rows = df
    summary = None
    count = 0
    for same_col, diff_col in zip(same_cols_list, diff_cols_list):
        result = find_matching_rows(df, same_col, diff_col)
        if summary is None: summary = result
        else: summary = summary.union(result)
    return summary

def check_for_agents(result):
    prela = syn_read_asset('Lifepro20_PRELA')
    ppolc = syn_read_asset('Lifepro20_PPOLC').select('COMPANY_CODE', 'POLICY_NUMBER', 'CONTRACT_CODE')
    ppolc = ppolc.withColumn('IDENTIFYING_ALPHA', f.concat_ws("",f.col('COMPANY_CODE'),f.col('POLICY_NUMBER')))

    prela = prela.join(ppolc, on='IDENTIFYING_ALPHA', how='left_outer').drop('IDENTIFYING_ALPHA')
    prela = prela.groupBy('NAME_ID').agg(f.collect_set("POLICY_NUMBER").alias('POLICY_NUMBER'), f.collect_set("RELATE_CODE").alias('RELATE_CODE'),f.collect_set("CONTRACT_CODE").alias('CONTRACT_CODE'))
    prela = prela.withColumn('AGENT_IDENTIFIER', f.when(f.array_contains(prela['RELATE_CODE'], "AG"), 'AGENT').otherwise(None))
    result = result.join(prela, on='NAME_ID', how='left_outer')
    SSN_For_Agents = result.filter(result['AGENT_IDENTIFIER'].isNotNull()).distinct().select('SSN_BTC_HASH')
    SSN_For_Agents = SSN_For_Agents.withColumn('Filter_Out', f.lit('Y'))
    result = result.join(SSN_For_Agents, on='SSN_BTC_HASH',how='left_outer')

    plhst = syn_read_asset('Lifepro20_PLHST').select('NAME_ID', 'ADDRESS_ID')
    pahst = syn_read_asset('Lifepro20_PAHST').select('ADDRESS_ID', 'ADDR_LINE_1')

    address = plhst.join(pahst, on='ADDRESS_ID', how='left_outer').distinct()
    result = result.join(address, on='NAME_ID', how='left_outer')
    return result

# COMMAND ----------

# same_cols_list = ['SSN_BTC_HASH']
# diff_cols_list = 'INDIVIDUAL_LAST'
# # result = find_matching_rows(df, same_cols_list, diff_cols_list)
