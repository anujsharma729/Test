# Databricks notebook source
# MAGIC %run ../../../utils

# COMMAND ----------

# MAGIC %run ../../ltc_utils

# COMMAND ----------

from datetime import datetime

def join_df(df1, df2):
    if (df1.filter(df1['ASSET_NAME'].contains('Beacon')).count() > 0) | (df2.filter(df2['ASSET_NAME'].contains('Beacon')).count() > 0):
        df1 = df1.withColumn("SSN", f.substring(f.col("SSN"), -4, 4))
        df2 = df2.withColumn("SSN", f.substring(f.col("SSN"), -4, 4))
    joined_df = df1.join(df2, (df1.FIRST_NAME == df2.FIRST_NAME) & (df1.LAST_NAME == df2.LAST_NAME) & (df1.SSN == df2.SSN) & (df1.BIRTH_DATE != df2.BIRTH_DATE), 'inner')
    return joined_df
def get_unique_pairs(lst):
    unique_pairs = []
    for i in range(len(lst)):
        for j in range(i + 1, len(lst)):
            unique_pairs.append((lst[i], lst[j]))
    return unique_pairs

def get_summary(df, ws, asset, total_rows):
    rows_passed = total_rows - df.count()
    score = df.count()/total_rows
    if "Care" in asset: column = "BIRTH_DT"
    elif "Lifepro" in asset: column = "DATE_OF_BIRTH"
    elif 'Promise' in asset: column = 'BIRTH_DATE'
    elif 'Beacon' in asset: column = 'InsuredBirthDate'
    else: column = 'Birth Date'

    summary = spark.createDataFrame([
    (datetime.today().strftime('%Y-%m-%d'), ws, asset.split("_",1)[0], asset.split("_",1)[1], column, 'Consistency', 
    "Person Records in Lifepro Must Have Matching Birth Date",total_rows, rows_passed, df.count(), score, 1.0)], ["Scan Date", "Workstream", "System Name", "Asset Name", "Column Name", "DQ Dimension", "Data Quality Rule", "Total Rows", "Rows Passed", "Rows Failed", "Score", "Threshold"])
    return summary

def clean_columns(df, table):
    df = trim(df)

    for column in df.columns:
        df = df.withColumn(column, f.when(f.col(column) == '\0', None)
            .when(f.col(column) == '', None)
            .when(f.initcap(f.col(column)) == 'Null', None)
            .when(f.initcap(f.col(column)) == 'Unknown', None)
            .when(f.initcap(f.col(column)) == 'Na', None)
            .when(f.initcap(f.col(column)) == 'N/a', None)
            .when(f.col(column).rlike(r"^0+$"), None)
            .otherwise(f.col(column)))
        
        if "Lifepro" in table:
            df = df.withColumn('BIRTH_DATE', f.from_unixtime(f.unix_timestamp(f.col('DATE_OF_BIRTH').cast("string"), 'yyyyMMdd'), 'yyyy-MM-dd'))
            df = df.withColumn('DEATH_DATE', f.from_unixtime(f.unix_timestamp(f.col('DEATH_DATE').cast("string"), 'yyyyMMdd'), 'yyyy-MM-dd'))
        else:
            if 'BIRTH' in column.upper(): df = df.withColumn("BIRTH_DATE", f.date_format((df[column]), "yyyy-MM-dd"))
            if 'DEATH' in column.upper(): df = df.withColumn("DEATH_DATE", f.date_format((df[column]), "yyyy-MM-dd"))
            
        if ('NAME_ID' in column.upper()) | ('Client Member ID' in column) |('PERSON_ID' in column.upper()) | ('InsuredID' in column): df = df.withColumnRenamed(column, 'ID')
        if 'FIRST' in column.upper(): df = df.withColumn('FIRST_NAME', f.upper(df[column]))
        if ('LAST' in column.upper()) & ("DT" not in column.upper()) & ("DATE" not in column.upper()): df = df.withColumn('LAST_NAME', f.upper(df[column]))
        if ('SSN' in column.upper()) | ('TAX_ID' in column.upper()) | ('SEC' in column.upper()): 
            df = df.withColumnRenamed(column, 'SSN')
    if "DEATH" not in df.columns:
        df = df.withColumn('DEATH_DATE', f.lit(None))
    df = df.withColumn("ASSET_NAME", f.lit(table))
    df = df.select("ASSET_NAME","ID", 'FIRST_NAME', 'LAST_NAME', 'SSN', 'BIRTH_DATE', 'DEATH_DATE')

    df = df.filter(df['SSN'].isNotNull())
    df = df.filter(df['BIRTH_DATE'].isNotNull())
    df = df.filter((df['FIRST_NAME'].isNotNull()) & (df['LAST_NAME'].isNotNull()))
    return df

# COMMAND ----------

configure_spark()
Assets = ['Care_TPERSON', 'Lifepro20_PNAME', 'Promise_T_PERSON', 'GLTC_Claimant', 'Beacon_InsuredDetail']
summary = None
for value in get_unique_pairs(Assets):
    print(value)
    df1 = syn_read_asset(value[0])
    df1 = clean_columns(df1, value[0])
    df2 = syn_read_asset(value[1])
    df2 = clean_columns(df2, value[1])
    master_df = join_df(df1, df2)
    total_rows = df1.count()
    summary_df = get_summary(master_df, config["work_stream"], value[0], total_rows)
    if summary is None: summary = summary_df
    else: summary = summary.union(summary_df)

display(summary)

# COMMAND ----------

# CARE_df = syn_read_asset("Care_TPERSON")
# CARE_total_rows = CARE_df.count()
# CARE_df = clean_columns(CARE_df, 'Care_TPERSON')
# LIFEPRO_df = syn_read_asset("Lifepro_PNAME")
# LIFEPRO_total_rows = LIFEPRO_df.count()
# LIFEPRO_df = clean_columns(LIFEPRO_df, 'Lifepro_PNAME')
# PROMISE_df = syn_read_asset('Promise_T_PERSON')
# PROMSIE_total_rows = PROMISE_df.count()
# PROMISE_df = clean_columns(PROMISE_df, 'Promise_T_PERSON')
# GLTC_df = syn_read_asset('GLTC_Claimant')
# GLTC_total_rows = GLTC_df.count()
# GLTC_df = clean_columns(GLTC_df, 'GLTC_Claimant')
# BEACON_df = syn_read_asset('Beacon_InsuredDetail')
# BEACON_total_rows = BEACON_df.count()
# BEACON_df = clean_columns(BEACON_df, 'Beacon_InsuredDetail')

# COMMAND ----------

# master_df = join_df(PROMISE_df, CARE_df) #107
# master_df1 = join_df(PROMISE_df, PROMISE_df) #107
# master_df2 = join_df(PROMISE_df, GLTC_df) #107
# master_df3 = join_df(PROMISE_df, BEACON_df) #NONE
# master_df4 = join_df(PROMISE_df, LIFEPRO_df) #1380

# LIFEPRO_MASTER = master_df.union(master_df1).union(master_df2).union(master_df3).union(master_df4)
# display(LIFEPRO_MASTER)
