# Databricks notebook source
'''
SSN & COUNTRY Query

This Query checks for SSN values that are being stored in the Country Field rather than in the SSN field. 
This query relates to the Provider Code issue which involves the process of inputting a provider code into the SSN field and putting the SSN in the Country Code field. 
The entries into Country are likely the result of people incorrectly implementing an the provider code process (which is concerning). 
These results beg the question, what fields don't have SSNs in them?
'''

def find_ssn_in_country():
    df = syn_read_asset('Lifepro20_PNAME').select('NAME_ID', 'SSN_BTC_HASH', 'INDIVIDUAL_FIRST','INDIVIDUAL_LAST', 'NAME_BUSINESS')
    # config['asset_name'] = 'Lifepro_PLHST'
    # plhst_df = syn_read_asset('Lifepro_PLHST')
    plhst_df = syn_read_asset('Lifepro20_PLHST').withColumnRenamed('NAME_ID', 'PLHST_NAME_ID').withColumnRenamed('ADDRESS_ID', 'PLHST_ADDRESS_ID').select('PLHST_NAME_ID', 'PLHST_ADDRESS_ID').distinct()

    df = df.join(plhst_df, df['NAME_ID'] == plhst_df['PLHST_NAME_ID'], 'left_outer')

    # config['asset_name'] = 'Lifepro_PAHST'
    # pahst_df = read_asset(**config)
    pahst_df = syn_read_asset('Lifepro_PAHST').select('ADDRESS_ID', 'COUNTRY')
    pahst_df = trim(pahst_df).distinct()
    df = df.join(pahst_df, df['PLHST_ADDRESS_ID'] == pahst_df['ADDRESS_ID'], 'left_outer').distinct()
    df = df.drop('PLHST_NAME_ID', 'PLHST_ADDRESS_ID')

    df = df.filter(f.col('COUNTRY').rlike(r"^^(?!\d{10})\d{9}") | (f.col('COUNTRY').rlike(r"^(?!(000|666))\d{3}-(?!00)\d{2}-(?!0000)\d{4}$")) | f.col('COUNTRY').rlike(r"^\d{2}-\d{7}$"))
    df = df.withColumn('Consistency: SSN_BTC_HASH, COUNTRY', f.lit('fail: Country Field Must Not Contain SSN Values'))
    return df
