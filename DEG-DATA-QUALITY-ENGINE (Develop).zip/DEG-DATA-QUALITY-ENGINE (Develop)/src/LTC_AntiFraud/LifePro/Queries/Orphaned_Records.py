# Databricks notebook source
# MAGIC %run ../../../utils

# COMMAND ----------

# MAGIC %run ../../ltc_utils

# COMMAND ----------

def orphaned_records(system,id,asset_name):
    tables  = []
    dir = f'abfss://gold@dlsmfceus2aaihubprd01.dfs.core.windows.net/ltc_ext/parquet/ltc_buffer/'
    output = dbutils.fs.ls(dir)
    df1 = syn_read_asset(asset_name)
    df1 = clean(df1)
    for c in df1.columns:
        if 'FIRST' in c.upper(): df1 = df1.withColumnRenamed(c, 'FIRST_NAME')
        elif 'LAST' in c.upper(): df1 = df1.withColumnRenamed(c, 'LAST_NAME')
        elif 'SSN' in c.upper(): 
            df1 = df1.withColumnRenamed(c, 'SSN')
        elif 'BIRTH' in c.upper(): df1 = df1.withColumnRenamed(c, 'BIRTH_DATE')

    for value in output:
        if (system in value.name) and (asset_name not in value.name):
            tables.append(value.name.split('/')[0])
    
    matched_records = None
    for asset in tables:
        df = syn_read_asset(asset)
        if id in df.columns:
            print(asset)
            df = df.select(id).withColumn('ASSET_NAME', f.lit(asset))
            df = df1.join(df, on=id, how='left')
            df = df.select(id, 'FIRST_NAME', 'LAST_NAME', 'SSN','BIRTH_DATE', 'ASSET_NAME').distinct()
            if matched_records is None: matched_records = df
            else: matched_records = matched_records.union(df)
    
    matched_records = matched_records.groupBy(id, 'SSN', 'FIRST_NAME', 'LAST_NAME', 'BIRTH_DATE').agg(f.collect_set('ASSET_NAME').alias('ASSET_NAME')).distinct()
    matched_records = matched_records.withColumn("ASSET_NAME", f.when(f.size(f.col("ASSET_NAME")) == 0, None).otherwise(f.col("ASSET_NAME")))       
    matched_records = matched_records.withColumn(f'Consistency: {id}', f.when(f.col('ASSET_NAME').isNull(), 'fail: Must Not Be Orphaned Record').otherwise('pass: Must Not Be Orphaned Record'))
    print(matched_records.count())
    return matched_records


# COMMAND ----------

# df = orphaned_records('Lifepro','NAME_ID','Lifepro_PNAME')

# COMMAND ----------

# value_counts(df, 'Consistency: NAME_ID')

# COMMAND ----------


