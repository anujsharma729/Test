# Databricks notebook source
# MAGIC %run ../../../utils

# COMMAND ----------

''' 
LEXIS NEXIS QUERY

We pass lexis nexis PII on active claimants when requesting background check reports. Lexis Nexis matches our data to theirs, and then passes us back their best matching PII record above a certain confidence threshold. We can then query all the cases where lexis nexis's SSN on file is different than ours.
'''

def get_LexisNexis_SSN():
    df = syn_read_asset('T_LEXIS_NEXIS_LEXID')
    df = df.select(
    "CLAIM_ID","POLICY_NUMBER", "SOURCE_SYSTEM","FIRST_NAME","LAST_NAME","BIRTH_DATE",
    f.expr("RIGHT(CONCAT('000', SSN), 9)").alias("JH_SSN"),"best_ssn").alias("LEXIS_NEXIS_SSN")

    df = df.filter(f.col("JH_SSN") != f.col("best_ssn"))
    df = df.filter(df['SOURCE_SYSTEM'] == 'LIFEPRO')
    pname = syn_read_asset('Lifepro20_PNAME').select('SSN_BTC_HASH','NAME_ID', 'INDIVIDUAL_FIRST', 'INDIVIDUAL_LAST')
    pname = clean(pname, ['SSN_BTC_HASH']).distinct()
    df = df.join(pname,(df['JH_SSN'] == pname['SSN_BTC_HASH']), 'full')
    df = df.orderBy(f.desc('JH_SSN'))
    df = df.withColumn('Accuracy: SSN_BTC_HASH', f.when((df['JH_SSN'].isNotNull()) & (df['SSN_BTC_HASH'].isNotNull()), 'fail: Must Match Lexis Nexis SSN').when((df['JH_SSN'].isNotNull()) & (df['SSN_BTC_HASH'].isNull()), 'fail: Must Match Lexis Nexis SSN').otherwise('pass: Must Match Lexis Nexis SSN'))
    summary_df = get_summary(df, None, 'LifePro', 'Lifepro_PNAME', 'LTC_AntiFraud')
    # failed_rows_df = get_failed_rows(df)
    # config['asset_name'] = 'Lifepro_PNAME'
    # save_parquet_results(failed_rows_df, summary_df, **config)
    # return df
    return summary_df

