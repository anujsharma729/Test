# Databricks notebook source
# MAGIC %run ./Orphaned_Records

# COMMAND ----------

df = orphaned_records('Lifepro','NAME_ID','Lifepro_PNAME')
sum1 = get_summary(df, None, 'Lifepro', 'Lifepro_PNAME', 'LTC_AntiFraud')

# COMMAND ----------

# MAGIC %run ./Lexis_Nexis_SSN

# COMMAND ----------

sum3 = get_LexisNexis_SSN()

# COMMAND ----------

# MAGIC %run ./DOB_Queries

# COMMAND ----------

sum2 = summary

# COMMAND ----------

# MAGIC %run ./SSN_&_COUNTRY

# COMMAND ----------

df1 = find_ssn_in_country()
sum4 = get_summary(df1, None, 'Lifepro', 'Lifepro_PNAME', 'LTC_AntiFraud')


# COMMAND ----------

summary = sum1.union(sum2).union(sum3).union(sum4)
summary.write.parquet(f"abfss://dataquality@{ENV['storage_account']}.dfs.core.windows.net/LTC_AntiFraud/Lifepro/Lifepro_PNAME/{TIMESTAMP}/scan_summary")
