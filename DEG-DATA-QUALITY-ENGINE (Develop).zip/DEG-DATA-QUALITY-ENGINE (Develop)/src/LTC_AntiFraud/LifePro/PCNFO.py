# Databricks notebook source
# MAGIC %run ../../utils

# COMMAND ----------

# MAGIC %run ../ltc_utils

# COMMAND ----------

# MAGIC %run ../../rules

# COMMAND ----------

config['asset_name'] = 'lifepro20_pcnfo'
df = uc_read('lifepro20_pcnfo')
df = clean(df)
df = df.filter(df.DATE_UPDATED.isNull())

# COMMAND ----------

#Completeness
columns = ['COMPANY_CODE', 'POLICY_NUMBER', 'CNFO_STATUS', 'EFFECTIVE_DATE']
for column in columns:
    df = completeness_check(df, column)

#Uniqueness
df = uniqueness_check(df, 'POLICY_NUMBER')

df = conformity_policynumber(df, 'POLICY_NUMBER')

# COMMAND ----------

summary = get_summary(df)
uc_write(summary)
