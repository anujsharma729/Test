# Databricks notebook source
# MAGIC %run ../../utils

# COMMAND ----------

# MAGIC %run ../ltc_utils

# COMMAND ----------

# MAGIC %run ../../rules

# COMMAND ----------

config['asset_name'] = 'lifepro20_pclmr_claim_master_record'
df = uc_read(config['asset_name'])
df = clean(df)
ppolc = uc_read('lifepro20_ppolc').select('POLICY_NUMBER', 'CONTRACT_CODE', 'CONTRACT_REASON')
ppolc = trim(ppolc)

for dt in df.columns: 
    if 'DATE_' in dt:
        df = df.withColumn(dt, f.to_date(f.col(dt).cast("string"), 'yyyyMMdd'))

df = df.join(ppolc, on='POLICY_NUMBER', how='left')

# COMMAND ----------

#COMPLETENESS
completeness_check_columns = ['POLICY_NUMBER', 'CLAIM_NUMBER', 'COMPANY_CODE', 'PATIENT_NAME_ID', 'INSURED_NAME_ID']
for column in completeness_check_columns:
    df = completeness_check(df, column)

#UNIQUENESS
df = uniqueness_check(df, 'CLAIM_NUMBER')

#CONFORMITY
df = conformity_policynumber(df, 'POLICY_NUMBER')

df = df.withColumn("Conformity: CLAIM_NUMBER", f.when(df['CLAIM_NUMBER'].rlike(r'^[A-Z ]{1,6}\d{1,8}$'), 'pass: must be company/cspp code followed by spaces for first 6 characters')
        .when(df['CLAIM_NUMBER'].rlike(r'^[JHC2]+[ ]{1,2}\d{1,6}'), 'pass: must be company/cspp code followed by spaces for first 6 characters')
        .when(df['CLAIM_NUMBER'].rlike(r'^C-\d{1,6}$'), 'pass: must be company/cspp code followed by spaces for first 6 characters')
        .when(df['POLICY_NUMBER'].isNull(), 'pass: No Entry').otherwise('fail: must be company/cspp code followed by spaces for first 6 characters'))

#[1: Incomplete, 2: Pending, 3: Open, 4: Closed, 5: Re-Opened, 6: Rejected, 7: History]

df = accuarcy_between(df, 'STATUS_CODE', 1, 7)

#ACCURACY
df = df.withColumn('Accuracy: CLAIM_NUMBER', is_accurate_claim_number(df['CLAIM_NUMBER']))

df = df.withColumn('Accuracy: STATUS_CODE', f.when((df['CONTRACT_CODE'] == 'T') & (df['STATUS_CODE'].isin([1, 2, 3, 5])), 'fail: claims cannot be pending or active for terminated policies').otherwise('pass: claims cannot be pending or active for terminated policies'))

#TIMELINESS
df = df.withColumn('Timeliness: STATUS_CODE', f.when((df['STATUS_CODE'] == 2) & (f.datediff(f.current_date(), df['DATE_ADDED']) > 80), 'fail: claims must').otherwise('pass: claims must'))

# COMMAND ----------

summary = get_summary(df)
uc_write(summary)
