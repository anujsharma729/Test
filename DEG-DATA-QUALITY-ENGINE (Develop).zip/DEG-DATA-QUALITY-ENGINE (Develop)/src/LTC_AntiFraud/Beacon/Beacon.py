# Databricks notebook source
# MAGIC %run ../../utils

# COMMAND ----------

# MAGIC %run ../ltc_utils

# COMMAND ----------

# MAGIC %run ../../rules

# COMMAND ----------

system = 'beacon'
df1 = uc_read('beacon_claim').select('ClaimID', 'ClaimNum', 'ClaimStatusCode','LegacySystem')
df2 = uc_read('beacon_insureddetail')
df3 = uc_read('beacon_policydetail').select('PolicyNum', 'PolicyID', 'CompanyCode', 'LineOfBusinessCode', 'PolicyStatusCode')
df4  = uc_read('beacon_providerdetail').drop('Comments', 'ProviderMedicareCertifiedInd')

df2 = format_dates(df, 'InsuredBirthDate')


# COMMAND ----------

#COMPLETENESS
df1 = completeness_check(df1, 'ClaimID')
df1 = completeness_check(df1, 'ClaimNum')

#Conformity
rule = '{rule}'
df4 = df4.withColumn("Conformity: ClaimNum", f.when(df1['ClaimNum'].rlike(r'^[A-Z ]{1,6}\d{1,8}$'), f'pass: {rule}')
	.when(df1['ClaimNum'].rlike(r'^[JHC2]+[ ]{1,2}\d{1,6}'), f'pass: {rule}')
	.when(df1['ClaimNum'].rlike(r'^C-\d{1,6}$'), f'pass: {rule}')
	.when(f.upper(df1['ClaimNum']).rlike(r"C-\d+"), f'pass: {rule}')
	.when(df1['ClaimNum'].rlike(r'^\d+$'), f'pass: {rule}')
	.when(df1['ClaimNum'].rlike(r"^[A-Z]\d{5}$"), f'pass: {rule}')
	.when(df1['ClaimNum'].rlike(r'^[A-Z]{2}\d{4}$'), f'pass: {rule}')
	.when(f.upper(df1['ClaimNum']).rlike(r'^R\d{8}$'), f'pass: {rule}')
 	.when(f.upper(df1['ClaimNum']).rlike(r'^P\d{5}$'), f'pass: {rule}')
   	.when(f.upper(df1['ClaimNum']).rlike(r'^CSP-\d{4}$'), f'pass: {rule}')
	.when(df1['ClaimNum'].rlike(r'^[A-Z]{3}\d{4}$'), f'pass: {rule}')
	.when(df1['ClaimNum'].isNull(), f'pass: {rule}').otherwise(f'fail: {rule}'))


#INSUREDDETAIL
for column in ['InsuredGenderCode', 'InsuredfirstName', 'InsuredLastName', 'InsuredBirthDate', 'InsuredSSN']:
    df2 = completeness_check(df2, column)

df2 = conformity_birthdate(df2, 'InsuredBirthDate')
df2 = conformity_gender(df2, 'InsuredGenderCode')
df2 = conformity_ssn_4_digit(df2, 'InsuredSSN')

df2 = accuracy_gender(df2, 'InsuredGenderCode')
df2 = accuracy_birthdate(df2, 'InsuredBirthDate')


#POLICYDETAIL
df3 = completeness_check(df3, 'PolicyNum')
df3 = conformity_policynumber(df3, 'PolicyNum')

#PROVIDERDETAIL
completeness_check_columns = ['ProviderAddressLine1','ProviderCity' , 'ProviderState', 'ProviderWorkPhoneNum', 'ProviderName', 'ProviderZipCode']
for column in completeness_check_columns:
    df4 = completeness_check(df4, column)

df4 = conformity_addr1(df4, 'ProviderAddressLine1')
df4 = conformity_addr2(df4, 'ProviderAddressLine2')
df4 = conformity_addr3(df4, 'ProviderAddressLine3')
df4 = conformity_city(df4, 'ProviderCity')
df4 = conformity_state(df4, 'ProviderState')
# df4 = conformity_zip(df4, 'ProviderZipCode')
df4 = conformity_phone(df4, 'ProviderWorkPhoneNum')

df4 = accuracy_phone(df4, 'ProviderWorkPhoneNum')
df4 = accuracy_city(df4, 'ProviderCity')

# COMMAND ----------

config['asset_name'] = 'beacon_claim'
s1 = get_summary(df1)
config['asset_name'] = 'beacon_insureddetail
s2 = get_summary(df2)
config['asset_name'] = 'beacon_policydetail'
s3 = get_summary(df3)
config['asset_name'] = 'beacon_providerdetail'
s4 = get_summary(df4)
summary = s1.union(s2).union(s3).union(s4)
uc_write(summary)
