# Databricks notebook source
# MAGIC %run ../../utils

# COMMAND ----------

# MAGIC %run ../ltc_utils

# COMMAND ----------

configure_spark()
config['asset_name'] = 'Beacon_InsuredDetail'
config['data_system'] = 'Beacon'

df = read_asset(**config)
df = clean(df)
df = df.withColumn('InsuredBirthDate', f.date_format((f.col('InsuredBirthDate')), "yyyy-MM-dd"))

REFERENCE_DATE = "1900-01-01"
SYSTEM_DEFAULT = "9999-12-31"

# COMMAND ----------

#COMPLETENESS

completeness_check_columns = ['InsuredGenderCode', 'InsuredFirstName', 'InsuredLastName', 'InsuredBirthDate', 'InsuredSSN']
for column in completeness_check_columns:
    df = completeness_check(df, column)

#CONFORMITY
df = df.withColumn('Conformity: InsuredBirthDate',  f.when(df['InsuredBirthDate'].rlike(r'\d{8}'),'pass: Must Adhere to Expected Format YYYY-MM-DD')
    .when(df['InsuredBirthDate'].rlike(r'\d{4}-\d{2}-\d{2}'),'pass: Must Adhere to Expected Format YYYY-MM-DD')
    .when(df['InsuredBirthDate'].isNull(), 'pass: No Entry')
    .otherwise('fail: Must Adhere to Expected Format YYYY-MM-DD'))

# 
# df = df.withColumn('Conformity: InsuredFirstName', check_name(f.col("InsuredFirstName")))
# df = df.withColumn('Conformity: InsuredLastName', check_name(f.col("InsuredLastName")))

df = df.withColumn('Conformity: InsuredSSN', f.when(df['InsuredSSN'].rlike(r"\d{4}$"), 'pass: Must Contain Last 4 Digits of SSN').when(df['InsuredSSN'].isNull(), 'pass: No Entry').otherwise('fail: Must Contain Last 4 Digits of SSN'))

df = df.withColumn('Conformity: InsuredGenderCode',  f.when(df['InsuredGenderCode'].rlike(r'^[A-Z]$'),'pass: Must Contain A Single Alphabetic Character')
    .when(df['InsuredGenderCode'].isNull(), 'pass: No Entry')
    .otherwise('fail: Must Contain A Single Alphabetic Character'))

#ACCURACY
df = df.withColumn('Accuracy: InsuredGenderCode', f.when(df['InsuredGenderCode'].rlike(r'^[FM]$'),'pass: Must Contain F or M').when(df['InsuredGenderCode'].isNull(), 'pass: No Entry').otherwise('fail: Must Contain F or M'))

df = df.withColumn('Accuracy: InsuredBirthDate', f.when(df['InsuredBirthDate'] <= REFERENCE_DATE, 'fail: Must Be After 1900-01-01')
    .when(df['InsuredBirthDate'] <= TIMESTAMP[:10], 'pass: Must Contain Date Before Today Or Is System Default')
    .when(df['InsuredBirthDate'] == SYSTEM_DEFAULT, 'pass: Must Contain Date Before Today Or Is System Default')
    .when(df['InsuredBirthDate'] > TIMESTAMP[:10], 'fail: Must Not Be A Future Date')
    .when(df['InsuredBirthDate'].isNull(), 'pass: No Entry')
    .otherwise('fail: Must Contain Date Before Today Or Is System Default'))

# COMMAND ----------

summary_df = get_summary(df, None, **config)
failed_rows_df = get_failed_rows(df)
save_parquet_results(failed_rows_df, summary_df, **config)
