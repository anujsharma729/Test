# Databricks notebook source
# MAGIC %run ./Claim

# COMMAND ----------

# MAGIC %run ./InsuredDetail

# COMMAND ----------

# MAGIC %run ./PolicyDetail

# COMMAND ----------

# MAGIC %run ./ProviderDetail
