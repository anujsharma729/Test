# Databricks notebook source
# MAGIC %run ../../utils

# COMMAND ----------

# MAGIC %run ../ltc_utils

# COMMAND ----------

configure_spark()
config['asset_name'] = 'Beacon_PolicyDetail'
config['data_system'] = 'Beacon'
df = read_asset(**config)
# df = syn_read_asset("Beacon_PolicyDetail")
df = df.select('PolicyNum', 'PolicyID', 'CompanyCode', 'LineOfBusinessCode', 'PolicyStatusCode')
df = clean(df)

# COMMAND ----------

#COMPLETENESS
df = completeness_check(df, 'PolicyNum')

#CONFORMITY
df = df.withColumn('Conformity: PolicyNum', f.when(df['PolicyNum'].rlike(r'\d{10,}$'), 'fail: Must Not Be More Than 9 Digits Long')
        .when(df['PolicyNum'].rlike(r'^\d{1,6}$'), 'fail: Must Not be Less Than 7 Digits Long')
        .when(df['PolicyNum'].rlike(r'^\d{7,9}$'), 'pass: Must Be 7-9 Digit Number')
        .when(df['PolicyNum'].isNull(), 'pass: No Entry').otherwise('fail: Must Be 7-9 Digit Number'))

# COMMAND ----------

summary_df = get_summary(df, None, **config)
failed_rows_df = get_failed_rows(df)
save_parquet_results(failed_rows_df, summary_df, **config)
