# Databricks notebook source
# MAGIC %run ../../utils

# COMMAND ----------

# MAGIC %run ../ltc_utils

# COMMAND ----------

configure_spark()
config['asset_name'] = 'Beacon_ProviderDetail'
config['data_system'] = 'Beacon'
df = read_asset(**config)
# df = syn_read_asset('Beacon_ProviderDetail')
df = df.drop('Comments', 'ProviderMedicareCertifiedInd')

df = clean(df)
df = format_address(df, ['ProviderAddressLine1', 'ProviderAddressLine2', 'ProviderAddressLine3','ProviderCity'])


# COMMAND ----------

#COMPLETENESS
completeness_check_columns = ['ProviderAddressLine1','ProviderCity' , 'ProviderState', 'ProviderWorkPhoneNum', 'ProviderName', 'ProviderZipCode']
for column in completeness_check_columns:
    df = completeness_check(df, column)

#CONFORMITY
df = df.withColumn('Conformity: ProviderName', f.when(df['ProviderName'].rlike(r' {3,}'),'fail: Must Not Contain 3+ Spaces')    
    .when(df['ProviderName'].rlike(r".*[?@#$%^*¬><!{}:}‹~¿_;:'|+=°®•].*"),"fail: Must Not Contain Any Invalid Punctuation [?@#$%^*¬><!{}:'}‹~¿_;:|+=°®•]")
    .when(df['ProviderName'].rlike(r'^[eProviderState]$'),"pass: must contain 'eProviderState' keyword") 
    .when(df['ProviderName'].rlike(r'^[A-Za-z0-9\s]+$'),'pass: Must adhere to Expected Format')
    .when(df['ProviderName'].isNull(), 'pass: No Entry').otherwise('fail: Must adhere to Expected Format'))

df = df.withColumn('Conformity: ProviderAddressLine1', f.when(df['ProviderAddressLine1'].isNull(), 'pass: No Entry')
    .when(df['ProviderAddressLine1'].contains('ATTN:'), 'pass: Must Adhere to Address Format')
    .when(df['ProviderAddressLine1'].contains('PO Box'),'pass: Must Adhere to Address Format')
    .when(df['ProviderAddressLine1'].contains('C/O:'), 'fail: C/O and FBO Must be on ProviderAddressLine2')
    .when(df['ProviderAddressLine1'].contains('FBO:'), 'fail: C/O and FBO Must be on ProviderAddressLine2')
    .when(f.length(df['ProviderAddressLine1']) < 3, 'fail: Must Adhere to Address Format')
    .when(df['ProviderAddressLine1'].rlike(r"[^@\s]+@[^@\s]+\.[^@\s]+"), 'fail: Must Not Contain Email Address')
    .when(df['ProviderAddressLine1'].rlike(r"^[\w\s\d'\-./#(),]+$"), 'pass: Must Adhere to Address Format')
    .when(df['ProviderAddressLine1'].rlike(r".*[?$%^&*¬><!{}:}‹~¿_`;:|+=°®•].*"),"fail: Must Adhere to Address Format")
    .otherwise('fail: Must Adhere to Address Format'))

df = df.withColumn('Conformity: ProviderAddressLine2', f.when(df['ProviderAddressLine2'].isNull(), 'pass: No Entry')
    .when(df['ProviderAddressLine2'].contains('ATTN:'), 'fail: ATTN Must Be on ADDR_LINE_1')
    .when(df['ProviderAddressLine2'].contains('PO Box'),'pass: Must Adhere to Address Format')
    .when(df['ProviderAddressLine2'].contains('C/O:'), 'pass: Must Adhere to Address Format')
    .when(df['ProviderAddressLine2'].contains('FBO:'), 'pass: Must Adhere to Address Format')
    .when(f.length(df['ProviderAddressLine2']) < 3, 'fail: Must Adhere to Address Format')
    .when(df['ProviderAddressLine2'].rlike(r"[^@\s]+@[^@\s]+\.[^@\s]+"), 'fail: Must Not Contain Email Address')
    .when(df['ProviderAddressLine2'].rlike(r"^[\w\s\d'\-./#(),]+$"), 'pass: Must Adhere to Address Format')
    .when(df['ProviderAddressLine2'].rlike(r".*[?$%^&*¬><!{}:}‹~¿_`;:|+=°®•].*"),"fail: Must Adhere to Address Format")
    .otherwise('fail: Must Adhere to Address Format'))

df = df.withColumn('Conformity: ProviderAddressLine3', f.when(df['ProviderAddressLine3'].isNull(), 'pass: No Entry')
    .when(df['ProviderAddressLine3'].contains('ATTN:'), 'fail: ATTN Must Be on ADDR_LINE_1')
    .when(df['ProviderAddressLine3'].contains('PO Box'),'pass: Must Adhere to Address Format')
    .when(df['ProviderAddressLine3'].contains('C/O:'), 'fail: C/O and FBO Must be on ADDR_LINE_2')
    .when(df['ProviderAddressLine3'].contains('FBO:'), 'fail: C/O and FBO Must be on ADDR_LINE_2')
    .when(f.length(df['ProviderAddressLine3']) < 3, 'fail: Must Adhere to Address Format')
    .when(df['ProviderAddressLine3'].rlike(r"[^@\s]+@[^@\s]+\.[^@\s]+"), 'fail: Must Not Contain Email Address')
    .when(df['ProviderAddressLine3'].rlike(r"^[\w\s\d'\-./#(),]+$"), 'pass: Must Adhere to Address Format')
    .when(df['ProviderAddressLine3'].rlike(r".*[?$%^&*¬><!{}:}‹~¿_`;:|+=°®•].*"),"fail: Must Adhere to Address Format")
    .otherwise('fail: Must Adhere to Address Format'))

df = df.withColumn('Conformity: ProviderCity', f.when(df['ProviderCity'].isNull(), 'pass: No Entry')
    .when(df['ProviderCity'].contains('PO Box'), 'fail: PO Box Information Must Be in Address Line')
    .when(df['ProviderCity'].contains('C/O:'), 'fail: C/O Must be on ADDR_LINE_2')
    .when(df['ProviderCity'].rlike(r'\d'), 'fail: Must Only Contain Alphabetic Values')
    .when(df['ProviderCity'].rlike(r".*[?$%^&*¬><!{}:}‹~,¿_`;:|+=°®•].*"), 'fail: Must Only Contain Alphabetic Values')
    .when(df['ProviderCity'].rlike("^[A-Za-z\s'.-]+$"), 'pass: Must Only Contain Alphabetic Values')
    .otherwise('fail: Must Only Contain Alphabetic Values'))

df = df.withColumn('Conformity: ProviderState',f.when(df['ProviderState'].isin(US_STATES), 'pass: Must Contain U.S. ProviderState Code')
    .when(df['ProviderState'].isin(CAN_PROVINCES), 'pass: Must Contain Canadian Province ')
    .when(df['ProviderState'].rlike('\d'), 'fail: Must Only Contain Alphabetic Values')
    .when(df['ProviderState'].isNull(), 'pass: No Entry').otherwise('fail: Must Contain U.S. ProviderState Code'))

df = df.withColumn(f"Conformity: ProviderWorkPhoneNum", f.when(df["ProviderWorkPhoneNum"].rlike(r'^d{10}$'), 'pass: Must be 10 Digit Phone Number').when(df["ProviderWorkPhoneNum"].isNull(),'pass: No Entry').otherwise('fail: Must be 10 Digit Phone Number'))

df = df.withColumn('Conformity: ProviderZipCode',f.when(df['ProviderZipCode'].rlike('^\d{5}$'), 'pass: Must Contain U.S. or Canadian Zip Code')
    .when(df['ProviderZipCode'].rlike('^\d{9}$'), 'pass: Must Contain U.S. or Canadian Zip Code')
    .when(df['ProviderZipCode'].rlike('^\d{5}-\d{4}$'), 'pass: Must Contain U.S. or Canadian Zip Code')
    .when(df['ProviderZipCode'].isNull(), 'pass: No Entry').otherwise('fail: Must Contain U.S. or Canadian Zip Code'))

df = df.withColumn(f"Accuracy: ProviderWorkPhoneNum", f.when(f.col('ProviderWorkPhoneNum').rlike(r"^(.)\1*$"), "fail: Must Not Be Repeated Number")
        .when(f.col('ProviderWorkPhoneNum').rlike(r"^0*([1-9])0*$"), "fail: Must Not Be Repeated Number")
        .when(f.col('ProviderWorkPhoneNum').rlike(r"^[01]+$"), "fail: Must Not Be Repeated Number")
        .when(f.col('ProviderWorkPhoneNum').rlike(r"^[123]+$"), "fail: Must Not Be Repeated Number")
        .when(f.col('ProviderWorkPhoneNum') == '1234567890', 'fail: Must Not Be Repeated Number').otherwise("pass: Must Not Be Repeated Number"))

# COMMAND ----------


summary_df = get_summary(df, None, **config)
failed_rows_df = get_failed_rows(df)
save_parquet_results(failed_rows_df, summary_df, **config)
