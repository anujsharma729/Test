# Databricks notebook source
# MAGIC %run ../utils

# COMMAND ----------

# MAGIC %run ../rules

# COMMAND ----------

# MAGIC %run ./ltc_utils

# COMMAND ----------

# #REFERENCE ASSETS
# pname = uc_read('lifepro20_pname')
# pname = clean(pname)
# plhst = uc_read('lifepro20_plhst').select('NAME_ID', 'ADDRESS_ID')
# plhst = clean(plhst)
# pahst = uc_read('lifepro20_pahst').select('ADDRESS_ID', 'COUNTRY')
# pahst = trim(pahst).distinct()
# prela = uc_read('lifepro20_prela_relationship_master')
# prela = trim(prela)
# ppolc = uc_read('lifepro20_ppolc')
# ppolc = trim(ppolc)
# ppolc = get_current_data(ppolc, ['COMPANY_CODE', 'POLICY_NUMBER'], 'LAST_CHANGE_DATE')

# person = spark.sql(f"SELECT * FROM usdo_prod_catalog.gold_knowledge_graph.t_norm_person")
# ppc =spark.sql(f"SELECT * FROM usdo_prod_catalog.gold_knowledge_graph.t_norm_person_policy_crosswalk").select('NORM_PERSON_ID', 'EDGE_DETAIL', 'POLICY_NUMBER')
# np =spark.sql(f"SELECT * FROM usdo_prod_catalog.gold_knowledge_graph.t_norm_policy").select('POLICY_NUMBER', 'POLICY_STATUS').distinct()
# tnorm_match =spark.sql(f"SELECT * FROM usdo_prod_catalog.gold_knowledge_graph.t_norm_person_match")

# COMMAND ----------

# %run ./LifePro/lifepro_view

# COMMAND ----------

ppolc = uc_read('lifepro20_ppolc')
prela = uc_read('lifepro20_prela_relationship_master')
pagnt = uc_read('lifepro20_pagnt_agent_master')
plhst = uc_read('lifepro20_plhst')
pname = uc_read('lifepro20_pname')
ppben = uc_read('lifepro20_ppben_policy_benefits')
pclmr = uc_read('lifepro20_pclmr_claim_master_record')
pahst = uc_read('lifepro20_pahst')

ppolc = clean(ppolc)
prela = clean(prela)
pahst = clean(pahst)
prela = clean(prela)
plhst = clean(plhst)
pname = clean(pname)
ppben = clean(ppben)
pclmr = clean(pclmr)

ppolc = ppolc.withColumn('IDENTIFYING_ALPHA',f.concat(ppolc.COMPANY_CODE,ppolc.POLICY_NUMBER))
#[1: Incomplete, 2: Pending, 3: Open, 4: Closed, 5: Re-Opened, 6: Rejected, 7: History]
pclmr = pclmr.withColumn('CLAIM_STATUS',f.when(pclmr['STATUS_CODE']=='1', 'Incomplete').when(pclmr['STATUS_CODE']=='2', 'Pending').when(pclmr['STATUS_CODE']=='3', 'Open').when(pclmr['STATUS_CODE']=='4', 'Closed').when(pclmr['STATUS_CODE']=='5', 'Re-Opened').when(pclmr['STATUS_CODE']=='6', 'Rejected').when(pclmr['STATUS_CODE']=='7', 'History'))
ppben = ppben.withColumn('POLICY_STATUS', f.when(ppben['STATUS_CODE']=='T', 'Terminated').when(ppben['STATUS_CODE']=='A', 'Active').otherwise('Unknown'))

ppolc = get_current_data(ppolc, 'POLICY_NUMBER', 'LAST_CHANGE_DATE')
pahst = get_current_data(pahst, 'ADDRESS_ID', 'DATE_STAMP')
plhst = get_current_data(plhst, 'ADDRESS_ID', 'DATE_STAMP')

df = pname.join(prela, on='NAME_ID', how='left')
df = df.join(ppolc, on='IDENTIFYING_ALPHA', how='left')
df = df.join(plhst, on='NAME_ID', how='left')
df = df.join(pahst, on='ADDRESS_ID', how='left')
df = df.join(ppben, on=['COMPANY_CODE', 'POLICY_NUMBER'])
df = df.join(pclmr, (df['NAME_ID']==pclmr['INSURED_NAME_ID']) & (df['POLICY_NUMBER']==pclmr['POLICY_NUMBER']), how='left')


person_cols = ['NAME_ID', 'INDIVIDUAL_FIRST', 'INDIVIDUAL_LAST', 'NAME_BUSINESS', 'SSN_BTC_HASH','DATE_OF_BIRTH', 'DEATH_DATE','SEX_CODE', 'RELATE_CODE']
address_cols = ['ADDRESS_ID','ADDR_LINE_1', 'ADDR_LINE_2', "ADDR_LINE_3", 'CITY', 'STATE', pahst['ZIP'], pahst['COUNTY_CODE'], 'COUNTRY']
policy_cols = [ppolc['POLICY_NUMBER'], 'POLICY_STATUS', 'PAYMENT_CODE', ppolc['ISSUE_DATE']] #BENEFIT_TYPE
claim_cols = ['CLAIM_NUMBER',pclmr['CLAIM_STATUS'],'SENDER_ID']
contact_cols = ['TELE_NUM', 'CELL_NUM', 'FAX_NUM', 'PERSONAL_EMAIL_ADR', 'BUSINESS_EMAIL_ADR']

lifepro = df.select(*person_cols, *address_cols, *policy_cols, *claim_cols, *contact_cols).distinct()


# COMMAND ----------

try:
    #COUNTRY & SSN
    df = lifepro.select(['NAME_ID', 'COUNTRY', 'COUNTY_CODE']).distinct()
    df = df.withColumn('Accuracy: Country', f.when(f.col('COUNTRY').rlike(r"^^(?!\d{10})\d{9}") | (f.col('COUNTRY').rlike(r"^(?!(000|666))\d{3}-(?!00)\d{2}-(?!0000)\d{4}$")) | f.col('COUNTRY').rlike(r"^\d{2}-\d{7}$"), 'fail: country field must not contain tax id value').otherwise('pass: country field must not contain tax id value'))

    #COUNTY_CODE & SSN
    df = df.withColumn('Accuracy: COUNTY_CODE', f.when(f.col('COUNTY_CODE').rlike(r"^^(?!\d{10})\d{9}") | (f.col('COUNTY_CODE').rlike(r"^(?!(000|666))\d{3}-(?!00)\d{2}-(?!0000)\d{4}$")) | f.col('COUNTY_CODE').rlike(r"^\d{2}-\d{7}$"), 'fail: county code field must not contain tax id value').otherwise('pass: county code field must not contain tax id value'))
    s1 = get_summary(df)
    uc_write(s1)
except Exception as e:
    print(e)

# COMMAND ----------

try:
    #PAID AGENTS MUST HAVE SSN
    df = lifepro.select(['NAME_ID', 'SSN_BTC_HASH', 'PAYMENT_CODE', 'RELATE_CODE']).distinct()
    df = df.withColumn('Completeness: SSN', f.when((df.PAYMENT_CODE == 'P') & (df.SSN_BTC_HASH.isNull()) & (df.RELATE_CODE.isin(['SA', 'WA'])), 'fail: paid agents must have completed ssn').otherwise('pass: paid agents must have completed ssn'))
    s4 = get_summary(df)
    uc_write(s4)
except Exception as e:
    print(e)

# COMMAND ----------

try: 
    df = lifepro.select(['NAME_ID',"INDIVIDUAL_FIRST", 'INDIVIDUAL_LAST', 'SSN_BTC_HASH', 'POLICY_NUMBER', 'RELATE_CODE']).distinct()
    df = df.groupBy("POLICY_NUMBER","INDIVIDUAL_FIRST", 'INDIVIDUAL_LAST').agg(f.countDistinct('NAME_ID').alias("distinct_sourceid")).filter(f.col('distinct_sourceid')>1).join(df, on=['INDIVIDUAL_FIRST', 'INDIVIDUAL_LAST', 'POLICY_NUMBER'], how='inner').withColumn('Uniqueness: NAME_ID', f.when(f.col('distinct_sourceid') > 1, 'fail: policy number must have unique insured record').otherwise('pass: policy number must have unique insured record'))
    s5 = get_summary(df)
    uc_write(s5)
except Exception as e:
    print(e)

# COMMAND ----------

try:
    #POLICY STATUS TERMINATED BUT CLAIM IS ACTIVE
    df = lifepro.select(*person_cols, *policy_cols)
    df =df.withColumn('Accuracy: POLICY_STATUS',f.when((df.DEATH_DATE.isNotNull()) & (df.POLICY_STATUS == 'Active') & (df.RELATE_CODE.isin(['IN', 'MI'])), "fail: insured on active policy must not have death date").otherwise('pass: insured on active policy must not have death date'))

    #POLICY ISSUE DATE != 1900-01-01
    df = df.withColumn('Accuracy: ISSUE_DATE', f.when(df.ISSUE_DATE == '1900-01-01', 'fail: issue date must not be 1900-01-01').otherwise('pass: issue date must not be 1900-01-01'))
    s5 = get_summary(df)
    uc_write(s5)
except Exception as e:
    print(e)

# COMMAND ----------

#POLICY STATUS TERMINATED BUT CLAIM STATUS IS ACTIVE
try:
    df = lifepro.select(*person_cols, *policy_cols, *claim_cols)
    df = df.withColumn('Accuracy: STATUS_CODE', f.when((df.POLICY_STATUS != "Active") & (df.CLAIM_STATUS == 'ACTIVE') & (df.RELATE_CODE.isin(['IN', 'MI'])), "fail: terminated policy must not have active claims").otherwise('pass: terminated policy must not have active claims'))
    s6 = get_summary(df)
    uc_write(s6)
except Exception as e:
    print(e)

# COMMAND ----------

#Date of Birth Consistency
def join_bday(df1, df2, sys):
    df1 = rename_fields(df1)
    df2 = rename_fields(df2)
    df = df1.join(df2,  (df1.FIRST_NAME == df2.FIRST_NAME) & (df1.LAST_NAME == df2.LAST_NAME) & (df1.SSN == df2.SSN) & (df1.BIRTH_DATE != df2.BIRTH_DATE), 'left')
    df = df.withColumn('Consistency: BIRTH_DATE', f.when(df2.BIRTH_DATE.isNotNull(), f.lit(f'fail: birth date must match for {sys[0]} and {sys[1]}')).otherwise(f.lit(f'pass: birth date must match for {sys[0]} and {sys[1]}')))
    # return df
    # display(df)
    config['source_system'] = sys[0]
    config['asset_name'] = sys[-1]
    summary = get_summary(df)
    return summary

def join_dday(df1, df2, sys):
    df1 = rename_fields(df1)
    df2 = rename_fields(df2)
    df = df1.join(df2,  (df1.FIRST_NAME == df2.FIRST_NAME) & (df1.LAST_NAME == df2.LAST_NAME) & (df1.SSN == df2.SSN) & (df1.DEATH_DATE != df2.DEATH_DATE), 'left')
    df = df.withColumn('Consistency: DEATH_DATE', f.when(df2.DEATH_DATE.isNotNull(), f.lit(f'fail: death date must match for {sys[0]} and {sys[1]}')).otherwise(f.lit(f'pass: death date must match for {sys[0]} and {sys[1]}')))
    config['source_system'] = sys[0]
    config['asset_name'] = sys[-1]
    summary = get_summary(df)
    return summary

def rename_fields(df):
    df = clean(df)
    for column in df.columns:
        if 'first' in column.lower():
            df = df.withColumnRenamed(column, 'FIRST_NAME')
        elif ('last' in column.lower()) & ('change' not in column.lower()) and('date' not in column.lower()):
            df = df.withColumnRenamed(column, 'LAST_NAME')
        elif ('ssn' in column.lower()) or ('tax_id' in column.lower()) or ('soc_sec_nbr' in column.lower()):
            df = df.withColumnRenamed(column, 'SSN')
        elif ('person_id' in column.lower()) or ('name_id' in column.lower()) or ('master_case_nbr' in column.lower()):
            df = df.withColumnRenamed(column, 'PERSON_ID')
    df = df.select('PERSON_ID', 'FIRST_NAME', 'LAST_NAME', 'BIRTH_DATE', 'SSN')
    return df

care = uc_read('care_tperson')
lifepro = uc_read('lifepro20_pname')
promise = uc_read('promise_t_person')
gltc = uc_read('gltc_claimant')

promise = promise.withColumn("BIRTH_DATE",f.date_format(f.to_timestamp("BIRTH_DATE"), "yyyy-MM-dd"))
lifepro = lifepro.withColumn('BIRTH_DATE', f.from_unixtime(f.unix_timestamp(f.col('DATE_OF_BIRTH').cast("string"), 'yyyyMMdd'), 'yyyy-MM-dd'))
care = care.withColumn("BIRTH_DATE", f.date_format((care['BIRTH_DT']), "yyyy-MM-dd"))
gltc = gltc.withColumn("BIRTH_DATE", f.date_format((gltc['Birth_Date']), "yyyy-MM-dd"))

promise = promise.withColumn("DEATH_DATE",f.date_format(f.to_timestamp("DATE_OF_DEATH"), "yyyy-MM-dd"))
lifepro = lifepro.withColumn('DEATH_DATE', f.from_unixtime(f.unix_timestamp(f.col('DEATH_DATE').cast("string"), 'yyyyMMdd'), 'yyyy-MM-dd'))
care = care.withColumn("DEATH_DATE", f.date_format((care['DEATH_DT']), "yyyy-MM-dd"))

try: 
    df1 = join_bday(care, lifepro, ['care', 'lifepro', 'care_tperson'])
    df2 = join_bday(care, promise, ['care', 'promise','care_tperson'])
    df3 = join_bday(care, gltc, ['care', 'gltc', 'care_tperson'])
    df4 = join_bday(lifepro, promise, ['lifepro', 'promise', 'lifepro20_pname'])
    df5 = join_bday(lifepro, gltc, ['lifepro', 'gltc', 'lifepro20_pname'])
    df6 = join_bday(promise, gltc, ['promise', 'gltc', 'promise_t_person'])
    df = df1.union(df2).union(df3).union(df4).union(df5).union(df6)
    uc_write(df)
except Exception as e:
    print(e)

try:
    df1 = join_dday(care, lifepro, ['care', 'lifepro', 'care_tperson'])
    df2 = join_dday(care, promise, ['care', 'promise','care_tperson'])
    df3 = join_dday(lifepro, promise, ['lifepro', 'promise', 'lifepro20_pname'])
    df = df1.union(df2).union(df3)
    uc_write(df)
except Exception as e:
    print(e)

# COMMAND ----------

config['data_system'] = 'promise'
t_person = uc_read('promise_t_person')
t_insured_coverage = uc_read('promise_t_insured_coverage')
t_claim = uc_read('promise_t_claim')
t_claim_status = uc_read('promise_t_claim_status')
t_product = uc_read('promise_t_product')
t_person = uc_read('promise_t_person')

t_person = clean(t_person)
t_claim_status = t_claim_status.filter(t_claim_status.END_DATE.isNull())

t_product = t_product.join(t_insured_coverage, on='PRODUCT_ID', how='left').distinct()
t_claim = t_claim.join(t_claim_status, on='CLAIM_ID', how='left')
t_claim = t_claim.join(t_product, on='INSURED_COVERAGE_ID', how='left')
df = t_person.join(t_claim, on='PERSON_ID', how='left')

person_cols = ['PERSON_ID','FIRST_NAME', 'LAST_NAME', 'BIRTH_DATE','DATE_OF_DEATH','TAX_ID']
policy_cols = ['LTC_ID', 'PRODUCT_ID', 'INSURED_PERSON_ID', 'INSURED_COVERAGE_ID', 'POLICY_NUMBER']
claim_cols = ['CLAIM_ID','CLAIM_NUMBER', 'CLAIM_SYSTEM', 'CLAIM_STATUS_CODE','CLAIM_SUB_STATUS_CODE','CLAIM_REPORTED_DATE', 'END_DATE']
product_cols = ['PRODUCT_ID', 'PRODUCT_NAME', 'PRODUCT_DESCRIPTION', 'TAX_QUALIFIED']

promise = df.select(*person_cols, *policy_cols, *claim_cols, *product_cols)

# COMMAND ----------

try: 
    df = promise.withColumn('Completeness: TAX_ID', f.when(promise['CLAIM_NUMBER'].isNotNull() & promise['TAX_ID'].isNull() & promise['TAX_QUALIFIED'] == 'true', 'fail: tax qualifying claimant must have ssn').otherwise('pass: tax qualifying claimant must have ssn'))    

    df = df.groupBy("POLICY_NUMBER","FIRST_NAME", 'LAST_NAME').agg(f.countDistinct('PERSON_ID').alias("distinct_sourceid")).filter(f.col('distinct_sourceid')>1).join(df, on=['FIRST_NAME', 'LAST_NAME', 'POLICY_NUMBER'], how='right').withColumn('Uniqueness: PERSON_ID', f.when(df.distinct_sourceid > 1, 'fail: policy number must have unique insured record').otherwise('pass: policy number must have unique insured record'))

    s10 = get_summary(df)
    uc_write(s10)
except Exception as e:
    print(e)

# COMMAND ----------

# person = person.filter(person.EDGE_NAME == 'IS_COVERED_BY')
# df = person.filter(person.SOURCE_SYSTEM == 'LIFEPRO').groupBy("POLICY_NUMBER","FIRST_NAME", 'LAST_NAME').agg(f.countDistinct('SOURCE_ID').alias("distinct_sourceid")).filter(f.col('distinct_sourceid')>1).join(person, on=['FIRST_NAME', 'LAST_NAME', 'POLICY_NUMBER'], how='inner').display()