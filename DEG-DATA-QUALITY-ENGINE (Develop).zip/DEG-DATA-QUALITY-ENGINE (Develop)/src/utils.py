# Databricks notebook source
# DBTITLE 1,Imports & Environment Variables
from datetime import datetime, timedelta
from pathlib import Path
from pytz import timezone
from pyspark.sql import functions as f
from pyspark.sql.window import Window
from pyspark.sql.types import *
from typing import Dict
from pyspark.sql import DataFrame
from pyspark.sql.functions import col, lit, when, regexp_extract, regexp_replace, count, row_number,current_date,to_date, lower, unix_timestamp

PROD_ADLS_STORAGE_ACCOUNT = 'dlsmfceus2aaihubprd01'
EXP_ADLS_STORAGE_ACCOUNT = 'ihubgovuatadbstadls'
NOW = datetime.now(timezone('America/Toronto'))
TIMESTAMP = NOW.strftime('%Y-%m-%d_%H-%M-%S')
US_STATES = ["AB","AL","AK","AZ","AR","BC","CA","CO","CT","DC","DE","FL","GA","GU","HI","ID","IL","IA","IN","KS","KY","LA","ME","MB","MD","MA","MH","MI","MN","MS","MO","MT","NB","NE","NV","NH","NL","NJ","NY","NC","NS","ND","NM","NT","NU","ON","OH","OK","OR","PA","PE","PR","PW","QC","RI","SC","SD","SK","TN","TX","UT","VT","VA","VI","YT","WA","WV","WI","WY","ZZ"]
CAN_PROVINCES = ['NL', 'PE', 'NS','NB','QC', 'ON','MB', 'SK', 'AB', 'YT','NT', 'NU']
uc_table = "dq_summary"
dimensions = ('Completeness:','Uniqueness:','Conformity:','Accuracy:','Timeliness:')

prod_config =  {
    "environment": "PROD",
    "client_id": "27b46b34-c800-42da-a3df-bb042f37e0fa",
    "scope": "secret-dpo-do-syn-prod",
    "key": "databricks-prod-secret",
    "storage_account": PROD_ADLS_STORAGE_ACCOUNT,
    "Synapse_Scope": "secret-dpo-do-syn-prod",
    "Synapse_Key": "svc-syn-prod-adb",
    "catalog": "usdo_prod_catalog"
}
exp_config = {
    "environment": "EXP",
    "client_id": "9bc544e2-8ec6-46a0-acc5-bac9b160e4b6",
    "scope": "gov-adb-platform-secret-scope",
    "key": "degspnsecret",
    "storage_account": EXP_ADLS_STORAGE_ACCOUNT,
    "Synapse_Scope": "scope-dpo-do-test",
    "Synapse_Key": "svc-syn-test-adb", 
    "catalog": "usdo_uat_catalog"
}

try:
    databricks_instance = spark.conf.get("spark.databricks.clusterUsageTags.clusterOwnerOrgId")
    if databricks_instance == '2496084869070462':
        ENV = prod_config
    elif databricks_instance == '5045225592557498':
        ENV = exp_config
    else: 
        raise Exception('Code is being run in an unknown Databricks instance!')
except:
    ENV = exp_config

syn_user = dbutils.secrets.get(scope=ENV['Synapse_Scope'], key=ENV["Synapse_Key"])
syn_pw = dbutils.secrets.get(scope=ENV['Synapse_Scope'], key=ENV["Synapse_Key"] + '-pw')

catalog = "usdo_prod_catalog"
schema = ""
asset = ""

# COMMAND ----------

# DBTITLE 1,Setup Functions
def configure_spark(): # NOSONAR
    spark_configuration_details = {
        "fs.azure.account.auth.type": "OAuth",
        "fs.azure.account.oauth.provider.type":  "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
        "fs.azure.account.oauth2.client.id": ENV['client_id'],
        "fs.azure.account.oauth2.client.secret": dbutils.secrets.get(scope=ENV['scope'], key=ENV['key']),
        "fs.azure.account.oauth2.client.endpoint": "https://login.microsoftonline.com/5d3e2773-e07f-4432-a630-1a0f68a28a05/oauth2/token",
        "spark.databricks.sqldw.jdbc.service.principal.client.id": ENV['client_id'],
        "spark.databricks.sqldw.jdbc.service.principal.client.secret": dbutils.secrets.get(scope=ENV['scope'], key=ENV['key'])
    }
    for key, value in spark_configuration_details.items():
        spark.conf.set(key, value)

# COMMAND ----------

config = {
"container": '',
"parent_dir": '',
"asset_name": '',
"work_stream": "",
"data_system": "",
"data_owner": "",
"business_unit": "",
"data_domain": "", 
"rule_owner": ""
} 

# COMMAND ----------

# DBTITLE 1,Core Functions
def read_asset_csv(filepath):
    df = spark.read.csv(filepath, header=True, inferSchema=True)
    return df

def uc_read(schema, asset):
    df = spark.sql(f"SELECT * FROM usdo_prod_catalog.{schema}.{asset}")
    config['parent_dir'] = f"usdo_prod_catalog.{schema}.{asset}" 
    config['asset_name'] = asset
    return df

def uc_read_uat(schema, asset):
    df = spark.sql(f"SELECT * FROM usdo_uat_catalog.{schema}.{asset}")
    return df

def uc_write(df, schema='data_quality', asset='dq_summary'):
    df.write.mode("append").saveAsTable(f"{ENV['catalog']}.{schema}.{asset}")

def write_df_to_csv_adls(df, delimiter: str = ',', header: bool = True, mode: str = 'overwrite'):
    abfss_path = f"abfss://dataquality@{ENV['storage_account']}.dfs.core.windows.net/KPI/data_quality_asset_logging"
    df.write.option("delimiter", delimiter).option("header", header).mode(mode).csv(abfss_path)

def trim(df, columns=None):
    if columns == None: columns = df.columns
    for column in columns:
        df = df.withColumn(column, f.ltrim(f.rtrim(df[column])))
    return df

def get_failed_rows(df):
    data_quality_columns = [column for column in df.columns if column.startswith(('Completeness:','Uniqueness:','Conformity:','Consistency:','Accuracy:'))]
    condition_expr = ".contains('fail') | ".join([f"df['{column}']" for column in data_quality_columns]) + ".contains('fail')"
    failed_rows_df = df.filter(eval(condition_expr))
    return failed_rows_df


def filter_dimension_columns(df, dimensions=dimensions):
    df = df.select([col(f"`{x}`") for x in df.columns if x.startswith((dimensions))])
    return df

def get_consistency_summary(df, schema):
    data = []
    total_rows = df.count()
    for c in df.columns:
        if "must equal" in c:
            column = c.split()[1] + ', ' + c[c.find('[') + 1:c.find(']')]
            rule = c.split('Consistency: ')[1]
            failed_rows = df.filter(col(c).contains(f'fail')).count()
            passed_rows = df.filter(col(c).contains(f'pass')).count()
        else:
            results = df.select(c).distinct().collect()
            rule = list(set(str(val[c]).split(': ', 1)[1] for val in results if ': ' in str(val[c])))[-1]
            failed_rows = df.filter(col(c).contains(f'fail: {rule}')).count()
            passed_rows = df.filter(col(c).contains(f'pass: {rule}')).count()
            column = c.split(': ')[1]
            
        data.append([column, rule, 'Consistency', failed_rows, passed_rows])

    df = spark.createDataFrame(data, schema).distinct()
    return df

def uc_write_thresholds(df, schema='data_quality', asset='thresholds'):
    name = f"{ENV['catalog']}.{schema}.{asset}"
    df.write.mode("overwrite") \
        .option("overwriteSchema", "true") \
        .option("replaceWhere", f"workstream = '{df.first()['workstream']}'") \
        .saveAsTable(name)


# def add_threshold(df, conditions):
#     if conditions is None or not conditions:
#         return df.withColumn('threshold', f.lit(0))
#     expr = None
#     for key, rules in conditions.items():
#         for rule in rules:
#             if expr is None:
#                 expr = f.when(
#                     (f.col('column_name') == key) & (f.col('data_quality_rule') == rule['Rule']), rule['Threshold']
#                 )
#             else:
#                 expr = expr.when((f.col('column_name') == key) & (f.col('data_quality_rule') == rule['Rule']), rule['Threshold'])
#     if expr is None:
#         expr = f.lit(0)
#     else:
#         expr = expr.otherwise(0)
#     return df.withColumn('threshold', expr)
schema = StructType([StructField('column_name', StringType(), True), StructField('data_quality_rule', StringType(), True), StructField('dimension', StringType(), True), StructField('failed_rows', IntegerType(), True), StructField('passed_rows', IntegerType(), True)])

def get_file_format(path):
    try: 
        desc = spark.sql(f"DESCRIBE EXTENDED {path}")  
        provider_row = desc.filter(desc.col_name == 'Provider').collect()
        if provider_row == []:
            provider_row = desc.filter(desc.col_name == 'Type').collect()
        filetype = provider_row[0]["data_type"]
    except Exception as e:
        print(e)
        filetype = ""
    return filetype
    
def get_summary(df, config = config, dim = dimensions, schema = schema):
    total_rows = df.count()
    date = TIMESTAMP[:10]
    # df.cache()
    data = []
    if config['container'] == "":
        path = config['parent_dir']
        filetype = get_file_format(path)
    else:
        path = "abfss://"+config['container']+"@"+PROD_ADLS_STORAGE_ACCOUNT+".dfs.core.windows.net/"+config['parent_dir']+'/'+config['asset_name']
        if 'parquet' in path: filetype = 'parquet'
        elif 'delta' in path: filetype = 'delta'
        else: filetype = ""

    c_df = filter_dimension_columns(df, ('Consistency'))
    df = filter_dimension_columns(df, (dim))
    for c in df.columns:
        # dimension = c.split(':')[0]
        # column = c.split(': ')[-1].lower()
        dimension = c.split(':', 1)[0]
        column = c.split(':', 1)[1].strip().lower() if ':' in c else c.lower()

        results = df.select(col(f"`{c}`")).distinct().collect()
        unique_results = list(set(str(val[c]).split(': ', 1)[1] for val in results if ': ' in str(val[c])))
        for r in unique_results:
            failed_rows = df.filter(col(f"`{c}`").contains(f'fail: {r}')).count()
            passed_rows = df.filter(col(f"`{c}`").contains(f'pass: {r}')).count()
            data.append([column, r, dimension, failed_rows, passed_rows])
    
    df.unpersist()
    df = spark.createDataFrame(data, schema).distinct()
    if len(c_df.columns)>0:
        c_sum = get_consistency_summary(c_df, schema)
        df = df.union(c_sum)

    df = df.withColumn('score', (df.passed_rows / total_rows)).withColumn('scan_date', lit(date))
    df = df.withColumn('source_system', lit(config['data_system'].lower()))
    df = df.withColumn('asset_name', lit(config['asset_name'].lower()))
    df = df.withColumn('workstream', lit(config['work_stream'].lower()))
    df = df.withColumn("total_rows", lit(total_rows))
    df = df.withColumn('data_owner', lit(config['data_owner']))
    df = df.withColumn('business_unit', lit(config['business_unit']))
    df = df.withColumn('data_domain', lit(config['data_domain']))
    df = df.withColumn('rule_owner', lit(config['rule_owner']))
    df = df.withColumn('file_location', lit(path))
    df = df.withColumn('file_type', lit(filetype))
    df = df.withColumn('platform', lit('Databricks'))
    df = df.withColumn('rule_status', lit('active'))

    df = df.withColumn('segment', lit("US")).withColumn('company', lit("JohnHancock"))

    thresholds = spark.sql(f"SELECT * FROM usdo_prod_catalog.data_quality.thresholds")
    df = df.join(thresholds, on=['workstream', 'source_system', 'asset_name', 'column_name', 'data_quality_rule'], how='left')

    
    df = df.withColumn('priority', f.when(df['threshold'] > df['score'], 'High')
        .when(df['Score'] > 0.75, 'Low')
        .when(df['Score'] > 0.5, 'Medium').otherwise('High'))

    df = df.select(['scan_date','company','segment','data_owner','business_unit', 'data_domain','workstream', 'source_system','asset_name', 'column_name', 'dimension' ,'data_quality_rule', 'total_rows', 'passed_rows', 'failed_rows', 'score', 'threshold','priority','file_location','file_type', 'rule_status' ,'rule_owner', 'platform'])

    return df

def view_dq_results(df, column, dimension, value):
    df = df.filter(df[dimension + ': ' + column] == value)
    value_counts_df = df.groupBy(column).count().orderBy(f.col("Count").desc())
    return value_counts_df

def save_results_uc(df):
    if ENV == 'PRD': catalog = 'usdo_prd_catalog'
    else: catalog = 'usdo_uat_catalog'
    df.write.mode("append").option("mergeSchema", "true").saveAsTable(f"{catalog}.data_quality.dq_summary_legacy")

def rename_columns(df, columns):
    for column in columns:
        if isinstance(column, list):
            df = df.withColumnRenamed(column[0], column[1])
        else:
            df = df.withColumnRenamed(columns[0], columns[1])
            return df
    return df

def format_date(df, columns):
    if isinstance(columns, list):
        for column in columns:
            df = df.withColumn(column, f.date_format((df[column]),"yyyy-MM-dd"))
    else: 
        df = df.withColumn(column, f.date_format((df[column]),"yyyy-MM-dd"))
    return df

# COMMAND ----------

# DBTITLE 1,Rule Functions
#DQ DIMENSION: Completeness
def completeness_check(df,column, optional_falsies=None):
    df = df.withColumn(f'Completeness: {column}', f.when(~(df[column].isNull()), 'pass: must contain non null value').otherwise('fail: must contain non null value'))
    if isinstance(optional_falsies, list):
        for falsy_value in optional_falsies:
            df = df.withColumn(f'Completeness: {column}', f.when((df[column] == falsy_value), 'fail: must contain non null value').otherwise(df[f'Completeness: {column}']))
    elif optional_falsies != None:
        df = df.withColumn(f'Completeness: {column}', f.when((df[column] == optional_falsies), 'fail: must contain non null value').otherwise(df[f'Completeness: {column}']))
    return df

#DQ DIMENSION: Uniqueness
def uniqueness_check(df,column):
    if isinstance(column, str):
        df = df.withColumn(f"Uniqueness: {column}"
                        ,f.when(f.count("*").over(Window.partitionBy(column)) == 1, 'pass: must contain unique value')
                        .otherwise('fail: must contain unique value'))
    elif isinstance(column, list):
        column_list = column
        selected_columns = [df[column_name] for column_name in column_list]
        df = df.withColumn('TEMPORARY_COLUMN', f.concat_ws("_", *[f.col(c) for c in column]))
        df = df.withColumn(f"Uniqueness: {', '.join(column)}"
                    ,f.when(f.count("*").over(Window.partitionBy('TEMPORARY_COLUMN')) == 1, 'pass: must contain unique value')
                    .otherwise('fail: must contain unique value'))
        df = df.drop('TEMPORARY_COLUMN')
    else:
        raise ValueError('Uniqueness check requires a column or list of columns')
    return df

def consistency_check(df, ref_table_name, primary_key, foreign_key, check_col1, check_col2):
    df = df.withColumn('check_col1', df[check_col1])
    df = df.withColumn('check_col2', df[check_col2])

    df = df.fillna({'check_col1': 'null'})
    df = df.fillna({'check_col2': 'null'})

    df = df.withColumn(
        f'Consistency: {check_col1} must equal {ref_table_name}[{check_col2}] on {primary_key} = {ref_table_name}[{foreign_key}]', 
        f.when(df['check_col1'] == df['check_col2'], 'pass')
        .otherwise(f.concat(f.lit('fail: ['), df['check_col1'], f.lit('] != ['), df['check_col2'], f.lit(']'))))
    
    df = df.drop(df['check_col1'])
    df = df.drop(df['check_col2'])

    return df

# COMMAND ----------

# DBTITLE 1,Referential Integrity Check
def referential_integrity_check(df, fk_column, ref_schema, ref_table, pk_column, catalog=None):
    """Check that all non-null values in fk_column exist in the reference table's pk_column.
    
    Adds a 'Consistency: {fk_column}' column with pass/fail values compatible with get_consistency_summary.
    
    Args:
        df: The child DataFrame being checked.
        fk_column: The foreign key column name in df.
        ref_schema: The schema of the reference (parent) table.
        ref_table: The name of the reference (parent) table.
        pk_column: The primary key column in the reference table.
        catalog: The catalog name (defaults to the current ENV catalog).
    
    Returns:
        DataFrame with an added Consistency check column.
    """
    catalog = catalog or ENV["catalog"]
    rule = f"must exist in {ref_table}[{pk_column}]"
    
    # Get distinct valid PK values from the reference table
    valid_keys = (
        spark.table(f"{catalog}.{ref_schema}.{ref_table}")
        .select(f.col(pk_column).alias("_ref_pk"))
        .where(f.col("_ref_pk").isNotNull())
        .distinct()
    )
    
    # Left join to check existence (DISTINCT ensures no row multiplication)
    result = df.join(
        valid_keys,
        df[fk_column] == valid_keys["_ref_pk"],
        "left"
    )
    
    # Mark pass/fail — NULL foreign keys are considered acceptable (pass)
    result = result.withColumn(
        f'Consistency: {fk_column}',
        f.when(f.col(fk_column).isNull(), f'pass: {rule}')
         .when(f.col("_ref_pk").isNotNull(), f'pass: {rule}')
         .otherwise(f'fail: {rule}')
    )
    
    result = result.drop("_ref_pk")
    return result

# COMMAND ----------


def read_asset(container, parent_dir, data_system,work_stream, asset_name, **kwargs): # NOSONAR
    df = spark.read.parquet(f'abfss://{container}@{PROD_ADLS_STORAGE_ACCOUNT}.dfs.core.windows.net/{parent_dir}/{asset_name}', header ='True')
    return df

def read_asset_delta(container, parent_dir, data_system,work_stream, asset_name, **kwargs): # NOSONAR
    df = spark.read.format('delta').load(f'abfss://{container}@{PROD_ADLS_STORAGE_ACCOUNT}.dfs.core.windows.net/{parent_dir}/{asset_name}', header ='True')
    return df
    
def save_parquet_results(failed_rows_df, summary_df, asset_name, work_stream, data_system,**kwargs): # NOSONAR
    if failed_rows_df is None:
        summary_df.write.parquet(f"abfss://dataquality@{ENV['storage_account']}.dfs.core.windows.net/{work_stream}/{asset_name}/{TIMESTAMP}/scan_summary")

    if data_system == '':
        failed_rows_df.write.parquet(f"abfss://dataquality@{ENV['storage_account']}.dfs.core.windows.net/{work_stream}/{asset_name}/{TIMESTAMP}/failed_rows")
        summary_df.write.parquet(f"abfss://dataquality@{ENV['storage_account']}.dfs.core.windows.net/{work_stream}/{asset_name}/{TIMESTAMP}/scan_summary")
    else:
        failed_rows_df.write.parquet(f"abfss://dataquality@{ENV['storage_account']}.dfs.core.windows.net/{work_stream}/{data_system}/{asset_name}/{TIMESTAMP}/failed_rows")
        summary_df.write.parquet(f"abfss://dataquality@{ENV['storage_account']}.dfs.core.windows.net/{work_stream}/{data_system}/{asset_name}/{TIMESTAMP}/scan_summary")