# Databricks notebook source
from pyspark.sql import functions as f
from datetime import datetime, timedelta

US_STATES = ["AB","AL","AK","AZ","AR","BC","CA","CO","CT","DC","DE","FL","GA","GU","HI","ID","IL","IA","IN","KS","KY","LA","ME","MB","MD","MA","MH","MI","MN","MS","MO","MT","NB","NE","NV","NH","NL","NJ","NY","NC","NS","ND","NM","NT","NU","ON","OH","OK","OR","PA","PE","PR","PW","QC","RI","SC","SD","SK","TN","TX","UT","VT","VA","VI","YT","WA","WV","WI","WY","ZZ"]
CAN_PROVINCES = ['NL', 'PE', 'NS','NB','QC', 'ON','MB', 'SK', 'AB', 'YT','NT', 'NU']
TIMESTAMP = NOW.strftime('%Y-%m-%d_%H-%M-%S')
BUSINESS_values_to_check = ['Care enter', 'Assisted Living', 'Care Home', 'Care Community', 'Memory Care', 'Research Center', 'Senior Living']

# COMMAND ----------

def format_dates(df, column):
    if isinstance(column, str):
         df = df.withColumn(column, f.to_date(f.col(column).cast("string"), 'yyyyMMdd'))
    elif isinstance(column, list):
        for c in column:
            df = df.withColumn(c, f.to_date(f.col(c).cast("string"), 'yyyyMMdd'))
    return df
    

# COMMAND ----------

def completeness_with_dependency(df, column, dep_col, value, rule="must contain non null value"):
    df = df.withColumn(f'Completeness: {column}', f.when((df[dep_col]== value) & (df[column].isNull()), f'fail: {rule}').otherwise(f'pass: {rule}'))
    return df

def completeness_with_list_dependency(df, column, dep_col, list, rule="must contain non null value"):
    df = df.withColumn(f'Completeness: {column}', f.when((df[dep_col].isin(list)) & (df[column].isNull()), f'fail: {rule}').otherwise(f'pass: {rule}'))
    return df

def completeness_triple_dependency(df, c1, c2, c3, rule="must contain non null value"):
    df = df.withColumn(f"Completeness: {c1}, {c2} , {c3}", f.when(((df[c1].isNull()) & (df[c2].isNull()) & (df[c3].isNull())) , f'fail: {rule}').otherwise(f'pass: {rule}'))
    return df


# COMMAND ----------

def conformity_ssn(df, column):
    df = df.withColumn(f'Conformity: {column}', f.when(df[column].rlike(r'^\d{9}$'),'pass: must contain 9 digit value')
        .when(df[column].rlike(r'.*[a-zA-Z].*'),'fail: must contain 9 digit value')
        .when(df[column].rlike(r"[\p{P}]"), 'fail: must contain 9 digit value')
        .when(df[column].isNull(), 'pass: must contain 9 digit value')
        .when(df[column].rlike(r'^.{0,8}$'),'fail: must contain 9 digit value')
        .when(df[column] == '         ', 'fail: must contain 9 digit value')
        .otherwise('fail: must contain 9 digit value'))
    return df

def conformity_ssn_4_digit(df, column):
    df = df.withColumn(f'Conformity: {column}', f.when(df[column].rlike(r"\d{4}$"), 'pass: must contain 4 digit number').when(df[column].isNull(), 'pass: must contain 4 digit number').otherwise('fail: must contain 4 digit number'))
    return df

def conformity_datetime(df, column):
    df = df.withColumn(f'Conformity: {column}', f.when(df[column].rlike(r'^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$'), 'pass: must adhere to datetime format').otherwise('fail: must adhere to datetime format'))
    return df

def conformity_name(df, column):
    business_indicators = ['LLC', 'Inc', 'Corporation', 'Corp', 'Ltd', 'Limited']
    pattern = '|'.join([rf'\b{indicator}\b' for indicator in business_indicators])

    df = df.withColumn(
        f'Conformity: {column}',
        f.when(f.col(column).rlike(pattern), 'fail: must contain name in expected format')
         .when(f.col(column).endswith('Co.'), 'fail: must contain name in expected format')
         .when(f.col(column).rlike(r"(Mrs\.|Ms\.|Mr\.|Miss\.|Dr\.|Jr\.|Sr\.|MD\.|I|II|III)"), 'fail: must contain name in expected format')
         .when(f.col(column).isNull(), 'pass: must contain name in expected format')
         .when(f.col(column).contains('Estate'), 'fail: must contain name in expected format')
         .when(f.col(column).rlike(r"^[a-zA-Z' \-]+$"), 'pass: must contain name in expected format')
         .when(f.col(column).rlike(r"\b[A-Z]\."), 'fail: must contain name in expected format')
         .when(f.col(column).rlike(r"\s{2,}"), 'fail: must contain name in expected format')
         .when(f.length(f.col(column)) < 3, 'fail: must contain name in expected format')
         .when(f.col(column).contains('C/o'), 'fail: must contain name in expected format')
         .otherwise('fail: must contain name in expected format')
    )
    return df

def conformity_business(df, column):
    df = df.withColumn(f'Conformity: {column}',f.when(f.col(column).rlike(r'\s{2,}'), 'fail: must contain business name in expected format').when((df[column].isNull()) | (df[column].rlike(r'^[A-Za-z0-9\s]')), 'pass: must contain business name in expected format').otherwise('fail: must contain business name in expected format'))
    return df

def conformity_birthdate(df, column):
    df = df.withColumn(f'Conformity: {column}', f.when(df[column].rlike(r'\d{8}'), 'pass: must adhere to date format YYYY-MM-DD')
        .when(df[column].rlike(r'\d{4}-\d{2}-\d{2}'), 'pass: must adhere to date format YYYY-MM-DD')
        .when(df[column].isNull(), 'pass: must adhere to date format YYYY-MM-DD')
        .otherwise('fail: must adhere to date format YYYY-MM-DD'))
    return df

def conformity_deathdate(df, column):
    df = df.withColumn(f'Conformity: {column}', f.when(df[column].rlike(r'\d{8}'), 'pass: must adhere to date format YYYY-MM-DD')
        .when(df[column].rlike(r'\d{4}-\d{2}-\d{2}'), 'pass: must adhere to date format YYYY-MM-DD')
        .when(df[column].isNull(), 'pass: must adhere to date format YYYY-MM-DD')
        .otherwise('fail: must adhere to date format YYYY-MM-DD'))
    return df
    
def conformity_gender(df, column):
    df = df.withColumn(f'Conformity: {column}', f.when(df[column].rlike(r'^[A-Z]$'), 'pass: must contain single alphabetic value')
        .when(df[column].isNull(), 'pass: must contain single alphabetic value')
        .otherwise('fail: must contain single alphabetic value'))
    return df

def conformity_policynumber(df, column, min_digits=7, max_digits=9):
    df = df.withColumn(f'Conformity: {column}',
        f.when(df[column].rlike(rf'^\d{{{min_digits},{max_digits}}}$'), f'pass: must be a {min_digits}-{max_digits} digit number')
         .when(df[column].rlike(rf'^\d{{{max_digits + 1},}}$'), f'fail: must be a {min_digits}-{max_digits} digit number')
         .when(df[column].rlike(rf'^\d{{1,{min_digits - 1}}}$'), f'fail: must be a {min_digits}-{max_digits} digit number')
         .when(df[column].isNull(), f'pass: must be a {min_digits}-{max_digits} digit number')
         .otherwise(f'fail: must be a {min_digits}-{max_digits} digit number'))
    return df

def conformity_addr1(df, column):
    df = df.withColumn(column, f.upper(df[column]))
    df = df.withColumn(f'Conformity: {column}', f.when(df[column].isNull(), 'pass: must adhere to address format')
        .when(df[column].contains('ATTN:'), 'pass: must adhere to address format')
        .when(df[column].contains('PO Box'), 'pass: must adhere to address format')
        .when(df[column].contains('C/O:'), 'fail: must adhere to address format')
        .when(df[column].contains('FBO:'), 'fail: must adhere to address format')
        .when(f.length(df[column]) < 3, 'fail: must adhere to address format')
        .when(df[column].rlike('|'.join(BUSINESS_values_to_check)),'fail: must adhere to address format')
        .when(df[column].rlike(r"[^@\s]+@[^@\s]+\.[^@\s]+"), 'fail: must adhere to address format')
        .when(df[column].rlike(r"^[\w\s\d'\-./#(),]+$"), 'pass: must adhere to address format')
        .when(df[column].rlike(r".*[?$%^&*¬><!{}:‹~¿_`;:|+=°®•].*"), "fail: must adhere to address format")
        .otherwise('fail: must adhere to address format'))
    return df

def conformity_addr2(df, column):
    df = df.withColumn(column, f.upper(df[column]))
    df = df.withColumn(f'Conformity: {column}', f.when(df[column].isNull(), 'pass: must adhere to address format')
        .when(df[column].contains('ATTN:'), 'fail: must adhere to address format')
        .when(df[column].contains('PO Box'), 'pass: must adhere to address format')
        .when(df[column].contains('C/O:'), 'pass: must adhere to address format')
        .when(df[column].contains('FBO:'), 'pass: must adhere to address format')
        .when(f.length(df[column]) < 3, 'fail: must adhere to address format')
        .when(df[column].rlike('|'.join(BUSINESS_values_to_check)),'fail: must adhere to address format')
        .when(df[column].rlike(r"[^@\s]+@[^@\s]+\.[^@\s]+"), 'fail: must adhere to address format')
        .when(df[column].rlike(r"^[\w\s\d'\-./#(),]+$"), 'pass: must adhere to address format')
        .when(df[column].rlike(r".*[?$%^&*¬><!{}:‹~¿_`;:|+=°®•].*"), "fail: must adhere to address format")
        .otherwise('fail: must adhere to address format'))
    return df

def conformity_addr3(df, column):
    df = df.withColumn(column, f.upper(df[column]))
    df = df.withColumn(f'Conformity: {column}', f.when(df[column].isNull(), 'pass: must adhere to address format')
        .when(df[column].contains('ATTN:'), 'fail: must adhere to address format')
        .when(df[column].contains('PO Box'), 'pass: must adhere to address format')
        .when(df[column].contains('C/O:'), 'fail: must adhere to address format')
        .when(df[column].contains('FBO:'), 'fail: must adhere to address format')
        .when(df[column].rlike('|'.join(BUSINESS_values_to_check)),'fail: must adhere to address format')
        .when(f.length(df[column]) < 3, 'fail: must adhere to address format')
        .when(df[column].rlike(r"[^@\s]+@[^@\s]+\.[^@\s]+"), 'fail: must adhere to address format')
        .when(df[column].rlike(r"^[\w\s\d'\-./#(),]+$"), 'pass: must adhere to address format')
        .when(df[column].rlike(r".*[?$%^&*¬><!{}:‹~¿_`;:|+=°®•].*"), "fail: must adhere to address format")
        .otherwise('fail: must adhere to address format'))
    return df

def conformity_city(df, column):
    df = df.withColumn(f'Conformity: {column}', f.when(df[column].isNull(), 'pass: must only contain alphabetic values')
        .when(df[column].rlike(r'\d'), 'fail: must only contain alphabetic values')
        .when(df[column].rlike(r".*[?$%^&*¬><!{}:‹~,¿_`;:|+=°®•].*"), 'fail: must only contain alphabetic values')
        .when(df[column].rlike(r"^[A-Za-z\s'.-]+$"), 'pass: must only contain alphabetic values')
        .otherwise('fail: must only contain alphabetic values'))
    return df

def conformity_state(df, column):
    df = df.withColumn(f'Conformity: {column}', f.when(df[column].isin(US_STATES), 'pass: must contain US state code or Canadian province')
        .when(df[column].isin(CAN_PROVINCES), 'pass: must contain US state code or Canadian province')
        .when(df[column].rlike(r'\d'), 'fail: must contain US state code or Canadian province')
        .when(df[column].isNull(), 'pass: must contain US state code or Canadian province')
        .otherwise('fail: must contain US state code or Canadian province'))
    return df

def conformity_phone(df, column):
    df = df.withColumn(f"Conformity: {column}", f.when(df[column].rlike(r'^\d{10}$'), 'pass: must contain 10 digit phone number')
        .when(df[column].isNull(), 'pass: must contain 10 digit phone number')
        .otherwise('fail: must contain 10 digit phone number'))
    return df

def conformity_email(df, column):
    df = df.withColumn(f'Conformity: {f"{column}"}',  f.when(f.col(f"`{column}`").contains(" "), 'fail: must adhere to email format (example@gmail.com)')
    .when(f.col(f"`{column}`").rlike(r"^[a-zA-Z0-9._%+&'-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"),'pass: must adhere to email format (example@gmail.com)')
    .when(f.col(f"`{column}`").isNull(), 'pass: must adhere to email format (example@gmail.com)')
    .otherwise('fail: must adhere to email format (example@gmail.com)'))
    return df

def conformity_postalcode(df, column):
    df = df.withColumn(f'Conformity: {column}',
        f.when(f.col(column).rlike(r'^\d{5}$'), 'pass: must adhere to US or Canadian postal code format')
         .when(f.col(column).rlike(r'^\d{9}$'), 'pass: must adhere to US or Canadian postal code format')
         .when(f.col(column).rlike(r'^\d{5}-\d{4}$'), 'pass: must adhere to US or Canadian postal code format')
         .when(f.col(column).rlike(r'^[A-Za-z]\d[A-Za-z]\d[A-Za-z]\d$'), 'pass: must adhere to US or Canadian postal code format')
         .when(f.col(column).rlike(r'^[A-Za-z]\d[A-Za-z] \d[A-Za-z]\d$'), 'pass: must adhere to US or Canadian postal code format')
         .when(f.col(column).isNull(), 'pass: must adhere to US or Canadian postal code format')
         .otherwise('fail: must adhere to US or Canadian postal code format'))
    return df

def conformity_postalcode_us(df, column):
    df = df.withColumn(f'Conformity: {column}',
        f.when(f.col(column).rlike(r'^\d{5}$'), 'pass: must adhere to US postal code format')
        .when(f.col(column).rlike(r'^\d{9}$'), 'pass: must adhere to US postal code format')
        .when(f.col(column).rlike(r'^\d{5}-\d{4}$'), 'pass: must adhere to US postal code format').otherwise('fail: must adhere to US postal code format'))
    return df

def conformity_age(df, column):
    df = df.withColumn(f'Conformity: {column}', f.when(df[column].rlike(r'^\d{1,3}'), 'pass: must contain numerical value').otherwise('fail: must contain numerical value'))
    return df

def conformity_npn(df, column):
    df = df.withColumn(f'Conformity: {column}', f.when(df[column].rlike(r'^\d{4,10}$'), 'pass: must be a 4-10 digit number')
        .otherwise('fail: must be a 4-10 digit number'))
    return df

def conformity_check_value_integer(df, column):
    df = df.withColumn(f'Conformity: {column}', f.when((df[column].rlike(r'^\d*[1-9]\d*$')| (df[column].isNull())), 'pass: must be a postive numeric value').otherwise('fail: must be a postive numeric value'))
    return df

def conformity_check_alphabetic_value(df, column):
    df = df.withColumn(f'Conformity: {column}', f.when((df[column].rlike(r'^[A-Z]$')) | (df[column].isNull()),'pass: must contain single alphabetic character').otherwise('fail: must contain single alphabetic character'))
    return df

def conformity_check_punctuation(df, column):
    df = df.withColumn(f'Conformity: {column}', f.when(df[column].rlike(r"[^\w\s]"), 'fail: must not contain punctuation').otherwise('pass: must not contain punctuation'))
    return df



# COMMAND ----------


REFERENCE_DATE = "1900-01-01"
SYSTEM_DEFAULT = "9999-12-31"

def accuracy_ssn(df, column):
    df = df.withColumn(f'Accuracy: {column}',f.when(df[column].rlike(r'^(?!000|666|900|999)\d{3}(?!00)\d{2}(?!0000)\d{4}$'), 'pass: must conform to irs rules')                
        .otherwise('fail: must conform to irs rules'))
    return df

def accuracy_gender(df, column):
    df = df.withColumn(f'Accuracy: {column}', f.when(df[column].rlike(r'^[FM]$'), 'pass: must contain F or M')
        .when(df[column].isNull(), 'pass: must contain F or M')
        .otherwise('fail: must contain F or M'))
    return df

def accuracy_birthdate(df, column):
    df = df.withColumn(f'Accuracy: {column}', f.when(df[column] <= REFERENCE_DATE, 'fail: must contain date before today or system default value')
        .when(df[column] <= TIMESTAMP[:10], 'pass: must contain date before today or system default value')
        .when(df[column] == SYSTEM_DEFAULT, 'pass: must contain date before today or system default value')
        .when(df[column] > TIMESTAMP[:10], 'fail: must contain date before today or system default value')
        .when(df[column].isNull(), 'pass: must contain date before today or system default value')
        .otherwise('fail: must contain date before today or system default value'))
    return df

def accuracy_deathdate(df, column):
    df = df.withColumn(f'Accuracy: {column}', f.when(df[column] <= REFERENCE_DATE, 'fail: must contain date before today or system default value')
        .when(df[column] <= TIMESTAMP[:10], 'pass: must contain date before today or system default value')
        .when(df[column] == SYSTEM_DEFAULT, 'pass: must contain date before today or system default value')
        .when(df[column] > TIMESTAMP[:10], 'fail: must contain date before today or system default value')
        .when(df[column].isNull(), 'pass: must contain date before today or system default value')
        .otherwise('fail: must contain date before today or system default value'))
    return df

def accuracy_phone(df, column):
    df = df.withColumn(f"Accuracy: {column}", f.when(df[column].rlike(r"^(.)\1*$"), "fail: must not contain repeated number")
        .when(df[column].rlike(r"^0*([1-9])0*$"), "fail: must not contain repeated number")
        .when(df[column].rlike(r"^[01]+$"), "fail: must not contain repeated number")
        .when(df[column].rlike(r"^[123]+$"), "fail: must not contain repeated number")
        .when(df[column] == '1234567890', 'fail: must not contain repeated number')
        .otherwise("pass: must not contain repeated number"))
    return df

def accuracy_city(df, column):
    df = df.withColumn(f'Accuracy: {column}', f.when(df[column].contains('PO Box'), 'fail: must contain city value')
        .when(df[column].contains('C/O:'), 'fail: must contain city value')
        .otherwise('pass: must contain city value'))
    return df

def accuracy_state_us(df, column):
    df = df.withColumn(f'Accuracy: {column}', f.when(df[column].isin(US_STATES), 'pass: must contain valid state code').otherwise('fail: must contain valid state code'))
    return df

def accuarcy_age(df, column):
    df = df.withColumn(f'Accuracy: {column}', f.when(df[column] > 0, 'pass: must be greater than zero').otherwise('fail: must be greater than zero'))
    return df

def accuracy_npn(df, column):
    df = df.withColumn(f'Accuracy: {column}', 
        f.when(df[column].rlike(r'(?!0).*'), 'pass: must not start with zero and contain atleast two digits')
        .when(~(df[column].rlike(r'^(\d)\1*$')), 'pass: must not start with zero and contain atleast two digits')     
        .when((df[column] == '')|(df[column].isNull()),'fail: must not start with zero and contain atleast two digits')           
        .otherwise('fail: must not start with zero and contain atleast two digits'))
    return df

def accuracy_check_value(df, column, values):
    if isinstance(values, str):
        df = df.withColumn(f'Accuracy: {column}', f.when((df[column] == values), f'pass: value must be {values}').otherwise(f'fail: value must be {values}')) 

    elif isinstance(values, list):
        if None in values:
            df = df.withColumn(f'Accuracy: {column}', f.when(df[column].isin(values), f'pass: value must be {values}').when(df[column].isNull(), f'pass: value must be {values}').otherwise(f'fail: value must be {values}'))
        else:
            df = df.withColumn(f'Accuracy: {column}', f.when(df[column].isin(values), f'pass: value must be {values}').otherwise(f'fail: value must be {values}'))
    return df

def accuarcy_greaterthan(df, column, value):
    df = df.withColumn(f'Accuracy: {column}', f.when(df[column] >= value, f'pass: must be greater than {value}').otherwise(f'fail: must be greater than {value}'))
    return df

def accuarcy_between(df, column, lower, upper):
    df = df.withColumn(f'Accuracy: {column}', f.when(f.col(column).between(lower, upper), f"pass: must be between {lower} and {upper}").otherwise(f"fail: must be between {lower} and {upper}"))
    return df

def accuracy_date(df, column, TIMESTAMP=TIMESTAMP, system_default = None):
    if system_default is not None:
        df = df.withColumn(f'Accuracy: {column}', f.when(df[column] <= TIMESTAMP[:10], 'pass: must not contain future date').when(df[column].isNull(), 'pass: must not contain future date').when(df[column] == system_default, 'pass: must not contain future date').otherwise('fail: must not contain future date'))

    else:
        df = df.withColumn(f'Accuracy: {column}', f.when(df[column] <= TIMESTAMP[:10], 'pass: must not contain future date').when(df[column].isNull(), 'pass: must not contain future date').otherwise('fail: must not contain future date'))
    return df