# Databricks notebook source
# MAGIC %pip install openpyxl

# COMMAND ----------

# DBTITLE 1,Run Scanner
# Standard library
from __future__ import annotations
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
import traceback

# Third-party
import pandas as pd
from delta.tables import DeltaTable
from pyspark.sql import DataFrame as SparkDataFrame, Row
from pyspark.sql.functions import col, concat_ws, expr, lit, when, regexp_extract

# ─── Configure Run ──────────────────────────────────────────────────────────

try:
    dbutils.widgets.dropdown("DRY_RUN", "false", ["false", "true"])
except Exception as e:
    if "already exists" not in str(e).lower():
        raise

DRY_RUN = dbutils.widgets.get("DRY_RUN").strip().lower() == "true"

# Automatically select the output catalog based on the workspace.
# adb-2496084869070462.2.azuredatabricks.net is the production workspace.
_PROD_WORKSPACE = "adb-2496084869070462.2.azuredatabricks.net"
_workspace_url = spark.conf.get("spark.databricks.workspaceUrl", "")
OUTPUT_CATALOG = "usdo_prod_catalog" if _PROD_WORKSPACE in _workspace_url else "usdo_uat_catalog"
print(f"Workspace: {_workspace_url}  →  OUTPUT_CATALOG={OUTPUT_CATALOG}")

SOURCE_CATALOG = "usdo_prod_catalog"
PRIMARY_KEYS_VOLUME = f"/Volumes/{OUTPUT_CATALOG}/data_quality/primary_keys_scanner"
PRIMARY_KEYS_FILE = f"{PRIMARY_KEYS_VOLUME}/primary_keys.xlsx"
PRIMARY_KEYS_METADATA_FILE = f"{PRIMARY_KEYS_VOLUME}/primary_keys_metadata.xlsx"

MAX_WORKERS = 32
scan_date = datetime.now().strftime("%Y-%m-%d")


# ─── Build Scan Targets ──────────────────────────────────────────────────────────

def build_scan_targets() -> SparkDataFrame:
    """Load all tables to scan from the primary keys Excel file."""
    scan_definitions_df = (
        spark.createDataFrame(pd.read_excel(PRIMARY_KEYS_FILE, engine='openpyxl'))
        .select("table_catalog", "table_schema", "table_name", "columns_list")
        .withColumns({
            "sql_snippet": concat_ws(
                " AND ",
                expr("transform(split(columns_list, ',\\\\s*'), x -> concat(x, ' IS NOT NULL'))")
            )
        })
    )

    return scan_definitions_df



# COMMAND ----------

# DBTITLE 1,Scan Helpers
# ─── Parallel Table Scanner ──────────────────────────────────────────────────────

def classify_error(error_message: str) -> str:
    """Categorize scan errors by type."""
    message = error_message.lower()
    if "table or view not found" in message or "not found" in message:
        return "TABLE_NOT_FOUND"
    if "permission" in message or "not authorized" in message or "insufficient privileges" in message:
        return "PERMISSION_DENIED"
    if any(token in message for token in ["timeout", "tempor", "connection", "reset", "closed channel", "unavailable"]):
        return "TRANSIENT"
    return "UNKNOWN"


def scan_table(row: Row) -> pd.DataFrame:
    """Run completeness + uniqueness scan on a single table."""
    cols_list = row.columns_list
    sql_snippet = row.sql_snippet
    tbl = row.table_name
    schma = row.table_schema
    combined_query = f"""
    WITH metrics AS (
      SELECT
        COUNT(*) AS total_rows,
        SUM(CASE WHEN {sql_snippet} THEN 1 ELSE 0 END) AS completeness_passed,
        COUNT(DISTINCT CONCAT_WS(',', {cols_list})) AS uniqueness_passed
      FROM {SOURCE_CATALOG}.{schma}.{tbl}
    )
    SELECT
      dim.dimension,
      CASE dim.dimension
        WHEN 'Completeness' THEN 'must contain non null value'
        WHEN 'Uniqueness' THEN 'must contain unique value'
      END AS data_quality_rule,
      '{tbl}' AS asset_name,
      '{cols_list}' AS column_name,
      m.total_rows,
      CASE dim.dimension
        WHEN 'Completeness' THEN m.completeness_passed
        WHEN 'Uniqueness' THEN m.uniqueness_passed
      END AS passed_rows,
      CASE dim.dimension
        WHEN 'Completeness' THEN m.total_rows - m.completeness_passed
        WHEN 'Uniqueness' THEN m.total_rows - m.uniqueness_passed
      END AS failed_rows,
      '{SOURCE_CATALOG}.{schma}.{tbl}' AS file_location
    FROM metrics m
    CROSS JOIN (
      SELECT 'Completeness' AS dimension
      UNION ALL
      SELECT 'Uniqueness'
    ) dim
    """
    return spark.sql(combined_query).toPandas()


def run_parallel_scan(scan_target_rows: list) -> tuple[list[pd.DataFrame], list[dict]]:
    """Execute scans in parallel, return results and errors."""
    scan_result_batches = []
    scan_error_records = []

    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        futures = {executor.submit(scan_table, row): row for row in scan_target_rows}
        for future in as_completed(futures):
            row = futures[future]
            try:
                table_scan_result_pd = future.result()
                scan_result_batches.append(table_scan_result_pd)
            except Exception as e:
                error_message = str(e)
                scan_error_records.append({
                    "scan_date": scan_date,
                    "table_schema": row.table_schema,
                    "table_name": row.table_name,
                    "error_type": classify_error(error_message),
                    "error_message": error_message,
                    "traceback": traceback.format_exc(),
                })

    return scan_result_batches, scan_error_records

# COMMAND ----------

# DBTITLE 1,Result Helpers
# ─── Process Results ─────────────────────────────────────────────────────────────

def handle_errors(scan_error_records: list[dict]) -> SparkDataFrame:
    """Capture scan errors in a DataFrame and display them. Returns an empty DataFrame if none."""
    if not scan_error_records:
        print("No scan errors encountered.")
        return spark.createDataFrame(
            [],
            "scan_date string, table_schema string, table_name string, error_type string, error_message string, traceback string"
        )

    scan_errors_df = spark.createDataFrame(scan_error_records)
    print(f"{len(scan_error_records)} scan error(s) encountered:")
    display(scan_errors_df)
    return scan_errors_df


def build_scan_metrics_df(scan_result_batches: list[pd.DataFrame]) -> SparkDataFrame:
    """Combine scan results into a single DataFrame."""
    if scan_result_batches:
        all_scan_results_pd = pd.concat(scan_result_batches, ignore_index=True)
        print(f"Total records collected: {len(all_scan_results_pd)}")
        return spark.createDataFrame(all_scan_results_pd)
    else:
        print("No results collected.")
        return spark.createDataFrame(
            [],
            "dimension string, data_quality_rule string, asset_name string, column_name string, total_rows long, passed_rows long, failed_rows long, file_location string"
        )


def score_results(scan_metrics_df: SparkDataFrame) -> SparkDataFrame:
    """Add score, threshold, and priority columns."""
    return (
        scan_metrics_df
        .withColumns({
            "scan_date": lit(scan_date),
            "score": when(col("total_rows") > 0, col("passed_rows") / col("total_rows")).otherwise(lit(None).cast("double")),
            "threshold": lit(1.0),
        })
        .withColumns({
            "priority": (
                when((col("score") < 0.5) | (col("score") < col("threshold")), lit("High"))
                .when((col("score") < 0.75) | (col("score") > col("threshold")), lit("Low"))
                .otherwise(lit("Medium"))
            )
        })
    )


# Columns to pull from the metadata file — extend this list as needed.
# Keeping it explicit prevents column name collisions with scan result columns.
_METADATA_COLS = ["schema", "data_owner", "business_unit", "data_domain", "source_system", "rule_owner"]


def enrich_with_metadata(scored_results_df: SparkDataFrame) -> SparkDataFrame:
    """Join metadata and add static business columns."""
    # Read columns from pandas first (avoids an Analyze RPC on the Spark DataFrame).
    raw_metadata_pd = pd.read_excel(PRIMARY_KEYS_METADATA_FILE, engine='openpyxl')
    available_cols = [c for c in _METADATA_COLS if c in raw_metadata_pd.columns]
    metadata_df = (
        spark.createDataFrame(raw_metadata_pd)
        .select(available_cols)
        .dropDuplicates(["schema"])
    )

    metadata_enriched_df = (
        scored_results_df
        .withColumns({
            "schema_extracted": regexp_extract(col("file_location"), f'{SOURCE_CATALOG}\\.([^.]+)\\.', 1)
        })
        .join(
            metadata_df,
            col("schema_extracted") == col("schema"),
            "left"
        )
        .drop("schema", "schema_extracted")
    )
    return metadata_enriched_df.withColumns({
        "company": lit("JohnHancock"),
        "segment": lit("US"),
        "workstream": lit("primary keys"),
        "file_type": lit("delta"),
        "rule_status": lit("active"),
        "platform": lit("Databricks"),
    })


def upsert_to_blotter(output_results_df: SparkDataFrame) -> None:
    """Create blotter table if needed and upsert results."""
    spark.sql(f"""
    CREATE TABLE IF NOT EXISTS {OUTPUT_CATALOG}.data_quality.primary_keys_blotter (
        scan_date STRING, company STRING, segment STRING, data_owner STRING,
        business_unit STRING, data_domain STRING, workstream STRING, source_system STRING,
        asset_name STRING, column_name STRING, dimension STRING, data_quality_rule STRING,
        total_rows LONG, passed_rows LONG, failed_rows LONG, score DOUBLE, threshold DOUBLE,
        priority STRING, file_location STRING, file_type STRING, rule_status STRING,
        rule_owner STRING, platform STRING
    ) USING DELTA
    """)

    if DRY_RUN:
        print("[DRY_RUN] Skipped upsert into blotter. Displaying results only.")
    else:
        delta_tbl = DeltaTable.forName(spark, f"{OUTPUT_CATALOG}.data_quality.primary_keys_blotter")
        (
            delta_tbl.alias("t")
            .merge(
                output_results_df.alias("s"),
                """
                t.scan_date = s.scan_date AND
                t.dimension = s.dimension AND
                t.asset_name = s.asset_name AND
                t.column_name = s.column_name AND
                t.file_location = s.file_location
                """
            )
            .whenMatchedUpdateAll()
            .whenNotMatchedInsertAll()
            .execute()
        )
        print("Results upserted into blotter.")
        
    ordered_columns = [
        "scan_date", "company", "segment", "data_owner", "business_unit", "data_domain", "workstream",
        "source_system", "asset_name", "column_name", "dimension", "data_quality_rule", "total_rows",
        "passed_rows", "failed_rows", "score", "threshold", "priority", "file_location", "file_type",
        "rule_status", "rule_owner", "platform"
    ]
    display(output_results_df.select(*ordered_columns))

# COMMAND ----------

# DBTITLE 1,Main Execution
# ═══════════════════════════════════════════════════════════════════════════════════
#  MAIN EXECUTION
# ═══════════════════════════════════════════════════════════════════════════════════

scan_targets_df = build_scan_targets()
scan_count = scan_targets_df.count()
print(f"Selected {scan_count} table(s) to scan.")

scan_target_rows = scan_targets_df.collect()
scan_result_batches, scan_error_records = run_parallel_scan(scan_target_rows)

total = len(scan_target_rows)
print(f"\nCompleted {total - len(scan_error_records)}/{total} tables successfully. {len(scan_error_records)} error(s).")

scan_errors_df = handle_errors(scan_error_records)

scan_metrics_df = build_scan_metrics_df(scan_result_batches)
scored_results_df = score_results(scan_metrics_df)
output_results_df = enrich_with_metadata(scored_results_df)
upsert_to_blotter(output_results_df)

# ─── Fail the job AFTER blotter write so the successful results are persisted ──
if scan_error_records:
    failed_tables = ", ".join(
        f"{r['table_schema']}.{r['table_name']} ({r['error_type']})"
        for r in scan_error_records
    )
    raise RuntimeError(
        f"{len(scan_error_records)} table scan error(s) on {scan_date}. "
        f"Successful results have been written to the blotter. "
        f"Failed tables: {failed_tables}"
    )