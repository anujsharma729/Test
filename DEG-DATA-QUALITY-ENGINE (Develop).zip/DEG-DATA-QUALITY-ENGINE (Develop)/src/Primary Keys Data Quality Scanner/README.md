# Primary Keys Data Quality Scanner

Scans Unity Catalog Delta tables for primary key quality and promotes the results into the central DQ summary table. The scanner measures two dimensions — **Completeness** and **Uniqueness** — for each registered set of primary key columns, scores every rule, and persists the output through a two-stage pipeline: a raw blotter table, then the shared `dq_summary` table.

---

## Notebooks

### 1. `Primary Keys Data Quality Scanner`

The main scan runner. Reads a registry of tables and their primary key columns, executes SQL-based quality checks against each table in parallel, scores the results, enriches them with schema-level metadata, and upserts the output into the blotter table.

**Stages:**

| Stage | What it does |
| --- | --- |
| Build scan targets | Reads `primary_keys.xlsx` and derives a `sql_snippet` (IS NOT NULL predicates) for each row |
| Parallel scan | Runs Completeness + Uniqueness checks across all registered tables concurrently (up to 32 threads) |
| Error handling | Classifies failures as `TABLE_NOT_FOUND`, `PERMISSION_DENIED`, `TRANSIENT`, or `UNKNOWN`; surfaces them without aborting the run |
| Scoring | `score = passed_rows / total_rows`; threshold fixed at `1.0`; priority assigned as High / Medium / Low |
| Metadata enrichment | Left-joins `primary_keys_metadata.xlsx` on schema name to attach `data_owner`, `business_unit`, `data_domain`, `source_system`, `rule_owner`; adds static columns (`company`, `segment`, `workstream`, `file_type`, `rule_status`, `platform`) |
| Upsert to blotter | MERGE into `primary_keys_blotter` on `scan_date + dimension + asset_name + column_name + file_location`; creates the table if it does not yet exist |

**Priority thresholds:**

| Priority | Condition |
| --- | --- |
| High | `score < 0.5` or `score < threshold` |
| Low | `score < 0.75` or `score > threshold` |
| Medium | All other cases |

**Widget:**

| Widget | Default | Effect |
| --- | --- | --- |
| `DRY_RUN` | `false` | When `true`, skips the blotter upsert and displays results only |

---

### 2. `Primary Keys Blotter Transfer`

A monthly promotion job. Reads the current calendar month's records from the blotter, selects the most recent complete row per rule identity, and atomically MERGEs them into the central `dq_summary` table.

**Stages:**

| Stage | What it does |
| --- | --- |
| Read blotter | Loads all blotter rows whose `scan_date` falls in the current calendar month |
| Filter complete rows | Drops any rows with a NULL in any of the 23 required columns |
| Deduplicate | Keeps the single latest `scan_date` per rule identity (`asset_name`, `column_name`, `dimension`, `data_quality_rule`) |
| Atomic MERGE | Upserts into `dq_summary` — matched on the 4-column rule identity key and current-month `scan_date`; rows outside the current month or for unrelated workstreams are left untouched |
| Verification | Counts and displays the primary-keys rows now present in `dq_summary` for the current month |

**Widget:**

| Widget | Default | Effect |
| --- | --- | --- |
| `DRY_RUN` | `true` | When `true`, previews what the MERGE would update/insert without writing |

---

## Configuration Files

Both files live in the Unity Catalog Volume at:

```
/Volumes/usdo_uat_catalog/data_quality/primary_keys_scanner/
```

### `primary_keys.xlsx`

Registry of tables to scan. One row per table.

| Column | Description |
| --- | --- |
| `table_catalog` | Unity Catalog catalog name |
| `table_schema` | Schema name |
| `table_name` | Table name |
| `columns_list` | Comma-separated list of primary key columns to check |

### `primary_keys_metadata.xlsx`

Schema-level metadata joined onto scan results.

| Column | Description |
| --- | --- |
| `schema` | Join key — must match the schema of the scanned table |
| `data_owner` | Data owner name |
| `business_unit` | Business unit |
| `data_domain` | Data domain |
| `source_system` | Source system name |
| `rule_owner` | Owner of the DQ rule |

---

## Tables

| Table | Catalog | Role |
| --- | --- | --- |
| *(scan targets)* | `usdo_prod_catalog` | Source tables being scanned |
| `data_quality.primary_keys_score_blotter` | `usdo_uat_catalog` | Raw scan results; created automatically on first run |
| `data_quality.dq_summary` | `usdo_uat_catalog` | Central DQ summary table; populated by the Blotter Transfer notebook |

---

## Dependencies

- `openpyxl` — required to read `.xlsx` config files; installed via `%pip install openpyxl` in the first cell of the scanner notebook.

---

## Typical Run Order

1. Run **`Primary Keys Data Quality Scanner`** (daily or on demand) to populate the blotter with fresh scan results.
2. Run **`Primary Keys Blotter Transfer`** (monthly, or after the scan completes) to promote the latest complete scores into `dq_summary`.

Both notebooks default to a safe mode (`DRY_RUN`) that can be used to preview output before committing writes.
