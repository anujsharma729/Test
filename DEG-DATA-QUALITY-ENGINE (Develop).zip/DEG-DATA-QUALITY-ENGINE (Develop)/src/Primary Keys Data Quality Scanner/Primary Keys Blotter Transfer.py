# Databricks notebook source
# DBTITLE 1,Setup & Date Logic
from datetime import date, timedelta
import calendar

# Determine current month boundaries
today = date.today()
month_start = today.replace(day=1)
month_end = today.replace(day=calendar.monthrange(today.year, today.month)[1])

MONTH_START_STR = month_start.strftime("%Y-%m-%d")
MONTH_END_STR = month_end.strftime("%Y-%m-%d")

# Automatically select the catalog based on the workspace.
# adb-2496084869070462.2.azuredatabricks.net is the production workspace.
_PROD_WORKSPACE = "adb-2496084869070462.2.azuredatabricks.net"
_workspace_url = spark.conf.get("spark.databricks.workspaceUrl", "")
_catalog = "usdo_prod_catalog" if _PROD_WORKSPACE in _workspace_url else "usdo_uat_catalog"

# Table references
BLOTTER_TABLE = f"{_catalog}.data_quality.primary_keys_blotter"
SUMMARY_TABLE = f"{_catalog}.data_quality.dq_summary"

# Rule identity composite key
RULE_KEY_COLS = ["asset_name", "column_name", "dimension", "data_quality_rule"]

# All 23 columns that must be non-NULL for a row to be considered complete
ALL_COLUMNS = [
    "scan_date", "company", "segment", "data_owner", "business_unit",
    "data_domain", "workstream", "source_system", "asset_name", "column_name",
    "dimension", "data_quality_rule", "total_rows", "passed_rows", "failed_rows",
    "score", "threshold", "priority", "file_location", "file_type",
    "rule_status", "rule_owner", "platform"
]

# Widget
dbutils.widgets.dropdown("DRY_RUN", "true", ["true", "false"])
DRY_RUN = dbutils.widgets.get("DRY_RUN") == "true"

print(f"Current month window: {MONTH_START_STR} to {MONTH_END_STR}")
print(f"Blotter source: {BLOTTER_TABLE}")
print(f"Summary target: {SUMMARY_TABLE}")
print(f"DRY_RUN: {DRY_RUN}")
if DRY_RUN:
    print("⚠️  DRY RUN — no writes will be performed")

# COMMAND ----------

# DBTITLE 1,Read & Filter Blotter
from pyspark.sql import functions as F
from pyspark.sql.window import Window

# Step 1: Read blotter rows within the current month
blotter_df = (
    spark.table(BLOTTER_TABLE)
    .filter(
        (F.col("scan_date") >= MONTH_START_STR) &
        (F.col("scan_date") <= MONTH_END_STR)
    )
)

print(f"Blotter rows in current month: {blotter_df.count()}")

# Step 2: Filter to only COMPLETE rows (all 23 columns non-NULL)
complete_df = blotter_df.dropna(subset=ALL_COLUMNS)

print(f"Complete rows (no NULLs): {complete_df.count()}")

# Step 3: For each rule identity, keep only the row with the LATEST scan_date
window_spec = Window.partitionBy(*RULE_KEY_COLS).orderBy(F.col("scan_date").desc())

latest_df = (
    complete_df
    .withColumn("_row_num", F.row_number().over(window_spec))
    .filter(F.col("_row_num") == 1)
    .drop("_row_num")
)

rows_to_transfer = latest_df.count()
print(f"Latest complete rows to transfer (one per rule identity): {rows_to_transfer}")

# Register as the MERGE source (used in the next cell)
latest_df.createOrReplaceTempView("latest_blotter_scores")

display(latest_df.limit(10))

# COMMAND ----------

# DBTITLE 1,Delete Stale Records from Summary
# Atomically merge the latest blotter scores into dq_summary.
# MERGE is a single Delta transaction — if anything fails mid-operation
# the entire statement rolls back. This eliminates the DELETE/INSERT gap
# that could leave dq_summary rows missing if the insert step had failed.
#
# Match condition: same 4-column rule identity key AND target scan_date
# within the current month. Rows in dq_summary from earlier months, or
# for rule identities not present in the blotter, are left untouched.
#
# Assumption: dq_summary has at most one row per rule identity per month.
# If duplicates exist, MERGE will raise a non-deterministic match error.

merge_sql = f"""
    MERGE INTO {SUMMARY_TABLE} AS target
    USING latest_blotter_scores AS source
    ON  target.asset_name        = source.asset_name
    AND target.column_name       = source.column_name
    AND target.dimension         = source.dimension
    AND target.data_quality_rule = source.data_quality_rule
    AND target.scan_date >= '{MONTH_START_STR}'
    AND target.scan_date <= '{MONTH_END_STR}'
    WHEN MATCHED     THEN UPDATE SET *
    WHEN NOT MATCHED THEN INSERT *
"""

if DRY_RUN:
    # Show what WOULD be updated vs inserted, without executing
    matched_df = spark.sql(f"""
        SELECT target.*
        FROM {SUMMARY_TABLE} AS target
        INNER JOIN latest_blotter_scores AS source
          ON  target.asset_name        = source.asset_name
          AND target.column_name       = source.column_name
          AND target.dimension         = source.dimension
          AND target.data_quality_rule = source.data_quality_rule
          AND target.scan_date >= '{MONTH_START_STR}'
          AND target.scan_date <= '{MONTH_END_STR}'
    """)
    insert_df = spark.sql(f"""
        SELECT source.*
        FROM latest_blotter_scores AS source
        WHERE NOT EXISTS (
            SELECT 1 FROM {SUMMARY_TABLE} AS target
            WHERE target.asset_name        = source.asset_name
              AND target.column_name       = source.column_name
              AND target.dimension         = source.dimension
              AND target.data_quality_rule = source.data_quality_rule
              AND target.scan_date >= '{MONTH_START_STR}'
              AND target.scan_date <= '{MONTH_END_STR}'
        )
    """)
    rows_updated = matched_df.count()
    rows_inserted = insert_df.count()
    print(f"⚠️  DRY RUN — MERGE would:")
    print(f"    UPDATE {rows_updated} existing row(s) in {SUMMARY_TABLE}")
    print(f"    INSERT {rows_inserted} new row(s) into {SUMMARY_TABLE}")
    print("\nCurrent summary rows that WOULD BE UPDATED:")
    display(matched_df.limit(10))
    print("\nBlotter rows that WOULD BE INSERTED (no existing match in summary):")
    display(insert_df.limit(10))
else:
    merge_result = spark.sql(merge_sql)
    stats = merge_result.first()
    rows_updated = stats["num_updated_rows"]
    rows_inserted = stats["num_inserted_rows"]
    print(f"MERGE complete (atomic — fully committed or fully rolled back):")
    print(f"  Updated : {rows_updated} row(s)")
    print(f"  Inserted: {rows_inserted} row(s)")

# COMMAND ----------

# DBTITLE 1,Transfer Summary
# Final summary of the transfer operation
print("=" * 60)
print("MONTHLY DQ SCORE TRANSFER COMPLETE" + (" (DRY RUN)" if DRY_RUN else ""))
print("=" * 60)
print(f"Month:              {today.strftime('%B %Y')}")
print(f"Window:             {MONTH_START_STR} to {MONTH_END_STR}")
print(f"Blotter rows read:  {blotter_df.count()}")
print(f"Complete rows:      {complete_df.count()}")
print(f"Rules to transfer:  {rows_to_transfer}")
print(f"Rows updated:       {rows_updated}" + (" (would update)" if DRY_RUN else ""))
print(f"Rows inserted:      {rows_inserted}" + (" (would insert)" if DRY_RUN else ""))
print("=" * 60)

# Verify: show current month's records now in dq_summary for this workstream
verify_df = (
    spark.table(SUMMARY_TABLE)
    .filter(
        (F.col("scan_date") >= MONTH_START_STR) &
        (F.col("scan_date") <= MONTH_END_STR) &
        (F.col("workstream") == "primary keys")
    )
)
print(f"\nVerification: {verify_df.count()} primary keys rows now in dq_summary for {today.strftime('%B %Y')}")