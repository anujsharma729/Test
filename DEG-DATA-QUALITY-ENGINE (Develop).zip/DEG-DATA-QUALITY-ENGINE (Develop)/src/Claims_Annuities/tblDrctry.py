# Databricks notebook source
# MAGIC %run ../utils

# COMMAND ----------

# MAGIC %run ../rules

# COMMAND ----------

config['asset_name'] = 'tblDrctry'
config['data_system'] = 'vtgods'
config['data_owner'] = 'Chad Edwards'
config['business_unit'] = 'Annuities'
config['data_domain'] = 'Claims'
config['rule_owner'] = 'Wendy Merrifield'
config['work_stream'] = 'claims annuities'

tblroles_df = uc_read('silver_vtgods', 'tblRoles')
tblplcy_df = uc_read('silver_vtgods', 'tblPlcy')
main_df = uc_read('silver_vtgods', 'tbldrctry')

# COMMAND ----------

value_list = ['A', 'E', '3','5','6']
tblplcy_df = tblplcy_df.filter(tblplcy_df['PlcyStat'].isin(value_list))

temp_df = tblroles_df.join(tblplcy_df,(tblroles_df["CoCd"] == tblplcy_df["CoCd"]) & (tblplcy_df["Plcynum"] == tblroles_df["Plcynum"]) , "inner").select(tblroles_df["CoCd"],tblroles_df["DrctryId"],tblroles_df["RoleCd"],tblplcy_df["Plcynum"])

df = main_df.join(temp_df,(main_df["CoCd"] == temp_df["CoCd"]) & (main_df["DrctryId"] == temp_df["DrctryId"]), "inner").select(main_df["*"],temp_df["Plcynum"]).distinct()

df = df.drop("count","dictionary_count","policy_count").distinct()
df = trim(df)

windowSpec = Window.partitionBy('SocSecNum')
df = df.withColumn("count", count("SocSecNum").over(windowSpec))

# COMMAND ----------

   
#COMPLETENESS
for column in ['SocSecNum','BirthDt','AddrLine1']:
    df = completeness_check(df, column)

df = completeness_with_dependency(df, 'FrstNm','CoIndivCd','I')
df = completeness_with_dependency(df, 'LastNm','CoIndivCd','I')
df = completeness_with_dependency(df, 'City','CntryCd','US')
df = completeness_with_dependency(df, 'State','CntryCd','US')
df = completeness_with_dependency(df, 'ZipPostalCd','CntryCd','US')
df = completeness_with_list_dependency(df, 'CntryCd', 'State', US_STATES)


#Uniqueness
####################### Conditions for SSN ##################################
df_condition = df.filter(lower(col("CoNm")).contains("trust") | lower(col("CoNm")).contains("trst") | col("CoNm").contains(" TR") ) 
ssn_list = [row.SocSecNum for row in df_condition.select("SocSecNum").distinct().collect()]
df_grouped = df.groupBy("CoNm","SocSecNum").agg(count("*").alias("countssn"))
df_duplicates = df_grouped.filter((col("countssn")>1) & (col("CoNm").isNotNull())).distinct()
ssn_list1 = [row.SocSecNum for row in df_duplicates.select("SocSecNum").distinct().collect()]
df_grouped1 = df.groupBy(f.regexp_replace("FrstNm","\\.",""),f.regexp_replace("LastNm","\\.",""),"BirthDt","AddrLine1","SocSecNum").agg(count("*").alias("countname"))
df_duplicates1 = df_grouped1.filter((col("countname")>1) & (col("SocSecNum").isNotNull())).distinct()
ssn_list2 = [row.SocSecNum for row in df_duplicates1.select("SocSecNum").distinct().collect()]
#################################################################################

df = df.withColumn('Uniqueness: SocSecNum', f.when(col('SocSecNum').isNull(),'fail: must contain unique value')  
.when((col("SocSecNum").isin(ssn_list1)), 'pass: must contain unique value')  
.when((col("SocSecNum").isin(ssn_list2)), 'pass: must contain unique value')    
.when((col('count') > 1) & (col("SocSecNum").isin(ssn_list)), 'pass: must contain unique value')             
.when((col('SocSecNum').isin('999999999','999-99-9999')) & (df['CoIndivCd'] == 'C') & (col('count') >= 1), 'pass: must contain unique value')  
.when((col('count') == 1), 'pass: must contain unique value') 
.otherwise('fail: must contain unique value'))

#CONFORMITY
df = conformity_name(df, 'FrstNm')
df = conformity_name(df, 'LastNm')
df = conformity_addr1(df, 'AddrLine1')
df = conformity_postalcode_us(df, 'ZipPostalCd')
df = conformity_ssn(df, 'SocSecNum')

#Accuracy
df = accuracy_birthdate(df, 'BirthDt')
df = accuracy_state_us(df, 'State')

# COMMAND ----------

summary = get_summary(df)
uc_write(summary)

# COMMAND ----------

