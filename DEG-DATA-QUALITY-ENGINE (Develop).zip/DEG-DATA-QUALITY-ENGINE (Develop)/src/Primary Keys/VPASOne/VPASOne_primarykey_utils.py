# Databricks notebook source
# MAGIC %run ../../utils

# COMMAND ----------

def syn_read_asset(schema_name, table_name):
    synapse_table = f"{schema_name}.{table_name}"
    df = spark.read.jdbc(url=jdbcUrl, table=synapse_table)
    return df

# COMMAND ----------

def save_parquet_results(failed_rows_df, summary_df, asset_name, work_stream, data_system,**kwargs): # NOSONAR
    if failed_rows_df is not None:
        failed_rows_df.write.parquet(f"abfss://dataquality@{ENV['storage_account']}.dfs.core.windows.net/{work_stream}/{data_system}/{asset_name}/{TIMESTAMP}/failed_rows")
    if summary_df is not None:
        summary_df.write.parquet(f"abfss://dataquality@{ENV['storage_account']}.dfs.core.windows.net/{work_stream}/{data_system}/{asset_name}/{TIMESTAMP}/scan_summary")

# COMMAND ----------

def value_counts(df, column):
    value_counts_df = df.groupBy(column).count().orderBy(f.col("Count").desc(),f.asc(column))
    display(value_counts_df)
    return value_counts_df

# COMMAND ----------

from functools import reduce
def filter_condition(asset_filter):
    filter_conditions = []
    for col_name, condition in asset_filter.items():
        if condition.startswith('=='):
            filter_conditions.append(f.col(col_name) == condition[2:])
        elif condition.startswith('!='):
            filter_conditions.append(f.col(col_name) != condition[2:])
        elif condition.startswith('>'):
            filter_conditions.append(f.col(col_name) > condition[1:])
        elif condition.startswith('<'):
            filter_conditions.append(f.col(col_name) < condition[1:])
        elif condition.startswith('>='):
            filter_conditions.append(f.col(col_name) >= condition[2:]) 
        elif condition.startswith('<='):
            filter_conditions.append(f.col(col_name) <= condition[2:])
        elif condition.startswith('isin'):
            filter_conditions.append(f.col(col_name).isin(condition[4:].split(',')))
        elif condition.startswith('notin'):
            filter_conditions.append(~f.col(col_name).isin(condition[5:].split(',')))
        elif condition.startswith('startswith'):
            filter_conditions.append(f.col(col_name).startswith(condition[10:]))
    filter_conditions =  reduce(lambda x,y: x & y, filter_conditions)
    return filter_conditions


# COMMAND ----------

def trim(df):
    for column in df.columns:
        df = df.withColumn(column, f.ltrim(f.rtrim(df[column])))
    return df
    
def clean(df, columns=None):
    df = trim(df)
    if columns == None: columns = df.columns
    for column in columns:
        df = df.withColumn(column, f.when(f.col(column) == '\0', None)
            .when(f.col(column) == '', None)
            .when(f.initcap(f.col(column)) == 'Null', None)
            .when(f.initcap(f.col(column)) == 'Unknown', None)
            .when(f.initcap(f.col(column)) == 'Na', None)
            .when(f.initcap(f.col(column)) == 'N/a', None)
            # .when(f.col(column).rlike(r"^0+$"), None)
            .otherwise(f.col(column)))
    return df

# COMMAND ----------

def uniqueness_check(df,column):
    if isinstance(column, str):
        df = df.withColumn(f"Uniqueness: {column}"
                        ,f.when(f.count("*").over(Window.partitionBy(column)) == 1, 'pass: Must Contain Unique Value')
                        .otherwise('fail: Must Contain Unique Value'))
    elif isinstance(column, list):
        column_list = column
        selected_columns = [df[column_name] for column_name in column_list]
        df = df.withColumn('TEMPORARY_COLUMN', f.concat_ws("", *selected_columns))
        df = df.withColumn(f"Uniqueness: {', '.join(column_list)}"
                    ,f.when(f.count("*").over(Window.partitionBy('TEMPORARY_COLUMN')) == 1, 'pass: Must Contain Unique Row')
                    .otherwise('fail: Must Contain Unique Row'))
        df = df.drop('TEMPORARY_COLUMN')
    else:
        raise ValueError('Uniqueness check requires a column or list of columns')
    return df

# COMMAND ----------

def completeness_check(df,column, optional_falsies=None):
    if isinstance(column, str):
        df = df.withColumn(f'Completeness: {column}', f.when(~(df[column].isNull()), 'pass: Must Contain Non Null Value').otherwise('fail: Must Contain Non Null Value'))
    
    if isinstance(column, list):
        col_name = ' | '.join(column)
        df = df.withColumn(f'Completeness: {col_name}', f.when(f.coalesce(*[f.col(c) for c in column]).isNotNull(), 'pass: Must Contain Non Null Value').otherwise('fail: Must Contain Non Null Value'))

    if isinstance(optional_falsies, list):
        for falsy_value in optional_falsies:
            df = df.withColumn(f'Completeness: {column}', f.when((df[column] == falsy_value), 'fail: Must Contain Non Null Value').otherwise(df[f'Completeness: {column}']))
    elif optional_falsies != None:
        df = df.withColumn(f'Completeness: {column}', f.when((df[column] == optional_falsies), 'fail: Must Contain Non Null Value').otherwise(df[f'Completeness: {column}']))
    return df

# COMMAND ----------

def apply_dq_rules(assets, **config):
    summary_df = None
    for asset in assets:
        config['asset_name'] = asset['tablename']
        if asset["tbl_primarykey"] is None: continue
        try:
            df = read_asset_delta(**config)
            total_row_count = df.count()
            if 'filter' in asset:
                df_filters = filter_condition(asset['filter'])
                df = df.filter(df_filters)
            df = df.select(*asset['tbl_primarykey'].split(","))

            print(config['asset_name'], ": ", (str(df.count()) + " / " + str(total_row_count) + " (filtered)") if 'filter' in asset else total_row_count)

            df = clean(df)

            if "," in asset['tbl_primarykey']: 
                asset['tbl_primarykey'] = asset['tbl_primarykey'].split(",")
                if 'completeness_coalesce' in asset:
                    all_coalesce_cols = [col for sublist in asset['completeness_coalesce'] for col in sublist]
                    column_list = asset['completeness_coalesce'] + [i for i in asset['tbl_primarykey'] if i not in set(all_coalesce_cols)]
                    for value in column_list:
                        df = completeness_check(df, value)
                else:
                    for value in asset['tbl_primarykey']:
                        df = completeness_check(df, value)
            else:
                df = completeness_check(df, asset['tbl_primarykey'])

            df = uniqueness_check(df, asset['tbl_primarykey'])
            summary = get_summary(df,None, **config)

            # if summary.filter(summary['Rows Failed'] > 0).count() > 0:
            #     print("Contains Failed Rows")
            #     df = df.select(asset['tbl_primarykey'])
            #     failed_rows = get_failed_rows(df)
            #     save_parquet_results(failed_rows, None, **config)

            if summary_df is None: summary_df = summary
            else: summary_df = summary_df.union(summary)
        except Exception as e:
            print('Could Not Load: ', config['asset_name'])
    summary_df = summary_df.withColumn('Thresholds', f.lit('1'))
    return summary_df

# COMMAND ----------

def get_failed_rows(df):
    data_quality_columns = [column for column in df.columns if column.startswith(('Completeness:','Uniqueness:','Conformity:','Consistency:','Accuracy:'))]
    condition_expr = ".contains('fail') | ".join([f"df['{column}']" for column in data_quality_columns]) + ".contains('fail')"
    failed_rows_df = df.filter(eval(condition_expr))
    return failed_rows_df

# COMMAND ----------

def print_dataframe_as_dict(spark_df):
    # Collect the DataFrame rows to the driver
    rows = spark_df.collect()
    
    # Convert rows to dictionary
    rows_as_dict = [row.asDict() for row in rows]
    
    # Print the dictionary
    for value in rows_as_dict:
        print(value)

# print_dataframe_as_dict(t)
