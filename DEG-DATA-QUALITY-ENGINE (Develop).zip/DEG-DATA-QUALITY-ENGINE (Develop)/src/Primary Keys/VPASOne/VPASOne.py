# Databricks notebook source
# MAGIC %run ../../utils

# COMMAND ----------

# MAGIC %run ./VPASOne_primarykey_utils

# COMMAND ----------

assets = [
{'Source': 'VPASOne', 'tablename': 'DSACHReqHistory', 'tbl_primarykey': 'prrowid', 'filter': {'IsDeleted': '==N'}},
{'Source': 'VPASOne', 'tablename': 'DSAdmRule', 'tbl_primarykey': 'prrowid', 'filter': {'IsDeleted': '==N'}},
{'Source': 'VPASOne', 'tablename': 'DSAnnPolicyTradCV', 'tbl_primarykey': 'PolicyNumber,CoverageID,CashValType', 'filter': {'IsDeleted': '==N'}},
{'Source': 'VPASOne', 'tablename': 'DSAnnPolicyValue', 'tbl_primarykey': 'PolicyNumber', 'filter': {'IsDeleted': '==N'}},
{'Source': 'VPASOne', 'tablename': 'DSAnnQuoteDetailValue', 'tbl_primarykey': 'PolicyNumber,GroupType,DetailType', 'filter': {'IsDeleted': '==N'}},
{'Source': 'VPASOne', 'tablename': 'DSBillSchedule', 'tbl_primarykey': 'prrowid', 'filter': {'IsDeleted': '==N'}},
{'Source': 'VPASOne', 'tablename': 'DSCase', 'tbl_primarykey': 'prrowid', 'filter': {'IsDeleted': '==N'}},
{'Source': 'VPASOne', 'tablename': 'DSCeOthPremHst', 'tbl_primarykey': 'prrowid', 'filter': {'IsDeleted': '==N'}},
{'Source': 'VPASOne', 'tablename': 'DSCommAlloc', 'tbl_primarykey': 'prrowid', 'filter': {'IsDeleted': '==N'}},
{'Source': 'VPASOne', 'tablename': 'DSCompliance', 'tbl_primarykey': 'prrowid', 'filter': {'IsDeleted': '==N'}},
{'Source': 'VPASOne', 'tablename': 'DSContactName', 'tbl_primarykey': 'prrowid', 'filter': {'IsDeleted': '==N'}},
{'Source': 'VPASOne', 'tablename': 'DSCoverage', 'tbl_primarykey': 'prrowid', 'filter': {'IsDeleted': '==N'}},
{'Source': 'VPASOne', 'tablename': 'DSCoverageDtl', 'tbl_primarykey': 'prrowid', 'filter': {'IsDeleted': '==N'}},
{'Source': 'VPASOne', 'tablename': 'DSCoverageFlatExtra', 'tbl_primarykey': 'prrowid', 'filter': {'IsDeleted': '==N'}},
{'Source': 'VPASOne', 'tablename': 'DSCoverageHst', 'tbl_primarykey': 'prrowid', 'filter': {'IsDeleted': '==N'}},
{'Source': 'VPASOne', 'tablename': 'DSCoverageLayer', 'tbl_primarykey': 'prrowid', 'filter': {'IsDeleted': '==N'}},
{'Source': 'VPASOne', 'tablename': 'DSCoverageLayerDet', 'tbl_primarykey': 'prrowid', 'filter': {'IsDeleted': '==N'}},
{'Source': 'VPASOne', 'tablename': 'DSCoverageLayerTgt', 'tbl_primarykey': 'prrowid', 'filter': {'IsDeleted': '==N'}},
{'Source': 'VPASOne', 'tablename': 'DSCovInsParams', 'tbl_primarykey': 'prrowid', 'filter': {'IsDeleted': '==N'}},
{'Source': 'VPASOne', 'tablename': 'DSCTRORQDtl', 'tbl_primarykey': 'prrowid', 'filter': {'IsDeleted': '==N'}},
{'Source': 'VPASOne', 'tablename': 'DSEventDepAcct', 'tbl_primarykey': 'prrowid', 'filter': {'IsDeleted': '==N'}},
{'Source': 'VPASOne', 'tablename': 'DSEventDetail', 'tbl_primarykey': 'prrowid', 'filter': {'IsDeleted': '==N'}},
{'Source': 'VPASOne', 'tablename': 'DSEventFinAcctDetail', 'tbl_primarykey': 'prrowid', 'filter': {'IsDeleted': '==N'}},
{'Source': 'VPASOne', 'tablename': 'DSEventFinAcctDetExt', 'tbl_primarykey': 'prrowid', 'filter': {'IsDeleted': '==N'}},
{'Source': 'VPASOne', 'tablename': 'DSEventHistory', 'tbl_primarykey': 'prrowid', 'filter': {'IsDeleted': '==N'}},
{'Source': 'VPASOne', 'tablename': 'DSEventHistoryExt', 'tbl_primarykey': 'prrowid', 'filter': {'IsDeleted': '==N'}},
{'Source': 'VPASOne', 'tablename': 'DsEventInfo', 'tbl_primarykey': 'prrowid', 'filter': {'IsDeleted': '==N'}},
{'Source': 'VPASOne', 'tablename': 'DSEventTax', 'tbl_primarykey': 'prrowid', 'filter': {'IsDeleted': '==N'}},
{'Source': 'VPASOne', 'tablename': 'DSIllustrService', 'tbl_primarykey': 'prrowid', 'filter': {'IsDeleted': '==N'}},
{'Source': 'VPASOne', 'tablename': 'DSInvestAlloc', 'tbl_primarykey': 'CaseNumber,PolicyNumber,CaseVersion,FundID,InvestTypeDesc,effdate', 'completeness_coalesce': [['CaseNumber','CaseVersion','PolicyNumber']], 'filter': {'IsDeleted': '==N'}},
{'Source': 'VPASOne', 'tablename': 'DSInvestRule', 'tbl_primarykey': 'prrowid', 'filter': {'IsDeleted': '==N'}},
{'Source': 'VPASOne', 'tablename': 'DSInvoiceMaster', 'tbl_primarykey': 'prrowid', 'filter': {'IsDeleted': '==N'}},
{'Source': 'VPASOne', 'tablename': 'DSLegalAction', 'tbl_primarykey': 'prrowid', 'filter': {'IsDeleted': '==N'}},
{'Source': 'VPASOne', 'tablename': 'DSPIPayDtl', 'tbl_primarykey': 'prrowid', 'filter': {'IsDeleted': '==N'}},
{'Source': 'VPASOne', 'tablename': 'DSPlannedPremium', 'tbl_primarykey': 'prrowid', 'filter': {'IsDeleted': '==N'}},
{'Source': 'VPASOne', 'tablename': 'DSPolicy', 'tbl_primarykey': 'prrowid', 'filter': {'IsDeleted': '==N'}},
{'Source': 'VPASOne', 'tablename': 'DSPolicyBill', 'tbl_primarykey': 'prrowid', 'filter': {'IsDeleted': '==N'}},
{'Source': 'VPASOne', 'tablename': 'DSPolicyBillComp', 'tbl_primarykey': 'prrowid', 'filter': {'IsDeleted': '==N'}},
{'Source': 'VPASOne', 'tablename': 'DSPolicyControlCodes', 'tbl_primarykey': 'prrowid', 'filter': {'IsDeleted': '==N'}},
{'Source': 'VPASOne', 'tablename': 'DSPolicyDAValue', 'tbl_primarykey': 'prrowid', 'filter': {'IsDeleted': '==N'}},
{'Source': 'VPASOne', 'tablename': 'DSPolicyDiv', 'tbl_primarykey': 'prrowid', 'filter': {'IsDeleted': '==N'}},
{'Source': 'VPASOne', 'tablename': 'DSPolicyInvoice', 'tbl_primarykey': 'prrowid', 'filter': {'IsDeleted': '==N'}},
{'Source': 'VPASOne', 'tablename': 'DSPolicyLoan', 'tbl_primarykey': 'prrowid', 'filter': {'IsDeleted': '==N'}},
{'Source': 'VPASOne', 'tablename': 'DSPolicyMiscValue', 'tbl_primarykey': 'PolicyNumber,ValueID,Duration,EffDate', 'filter': {'IsDeleted': '==N'}},
{'Source': 'VPASOne', 'tablename': 'DSPolicyReInvest', 'tbl_primarykey': 'prrowid', 'filter': {'IsDeleted': '==N'}},
{'Source': 'VPASOne', 'tablename': 'DSPolicyTradCV', 'tbl_primarykey': 'prrowid', 'filter': {'IsDeleted': '==N'}},
{'Source': 'VPASOne', 'tablename': 'DSPolicyTradValue', 'tbl_primarykey': 'prrowid', 'filter': {'IsDeleted': '==N'}},
{'Source': 'VPASOne', 'tablename': 'DSPolicyValue', 'tbl_primarykey': 'prrowid', 'filter': {'IsDeleted': '==N'}},
{'Source': 'VPASOne', 'tablename': 'DSPolicyValueDtl', 'tbl_primarykey': 'prrowid', 'filter': {'IsDeleted': '==N'}},
{'Source': 'VPASOne', 'tablename': 'DSPrdFundAvail', 'tbl_primarykey': 'prrowid', 'filter': {'IsDeleted': '==N'}},
{'Source': 'VPASOne', 'tablename': 'DSProduct', 'tbl_primarykey': 'prrowid', 'filter': {'IsDeleted': '==N'}},
{'Source': 'VPASOne', 'tablename': 'DSQuoteDetailValue', 'tbl_primarykey': 'PolicyNumber,CoverageID,GroupType,DetailType,DBCalcSeq', 'filter': {'IsDeleted': '==N'}},
{'Source': 'VPASOne', 'tablename': 'DSSpecGroupPolicy', 'tbl_primarykey': 'prrowid', 'filter': {'IsDeleted': '==N'}},
{'Source': 'VPASOne', 'tablename': 'DSWellnessImportHst', 'tbl_primarykey': 'prrowid', 'filter': {'IsDeleted': '==N'}},
{'Source': 'VPASOne', 'tablename': 'DSWellnessInfo', 'tbl_primarykey': 'PolicyNumber,CoverageID,RelationCode,WellnessInfoSeq,EffDate,WellnessInfoType', 'filter': {'IsDeleted': '==N'}}
]

# COMMAND ----------

config = {
"container": 'silver',
"parent_dir": 'VpasOne',
"asset_name": '',
"work_stream": "PrimaryKeys",
"data_system": "VpasOne"
}

configure_spark()

# COMMAND ----------

summary_df = apply_dq_rules(assets, **config)

# COMMAND ----------

# display(summary_df)

# COMMAND ----------

config['asset_name'] = 'VpasOne'
save_parquet_results(None, summary_df, **config)
