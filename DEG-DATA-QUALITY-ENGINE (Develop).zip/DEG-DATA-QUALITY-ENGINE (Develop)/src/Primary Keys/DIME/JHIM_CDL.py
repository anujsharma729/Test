# Databricks notebook source
# MAGIC
# MAGIC %run ../../utils

# COMMAND ----------

# MAGIC %run ../primarykey_utils

# COMMAND ----------

config['data_domain'] = 'Policy'
config['rule_owner'] = 'Gina Stewart'
config['data_owner'] = 'Amy Miskavitch'
config['business_unit'] = 'Life (US)'

assets = [{'Source': 'jhim_cdl', 'tablename': 'ACTOR', 'tbl_primarykey': 'ACTOR_SEQ_NUM,ROW_START'},
{'Source': 'jhim_cdl', 'tablename': 'EMPLOYEE', 'tbl_primarykey': 'EMPLOYEE_SEQ_NUM,ROW_START'},
{'Source': 'jhim_cdl', 'tablename': 'FIRM', 'tbl_primarykey': 'FIRM_SEQ_NUM,ROW_START'},
{'Source': 'jhim_cdl', 'tablename': 'AGENT_DTL_TT', 'tbl_primarykey': 'AGENT_DTL_TT_SEQ_NUM,ROW_START'},
{'Source': 'jhim_cdl', 'tablename': 'PARTY_IDENTIFIER_TT', 'tbl_primarykey': 'PARTY_IDENTIFIER_TT_SEQ_NUM,ROW_START'},
{'Source': 'jhim_cdl', 'tablename': 'REQUIREMENT', 'tbl_primarykey': 'REQUIREMENT_SEQ_NUM,ROW_START'},
{'Source': 'jhim_cdl', 'tablename': 'ROLE_ADDRESS_USAGE_TT', 'tbl_primarykey': 'ROLE_ADDR_USAGE_TT_SEQ_NUM,ROW_START'},
{'Source': 'jhim_cdl', 'tablename': 'CUSTOMER_ADDL_TT', 'tbl_primarykey': 'CUSTOMER_ADDL_TT_SEQ_NUM,ROW_START'},
{'Source': 'jhim_cdl', 'tablename': 'CASE_REPLACEMENT_TT', 'tbl_primarykey': 'CASE_REPLACEMENT_TT_SEQ_NUM,ROW_START'},
{'Source': 'jhim_cdl', 'tablename': 'COVERAGE_LIFE_TT', 'tbl_primarykey': 'COVERAGE_LIFE_TT_SEQ_NUM,ROW_START'},
{'Source': 'jhim_cdl', 'tablename': 'CDL_AUDIT', 'tbl_primarykey': 'CDL_AUDIT_SEQ_NUM,BATCH_DATE'},
{'Source': 'jhim_cdl', 'tablename': 'CUSTOMER_TT', 'tbl_primarykey': 'CUSTOMER_TT_SEQ_NUM,ROW_START'},
{'Source': 'jhim_cdl', 'tablename': 'DTL_QUOTE_IDENTIFIER', 'tbl_primarykey': None},
{'Source': 'jhim_cdl', 'tablename': 'PRODUCT_TT', 'tbl_primarykey': 'PRODUCT_TT_SEQ_NUM,ROW_START'},
{'Source': 'jhim_cdl', 'tablename': 'RIDER', 'tbl_primarykey': 'RIDER_SEQ_NUM,ROW_START'},
{'Source': 'jhim_cdl', 'tablename': 'CDL_JOB_STATS', 'tbl_primarykey': 'CDL_JOB_STATS_SEQ_NUM,BATCH_DT'},
{'Source': 'jhim_cdl', 'tablename': 'COVERAGE_LIFE_PRICING_TT', 'tbl_primarykey': 'COVERAGE_LIFE_PRICING_TT_SEQ_NUM,ROW_START'},
{'Source': 'jhim_cdl', 'tablename': 'AGENT_HIER_TT', 'tbl_primarykey': 'AGENT_HIER_TT_SEQ_NUM,ROW_START'},
{'Source': 'jhim_cdl', 'tablename': 'APPLICATION_DECISION', 'tbl_primarykey': 'APPLICATION_DECISION_SEQ_NUM,ROW_START'},
{'Source': 'jhim_cdl', 'tablename': 'DTL_POLICY_DRIVER', 'tbl_primarykey': 'DTL_POLICY_DRIVER_SEQ_NUM'},
{'Source': 'jhim_cdl', 'tablename': 'PARTY_ADDR_USAGE_TT', 'tbl_primarykey': 'PARTY_ADDR_USAGE_TT_SEQ_NUM,ROW_START'},
{'Source': 'jhim_cdl', 'tablename': 'CDL_JOB_CONTROL', 'tbl_primarykey': 'SEQ_NUM,JOB_DATE'},
{'Source': 'jhim_cdl', 'tablename': 'AGENT_TT', 'tbl_primarykey': 'AGENT_TT_SEQ_NUM,ROW_START'},
{'Source': 'jhim_cdl', 'tablename': 'DTL_2V_POLICY_OVERRIDE_TT', 'tbl_primarykey': 'DTL_2V_POLICY_OVERRIDE_TT_SEQ_NUM,ROW_START'},
{'Source': 'jhim_cdl', 'tablename': 'REF_LOOKUP', 'tbl_primarykey': None},
{'Source': 'jhim_cdl', 'tablename': 'JHIM_POLICY_OVERRIDE', 'tbl_primarykey': 'JHIM_POLICY_OVERRIDE_ID,BEGIN_TS'},
{'Source': 'jhim_cdl', 'tablename': 'POLICY_TT', 'tbl_primarykey': 'POLICY_TT_SEQ_NUM,ROW_START'},
{'Source': 'jhim_cdl', 'tablename': 'CASE_COVERAGE_TT', 'tbl_primarykey': 'CASE_COVERAGE_TT_SEQ_NUM,ROW_START'},
{'Source': 'jhim_cdl', 'tablename': 'COVERAGE_TT', 'tbl_primarykey': 'COVERAGE_TT_SEQ_NUM,ROW_START'},
{'Source': 'jhim_cdl', 'tablename': 'CASE_COVERAGE_RTNG_TT', 'tbl_primarykey': 'CASE_COVERAGE_RTNG_TT_SEQ_NUM,ROW_START'},
{'Source': 'jhim_cdl', 'tablename': 'CASE_REQUIREMENT_TT', 'tbl_primarykey': 'CASE_REQUIREMENT_TT_SEQ_NUM,ROW_START'},
{'Source': 'jhim_cdl', 'tablename': 'ADDRESS_TT', 'tbl_primarykey': 'ADDRESS_TT_SEQ_NUM,ROW_START'},
{'Source': 'jhim_cdl', 'tablename': 'POLICY_PARTY_ROLE_TT', 'tbl_primarykey': 'POLICY_PARTY_ROLE_TT_SEQ_NUM,ROW_START'},
{'Source': 'jhim_cdl', 'tablename': 'POLICY_ADDL_PRIM_TT', 'tbl_primarykey': 'POLICY_ADDL_PRIM_TT_SEQ_NUM,ROW_START'},
{'Source': 'jhim_cdl', 'tablename': 'POLICY_PARTY_ROLE_ADDL_TT', 'tbl_primarykey': 'POLICY_PARTY_ROLE_ADDL_TT_SEQ_NUM,ROW_START'},
{'Source': 'jhim_cdl', 'tablename': 'CASE_DETAIL_TT', 'tbl_primarykey': 'CASE_DETAIL_TT_SEQ_NUM,ROW_START'},
{'Source': 'jhim_cdl', 'tablename': 'AGENT_AGREEMENT_TT', 'tbl_primarykey': 'AGENT_AGREEMENT_TT_SEQ_NUM,ROW_START'},
{'Source': 'jhim_cdl', 'tablename': 'APPLICATION_POLICY', 'tbl_primarykey': 'APPLICATION_POLICY_SEQ_NUM,ROW_START'}]

# COMMAND ----------

summary_df = apply_dq_rules(assets, 'silver_jhim_cdl')
uc_write(summary_df)
