# Databricks notebook source
# MAGIC %run ../../utils

# COMMAND ----------

# MAGIC %run ../primarykey_utils

# COMMAND ----------

assets = [{'Source': 'ODS', 'tablename': 's_case_coverage_rtng_tt', 'tbl_primarykey': 'S_CASE_COVERAGE_RTNG_TT_SEQ_NUM,ROW_START'},
{'Source': 'ODS', 'tablename': 'S_POLICY_LIFE_CLAIM_TT', 'tbl_primarykey': 'S_POLICY_LIFE_CLAIM_TT_SEQ_NUM,ROW_START'},
{'Source': 'ODS', 'tablename': 'S_POLICY_LOAN_LIFE_HI_TT', 'tbl_primarykey': 'S_POLICY_LOAN_LIFE_HI_TT_SEQ_NUM,ROW_START'},
{'Source': 'ODS', 'tablename': 'S_POLICY_LIFE_TRANS', 'tbl_primarykey': 'S_POLICY_LIFE_TRANS_SEQ_NUM'},
{'Source': 'ODS', 'tablename': 'S_POLICY_LIFE_LOW_TT', 'tbl_primarykey': 'S_POLICY_LIFE_LOW_TT_SEQ_NUM,ROW_START'},
{'Source': 'ODS', 'tablename': 'S_COVERAGE_LIFE_PRICING', 'tbl_primarykey': 'S_COVERAGE_LIFE_PRICING_SEQ_NUM,ROW_START'},
{'Source': 'ODS', 'tablename': 'H_POLICY', 'tbl_primarykey': 'H_POLICY_SEQ_NUM'},
{'Source': 'ODS', 'tablename': 'S_POLICY_DIV_TT', 'tbl_primarykey': 'S_POLICY_DIV_TT_SEQ_NUM,ROW_START'},
{'Source': 'ODS', 'tablename': 'S_POLICY_LIFE_DAILY', 'tbl_primarykey': 'S_POLICY_LIFE_DAILY_SEQ_NUM,ROW_START'},
{'Source': 'ODS', 'tablename': 'S_POLICY_LIFE_CV_LOW_TT', 'tbl_primarykey': 'S_POLICY_LIFE_CV_LOW_TT_SEQ_NUM,ROW_START'},
{'Source': 'ODS', 'tablename': 'S_POLICY_LOAN_LIFE_HI', 'tbl_primarykey': 'S_POLICY_LOAN_LIFE_HI_SEQ_NUM'},
{'Source': 'ODS', 'tablename': 'H_COVERAGE_TT', 'tbl_primarykey': 'H_COVERAGE_TT_SEQ_NUM,ROW_START'},
{'Source': 'ODS', 'tablename': 'S_COVERAGE_LIFE_HI', 'tbl_primarykey': 'S_COVERAGE_LIFE_HI_SEQ_NUM,ROW_START'},
{'Source': 'ODS', 'tablename': 'L_POLICY_COVERAGE', 'tbl_primarykey': 'L_POLICY_COVERAGE_SEQ_NUM'},
{'Source': 'ODS', 'tablename': 'S_COVERAGE_LIFE_HI_TT', 'tbl_primarykey': 'S_COVERAGE_LIFE_HI_TT_SEQ_NUM,ROW_START'},
{'Source': 'ODS', 'tablename': 'S_POLICY_LIFE_HI', 'tbl_primarykey': 'S_POLICY_LIFE_HI_SEQ_NUM'},
{'Source': 'ODS', 'tablename': 'S_POLICY_LIFE_TP', 'tbl_primarykey': 'S_POLICY_LIFE_TP_SEQ_NUM'},
{'Source': 'ODS', 'tablename': 'S_COVERAGE_LIFE_LOW_TT', 'tbl_primarykey': 'S_COVERAGE_LIFE_LOW_TT_SEQ_NUM,ROW_START'},
{'Source': 'ODS', 'tablename': 'S_POLICY_LIFE_MED_TT', 'tbl_primarykey': 'S_POLICY_LIFE_MED_TT_SEQ_NUM,ROW_START'},
{'Source': 'ODS', 'tablename': 'S_POLICY_CLASS_ACTION', 'tbl_primarykey': 'S_POL_CL_ACT_SEQ_NUM,POLICY_NUM,PLC_CODE'},
{'Source': 'ODS', 'tablename': 'S_POLICY_LIFE_COMMISSION', 'tbl_primarykey': 'S_POLICY_LIFE_COMMISSION_SEQ_NUM,ROW_START'},
{'Source': 'ODS', 'tablename': 'S_POLICY_PRODUCT_TT', 'tbl_primarykey': 'S_POLICY_PRODUCT_TT_SEQ_NUM,ROW_START'},
{'Source': 'ODS', 'tablename': 'S_COVERAGE_FUND_LIFE_LOW', 'tbl_primarykey': 'S_COVERAGE_FUND_LIFE_LOW_SEQ_NUM'},
{'Source': 'ODS', 'tablename': 'S_COVERAGE_ROP_LIFE_MED_TT', 'tbl_primarykey': 'S_COVERAGE_ROP_LIFE_MED_TT_SEQ_NUM,ROW_START'},
{'Source': 'ODS', 'tablename': 'S_COVERAGE_LIFE_UW_RISK', 'tbl_primarykey': 'S_COVERAGE_LIFE_UW_RISK_SEQ_NUM,ROW_START'},
{'Source': 'ODS', 'tablename': 'S_POLICY_FUND_TT', 'tbl_primarykey': 'S_POLICY_FUND_TT_SEQ_NUM,ROW_START'},
{'Source': 'ODS', 'tablename': 'S_COVERAGE_LIFE_MED', 'tbl_primarykey': 'S_COVERAGE_LIFE_MED_SEQ_NUM'},
{'Source': 'ODS', 'tablename': 'S_POLICY_LIFE_CLAIM_DTH', 'tbl_primarykey': 'S_POLICY_LIFE_CLAIM_DTH_SEQ_NUM,ROW_START'},
{'Source': 'ODS', 'tablename': 'S_POLICY_LIFE_CLAIM_DTH_BENE', 'tbl_primarykey': 'S_POLICY_LIFE_CLAIM_DTH_BENE_SEQ_NUM,ROW_START'},
{'Source': 'ODS', 'tablename': 'S_POLICY_AGENT_TT', 'tbl_primarykey': 'S_POLICY_AGENT_TT_SEQ_NUM,ROW_START'},
{'Source': 'ODS', 'tablename': 'S_POLICY_LIFE_PAC_TT', 'tbl_primarykey': 'S_POLICY_LIFE_PAC_TT_SEQ_NUM,ROW_START'},
{'Source': 'ODS', 'tablename': 'S_POLICY_PRODUCT_LIFE_LOW', 'tbl_primarykey': 'S_POLICY_PRODUCT_LIFE_LOW_SEQ_NUM'},
{'Source': 'ODS', 'tablename': 'S_POLICY_SCAN_RECORD', 'tbl_primarykey': 'S_POLICY_SCAN_RECORD_SEQ_NUM'},
{'Source': 'ODS', 'tablename': 'S_POLICY_LIFE_SCHD_TT', 'tbl_primarykey': 'S_POLICY_LIFE_SCHD_TT_SEQ_NUM,ROW_START'},
{'Source': 'ODS', 'tablename': 's_case_requirement_tt', 'tbl_primarykey': 'S_CASE_REQUIREMENT_TT_SEQ_NUM,ROW_START'},
{'Source': 'ODS', 'tablename': 'S_COVERAGE_DTL_LIFE_LOW', 'tbl_primarykey': 'S_COVERAGE_DTL_LIFE_LOW_SEQ_NUM'},
{'Source': 'ODS', 'tablename': 'S_COVERAGE_LIFE_LOW', 'tbl_primarykey': 'S_COVERAGE_LIFE_LOW_SEQ_NUM'},
{'Source': 'ODS', 'tablename': 'S_POLICY_LIFE_MISC_TT', 'tbl_primarykey': 'S_POLICY_LIFE_MISC_TT_SEQ_NUM,ROW_START'},
{'Source': 'ODS', 'tablename': 'S_POLICY_LIFE_REINS', 'tbl_primarykey': 'S_POLICY_LIFE_REINS_SEQ_NUM,ROW_START'},
{'Source': 'ODS', 'tablename': 'S_POLICY_LIFE_ROR', 'tbl_primarykey': 'S_POLICY_LIFE_ROR_SEQ_NUM,ROW_START'},
{'Source': 'ODS', 'tablename': 'H_COVERAGE', 'tbl_primarykey': 'H_COVERAGE_SEQ_NUM'},
{'Source': 'ODS', 'tablename': 'S_COVERAGE_HE_LIFE_MED', 'tbl_primarykey': 'S_COVERAGE_HE_LIFE_MED_SEQ_NUM'},
{'Source': 'ODS', 'tablename': 'S_COVERAGE_LIFE_MED_TT', 'tbl_primarykey': 'S_COVERAGE_LIFE_MED_TT_SEQ_NUM,ROW_START'},
{'Source': 'ODS', 'tablename': 'S_POLICY_LIFE_DAILY_TT', 'tbl_primarykey': 'S_POLICY_LIFE_DAILY_TT_SEQ_NUM,ROW_START'},
{'Source': 'ODS', 'tablename': 'S_POLICY_LIFE_HI_TT', 'tbl_primarykey': 'S_POLICY_LIFE_HI_TT_SEQ_NUM,ROW_START'},
{'Source': 'ODS', 'tablename': 'S_POLICY_LIFE_CV_LOW', 'tbl_primarykey': 'S_POLICY_LIFE_CV_LOW_SEQ_NUM'},
{'Source': 'ODS', 'tablename': 's_case_detail_tt', 'tbl_primarykey': 'S_CASE_DETAIL_TT_SEQ_NUM,ROW_START'},
{'Source': 'ODS', 'tablename': 'S_COVERAGE_LIFE_PRICING_TT', 'tbl_primarykey': 'S_COVERAGE_LIFE_PRICING_TT_SEQ_NUM,ROW_START'},
{'Source': 'ODS', 'tablename': 'S_POLICY_REPLACEMENT', 'tbl_primarykey': 'S_POLICY_REPLACEMENT_SEQ_NUM'},
{'Source': 'ODS', 'tablename': 'ref_lookup', 'tbl_primarykey': None},
{'Source': 'ODS', 'tablename': 'S_COVERAGE_FUND_LIFE_HI', 'tbl_primarykey': 'S_COVERAGE_FUND_LIFE_HI_SEQ_NUM'},
{'Source': 'ODS', 'tablename': 'S_POLICY_LIFE_LOW', 'tbl_primarykey': 'S_POLICY_LIFE_LOW_SEQ_NUM'},
{'Source': 'ODS', 'tablename': 'S_POLICY_REQUIREMENT', 'tbl_primarykey': 'S_POLICY_REQUIREMENT_SEQ_NUM'},
{'Source': 'ODS', 'tablename': 'S_POLICY_AGENCY_TT', 'tbl_primarykey': 'S_POLICY_AGENCY_TT_SEQ_NUM,ROW_START'},
{'Source': 'ODS', 'tablename': 'S_POLICY_AGENCY', 'tbl_primarykey': 'S_POLICY_AGENCY_SEQ_NUM'},
{'Source': 'ODS', 'tablename': 'S_POLICY_LIFE_CLAIM', 'tbl_primarykey': 'S_POLICY_LIFE_CLAIM_SEQ_NUM,ROW_START'},
{'Source': 'ODS', 'tablename': 'S_POLICY_LIFE_MED', 'tbl_primarykey': 'S_POLICY_LIFE_MED_SEQ_NUM'},
{'Source': 'ODS', 'tablename': 'S_POLICY_BASIC1_TT', 'tbl_primarykey': 'S_POLICY_BASIC1_TT_SEQ_NUM,ROW_START'},
{'Source': 'ODS', 'tablename': 's_case_coverage_tt', 'tbl_primarykey': 'S_CASE_COVERAGE_TT_SEQ_NUM,ROW_START'},
{'Source': 'ODS', 'tablename': 'S_COVERAGE_ROP_LIFE_MED', 'tbl_primarykey': 'S_COVERAGE_ROP_LIFE_MED_SEQ_NUM'},
{'Source': 'ODS', 'tablename': 'S_FUND_TT', 'tbl_primarykey': 'S_FUND_TT_SEQ_NUM,ROW_START'},
{'Source': 'ODS', 'tablename': 'S_POLICY_LIFE_MISC_VALUES_TT', 'tbl_primarykey': 'S_POLICY_LIFE_MISC_VALUES_TT_SEQ_NUM,ROW_START'},
{'Source': 'ODS', 'tablename': 's_case_replacement_tt', 'tbl_primarykey': 'S_CASE_REPLACEMENT_TT_SEQ_NUM,ROW_START'}]

# COMMAND ----------

config['data_domain'] = 'Policy'
config['rule_owner'] = 'Gina Stewart'
config['data_owner'] = 'Amy Miskavitch'
config['business_unit'] = 'Life (US)'

summary_df = apply_dq_rules(assets, 'silver_ods')
uc_write(summary_df)
