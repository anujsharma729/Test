# Databricks notebook source
# MAGIC %run ../../utils

# COMMAND ----------

# MAGIC %run ../primarykey_utils

# COMMAND ----------

config['data_domain'] = 'Policy'
config['rule_owner'] = 'Gina Stewart'
config['data_owner'] = 'Amy Miskavitch'
config['business_unit'] = 'Life (US)'

assets = [
    {'Source': 'div_mdm', 'tablename': 'CDCONTMETHTP', 'tbl_primarykey': 'LANG_TP_CD,CONT_METH_TP_CD'},
    {'Source': 'div_mdm', 'tablename': 'CDCONTMETHCAT', 'tbl_primarykey': 'LANG_TP_CD,CONT_METH_CAT_CD'},
    {'Source': 'div_mdm', 'tablename': 'CONTRACT', 'tbl_primarykey': 'CONTRACT_ID'},
    {'Source': 'div_mdm', 'tablename': 'CONTACTMETHOD', 'tbl_primarykey': 'CONTACT_METHOD_ID'},
    {'Source': 'div_mdm', 'tablename': 'CDADMINSYSTP', 'tbl_primarykey': 'ADMIN_SYS_TP_CD,LANG_TP_CD'},
    {'Source': 'div_mdm', 'tablename': 'PERSON', 'tbl_primarykey': 'CONT_ID'},
    {'Source': 'div_mdm', 'tablename': 'ROLELOCATION', 'tbl_primarykey': 'ROLE_LOCATION_ID'},
    {'Source': 'div_mdm', 'tablename': 'CDCONTRACTROLETP', 'tbl_primarykey': 'CONTR_ROLE_TP_CD,LANG_TP_CD'},
    {'Source': 'div_mdm', 'tablename': 'CONTEQUIV', 'tbl_primarykey': 'CONT_EQUIV_ID'},
    {'Source': 'div_mdm', 'tablename': 'ORGNAME', 'tbl_primarykey': 'ORG_NAME_ID'},
    {'Source': 'div_mdm', 'tablename': 'CDAGREEMENTTP', 'tbl_primarykey': 'LANG_TP_CD,AGREEMENT_TP_CD'},
    {'Source': 'div_mdm', 'tablename': 'CDPROVSTATETP', 'tbl_primarykey': 'LANG_TP_CD,PROV_STATE_TP_CD'},
    {'Source': 'div_mdm', 'tablename': 'IDENTIFIER', 'tbl_primarykey': 'IDENTIFIER_ID'},
    {'Source': 'div_mdm', 'tablename': 'CDADMINFLDNMTP', 'tbl_primarykey': 'ADMIN_FLD_NM_TP_CD,LANG_TP_CD'},
    {'Source': 'div_mdm', 'tablename': 'CONTACT', 'tbl_primarykey': 'CONT_ID'},
    {'Source': 'div_mdm', 'tablename': 'NATIVEKEY', 'tbl_primarykey': 'NATIVE_KEY_ID'},
    {'Source': 'div_mdm', 'tablename': 'ADDRESSGROUP', 'tbl_primarykey': 'LOCATION_GROUP_ID'},
    {'Source': 'div_mdm', 'tablename': 'PERSONNAME', 'tbl_primarykey': 'PERSON_NAME_ID'},
    {'Source': 'div_mdm', 'tablename': 'CONTACTMETHODGROUP', 'tbl_primarykey': 'LOCATION_GROUP_ID'},
    {'Source': 'div_mdm', 'tablename': 'CONTRACTROLE', 'tbl_primarykey': 'CONTRACT_ROLE_ID'},
    {'Source': 'div_mdm', 'tablename': 'CDADDRUSAGETP', 'tbl_primarykey': 'LANG_TP_CD,ADDR_USAGE_TP_CD'},
    {'Source': 'div_mdm', 'tablename': 'CONTRACTCOMPONENT', 'tbl_primarykey': 'CONTR_COMPONENT_ID'},
    {'Source': 'div_mdm', 'tablename': 'CDCOUNTRYTP', 'tbl_primarykey': 'LANG_TP_CD,COUNTRY_TP_CD'},
    {'Source': 'div_mdm', 'tablename': 'ADDRESS', 'tbl_primarykey': 'ADDRESS_ID'},
    {'Source': 'div_mdm', 'tablename': 'LOCATIONGROUP', 'tbl_primarykey': 'LOCATION_GROUP_ID'},
    {'Source': 'div_mdm', 'tablename': 'CDCONTRACTSTTP', 'tbl_primarykey': 'CONTRACT_ST_TP_CD,LANG_TP_CD'}]

# COMMAND ----------

summary_df = apply_dq_rules(assets, 'silver_div_mdm')
uc_write(summary_df)
