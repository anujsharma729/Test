# Databricks notebook source
# MAGIC %run ../../utils

# COMMAND ----------

# MAGIC %run ../primarykey_utils

# COMMAND ----------

assets = [{'Source': 'LTC_MDM', 'tablename': 'XDATACHANGEEXCEPTIONLIST', 'tbl_primarykey': 'XDATA_CHANGE_SUMMERYPK_ID'},
{'Source': 'LTC_MDM', 'tablename': 'CDIDTP', 'tbl_primarykey': 'LANG_TP_CD,ID_TP_CD'},
{'Source': 'LTC_MDM', 'tablename': 'CDADDRUSAGETP', 'tbl_primarykey': 'LANG_TP_CD,ADDR_USAGE_TP_CD'},
{'Source': 'LTC_MDM', 'tablename': 'CDCONTRACTROLETP', 'tbl_primarykey': 'LANG_TP_CD,CONTR_ROLE_TP_CD'},
{'Source': 'LTC_MDM', 'tablename': 'CLAIMROLE', 'tbl_primarykey': 'CLAIM_ROLE_ID'},
{'Source': 'LTC_MDM', 'tablename': 'CLAIMCONTRACT', 'tbl_primarykey': 'CLAIM_CONTR_ID'},
{'Source': 'LTC_MDM', 'tablename': 'CDCONTRACTSTTP', 'tbl_primarykey': 'LANG_TP_CD,CONTRACT_ST_TP_CD'},
{'Source': 'LTC_MDM', 'tablename': 'CDCLAIMROLETP', 'tbl_primarykey': 'LANG_TP_CD,CLAIM_ROLE_TP_CD'},
{'Source': 'LTC_MDM', 'tablename': 'CDCONTMETHTP', 'tbl_primarykey': 'LANG_TP_CD,CONT_METH_TP_CD'},
{'Source': 'LTC_MDM', 'tablename': 'CDADMINSYSTP', 'tbl_primarykey': 'LANG_TP_CD,ADMIN_SYS_TP_CD'},
{'Source': 'LTC_MDM', 'tablename': 'CDPROVSTATETP', 'tbl_primarykey': 'LANG_TP_CD,PROV_STATE_TP_CD'},
{'Source': 'LTC_MDM', 'tablename': 'IDENTIFIER', 'tbl_primarykey': 'IDENTIFIER_ID'},
{'Source': 'LTC_MDM', 'tablename': 'XDATACHANGESUMMERY', 'tbl_primarykey': 'XDATA_CHANGE_SUMMERYPK_ID'},
{'Source': 'LTC_MDM', 'tablename': 'CONTEQUIV', 'tbl_primarykey': 'CONT_EQUIV_ID'},
{'Source': 'LTC_MDM', 'tablename': 'ORGNAME', 'tbl_primarykey': 'ORG_NAME_ID'},
{'Source': 'LTC_MDM', 'tablename': 'CDIDSTATUSTP', 'tbl_primarykey': 'LANG_TP_CD,ID_STATUS_TP_CD'},
{'Source': 'LTC_MDM', 'tablename': 'CONTACTMETHOD', 'tbl_primarykey': 'CONTACT_METHOD_ID'},
{'Source': 'LTC_MDM', 'tablename': 'PERSON', 'tbl_primarykey': 'CONT_ID'},
{'Source': 'LTC_MDM', 'tablename': 'CONTRACT', 'tbl_primarykey': 'CONTRACT_ID'},
{'Source': 'LTC_MDM', 'tablename': 'CONTRACTCOMPONENT', 'tbl_primarykey': 'CONTR_COMPONENT_ID'},
{'Source': 'LTC_MDM', 'tablename': 'CLAIM', 'tbl_primarykey': 'CLAIM_ID'},
{'Source': 'LTC_MDM', 'tablename': 'XPAYMENT', 'tbl_primarykey': 'XPAYMENTPK_ID'},
{'Source': 'LTC_MDM', 'tablename': 'CONTACTREL', 'tbl_primarykey': 'CONT_REL_ID'},
{'Source': 'LTC_MDM', 'tablename': 'CDCONTRCOMPTP', 'tbl_primarykey': 'LANG_TP_CD,CONTR_COMP_TP_CD'},
{'Source': 'LTC_MDM', 'tablename': 'CDXELIGIBILITYDECTP', 'tbl_primarykey': 'LANG_TP_CD,ELIGIB_DEC_TP_CD'},
{'Source': 'LTC_MDM', 'tablename': 'CONTRACTREL', 'tbl_primarykey': 'CONTRACT_REL_ID'},
{'Source': 'LTC_MDM', 'tablename': 'NATIVEKEY', 'tbl_primarykey': 'NATIVE_KEY_ID'},
{'Source': 'LTC_MDM', 'tablename': 'PERSONNAME', 'tbl_primarykey': 'PERSON_NAME_ID'},
{'Source': 'LTC_MDM', 'tablename': 'INACTIVATEDCONT', 'tbl_primarykey': 'CONT_ID'},
{'Source': 'LTC_MDM', 'tablename': 'CONTACT', 'tbl_primarykey': 'CONT_ID'},
{'Source': 'LTC_MDM', 'tablename': 'CONTRACTROLE', 'tbl_primarykey': 'CONTRACT_ROLE_ID'},
{'Source': 'LTC_MDM', 'tablename': 'LOCATIONGROUP', 'tbl_primarykey': 'LOCATION_GROUP_ID'},
{'Source': 'LTC_MDM', 'tablename': 'CDADMINFLDNMTP', 'tbl_primarykey': 'LANG_TP_CD,ADMIN_FLD_NM_TP_CD'},
{'Source': 'LTC_MDM', 'tablename': 'CDCOUNTRYTP', 'tbl_primarykey': 'LANG_TP_CD,COUNTRY_TP_CD'},
{'Source': 'LTC_MDM', 'tablename': 'CDNAMEUSAGETP', 'tbl_primarykey': 'LANG_TP_CD,NAME_USAGE_TP_CD'},
{'Source': 'LTC_MDM', 'tablename': 'CDCLAIMSTATUSTP', 'tbl_primarykey': 'LANG_TP_CD,CLAIM_STATUS_TP_CD'},
{'Source': 'LTC_MDM', 'tablename': 'CONTACTMETHODGROUP', 'tbl_primarykey': 'LOCATION_GROUP_ID'},
{'Source': 'LTC_MDM', 'tablename': 'XCLAIMPAYMENTREL', 'tbl_primarykey': 'XCLAIM_PAYMENT_RELPK_ID'},
{'Source': 'LTC_MDM', 'tablename': 'ADDRESSGROUP', 'tbl_primarykey': 'LOCATION_GROUP_ID'},
{'Source': 'LTC_MDM', 'tablename': 'ADDRESS', 'tbl_primarykey': 'ADDRESS_ID'},
{'Source': 'LTC_MDM', 'tablename': 'CDORGNAMETP', 'tbl_primarykey': 'LANG_TP_CD,ORG_NAME_TP_CD'}]

# COMMAND ----------

config['data_domain'] = 'Policy'
config['rule_owner'] = 'Gina Stewart'
config['data_owner'] = 'Amy Miskavitch'
config['business_unit'] = 'Life (US)'

summary_df = apply_dq_rules(assets, 'silver_ltc_mdm')
uc_write(summary_df)

# COMMAND ----------

config['asset_name'] = 'Dime_LTC_MDM'
save_parquet_results(None, summary_df, **config)
