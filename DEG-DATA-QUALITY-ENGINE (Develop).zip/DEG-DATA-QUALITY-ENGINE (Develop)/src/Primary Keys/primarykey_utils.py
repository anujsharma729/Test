# Databricks notebook source
# MAGIC %run ./../utils

# COMMAND ----------

def syn_read_asset(schema_name, table_name):
    synapse_table = f"{schema_name}.{table_name}"
    df = spark.read.jdbc(url=jdbcUrl, table=synapse_table)
    return df

def uc_read(schema, asset):
    df = spark.sql(f"SELECT * FROM usdo_prod_catalog.{schema}.{asset}")
    return df

# COMMAND ----------

config['work_stream'] = 'Primary Keys'

# COMMAND ----------

def save_parquet_results(failed_rows_df, summary_df, asset_name, work_stream, data_system,**kwargs): # NOSONAR
    if failed_rows_df is not None:
        failed_rows_df.write.parquet(f"abfss://dataquality@{ENV['storage_account']}.dfs.core.windows.net/{work_stream}/{data_system}/{asset_name}/{TIMESTAMP}/failed_rows")
    if summary_df is not None:
        summary_df.write.parquet(f"abfss://dataquality@{ENV['storage_account']}.dfs.core.windows.net/{work_stream}/{data_system}/{asset_name}/{TIMESTAMP}/scan_summary")

# COMMAND ----------

def value_counts(df, column):
    value_counts_df = df.groupBy(column).count().orderBy(f.col("Count").desc(),f.asc(column))
    display(value_counts_df)
    return value_counts_df

# COMMAND ----------

def trim(df):
    for column in df.columns:
        df = df.withColumn(column, f.ltrim(f.rtrim(df[column])))
    return df
    
def clean(df, columns=None):
    df = trim(df)
    if columns == None: columns = df.columns
    for column in columns:
        df = df.withColumn(column, f.when(f.col(column) == '\0', None)
            .when(f.col(column) == '', None)
            .when(f.initcap(f.col(column)) == 'Null', None)
            .when(f.initcap(f.col(column)) == 'Unknown', None)
            .when(f.initcap(f.col(column)) == 'Na', None)
            .when(f.initcap(f.col(column)) == 'N/a', None)
            # .when(f.col(column).rlike(r"^0+$"), None)
            .otherwise(f.col(column)))
    return df

def get_current_data(df, ids, dates):
    window_spec = Window.partitionBy(ids).orderBy(col(dates).desc())
    df_with_rownum = df.withColumn("row_num", row_number().over(window_spec))
    filtered_df = df_with_rownum.filter(col("row_num") == 1).drop("row_num")
    return filtered_df

# COMMAND ----------

def apply_dq_rules(assets, schema, config = config):
    summary_df = None
    for asset in assets:
        config['asset_name'] = asset['tablename']
        config['data_system'] = asset['Source']
        config['parent_dir'] = f"usdo_prod_catalog.{schema}.{asset['tablename']}"
        
        if asset.get("tbl_primarykey") is None: continue
        try:
            # df = read_asset(**config)
            df = uc_read(schema, config['asset_name'])
            print(config['asset_name'], " :", df.count())
            if asset.get("change_date") :
                df = get_current_data(df, asset.get('tbl_primarykey').split(','), asset.get('change_date').split([',']))

            df = df.select(asset.get('tbl_primarykey').split(","))
            df = clean(df)
            if "," in asset.get('tbl_primarykey'): 
                asset_keys = asset.get('tbl_primarykey').split(",")
                for value in asset_keys:
                    df = completeness_check(df, value)
            else:
                df = completeness_check(df, asset.get('tbl_primarykey'))

            df = uniqueness_check(df, asset.get('tbl_primarykey').split(","))
            summary = get_summary(df)
            if summary_df is None: summary_df = summary
            else: summary_df = summary_df.union(summary)
        except Exception as e:
            print(e)
            print('Could Not Load: ', config['asset_name'])
    summary_df = summary_df.withColumn('threshold', f.lit('1'))
    return summary_df

# COMMAND ----------

def get_failed_rows(df):
    data_quality_columns = [column for column in df.columns if column.startswith(('Completeness:','Uniqueness:','Conformity:','Consistency:','Accuracy:'))]
    condition_expr = ".contains('fail') | ".join([f"df['{column}']" for column in data_quality_columns]) + ".contains('fail')"
    failed_rows_df = df.filter(eval(condition_expr))
    return failed_rows_df

# COMMAND ----------

def print_dataframe_as_dict(spark_df):
    # Collect the DataFrame rows to the driver
    rows = spark_df.collect()
    
    # Convert rows to dictionary
    rows_as_dict = [row.asDict() for row in rows]
    
    # Print the dictionary
    for value in rows_as_dict:
        print(value)

# print_dataframe_as_dict(t)
