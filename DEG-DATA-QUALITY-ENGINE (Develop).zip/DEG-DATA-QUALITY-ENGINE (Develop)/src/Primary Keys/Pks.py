# Databricks notebook source
# MAGIC %run ../utils

# COMMAND ----------

# MAGIC %run ./primarykey_utils

# COMMAND ----------

config['business_unit'] = 'Life (US)'
config['data_owner'] = 'Lindsay Hanson'
config['data_domain'] = 'Wellness'
config['rule_owner'] = 'Halen Ganley'

assets = [{'Source': 'vitality', 'tablename': 'ACTIVEREWARDS_GOALS', 'tbl_primarykey': 'Skey'},
{'Source': 'vitality', 'tablename': 'ACTIVEREWARDS_REWARDS', 'tbl_primarykey': 'Skey'},
{'Source': 'vitality', 'tablename': 'ATTRIBUTES', 'tbl_primarykey': 'Skey'},
{'Source': 'vitality', 'tablename': 'DEVICE_DETAIL', 'tbl_primarykey': 'Skey'},
{'Source': 'vitality', 'tablename': 'EVENT_LOOKUP', 'tbl_primarykey': 'Skey'},
{'Source': 'vitality', 'tablename': 'EVENTS', 'tbl_primarykey': 'Skey'},
{'Source': 'vitality', 'tablename': 'EVENTSTATUS', 'tbl_primarykey': 'Skey'},
{'Source': 'vitality', 'tablename': 'HEALTHYFOOD', 'tbl_primarykey': 'Skey'},
{'Source': 'vitality', 'tablename': 'HOTELS', 'tbl_primarykey': 'Skey'},
{'Source': 'vitality', 'tablename': 'MALL', 'tbl_primarykey': 'Skey'},
{'Source': 'vitality', 'tablename': 'LOGINS', 'tbl_primarykey': 'Skey'},
{'Source': 'vitality', 'tablename': 'MEMBERDETAILS', 'tbl_primarykey': 'Skey'},
{'Source': 'vitality', 'tablename': 'POINTS', 'tbl_primarykey': 'Skey'},
{'Source': 'vitality', 'tablename': 'VITALITYSQUARES', 'tbl_primarykey': 'Skey'},
{'Source': 'vitality', 'tablename': 'VITALITYWHEEL', 'tbl_primarykey': 'Skey'},
# {'Source': 'vitality', 'tablename': 'WATERFALL', 'tbl_primarykey': 'Skey'}
]

try:
    s1 = apply_dq_rules(assets, 'silver_vitality')
    uc_write(s1)
except Exception as e: 
    print(e)


# COMMAND ----------

config['business_unit'] = 'Life (US)'
config['data_owner'] = 'Amanda Murphy'
config['data_domain'] = 'Producer & Distributor'
config['rule_owner'] = 'Amanda Murphy'

assets = [{'Source':'marketo','tablename':'activities','tbl_primarykey':'id'},
{'Source':'marketo','tablename':'smartCampaigns','tbl_primarykey':'id'},
{'Source':'marketo','tablename':'customactivity types','tbl_primarykey':'id'},
{'Source':'marketo','tablename':'leads','tbl_primarykey':'id'},
{'Source':'marketo','tablename':'programs','tbl_primarykey':'id'},
{'Source':'marketo','tablename':'programmembers','tbl_primarykey':'leadId,programId'},
{'Source':'marketo','tablename':'channels','tbl_primarykey':'id'},
{'Source':'marketo','tablename':'activity types','tbl_primarykey':'id'},
{'Source':'marketo','tablename':'emails','tbl_primarykey':'id'}
]

try:
    s2 = apply_dq_rules(assets, 'silver_marketo')
    uc_write(s2)
except Exception as e: 
    print(e)


# COMMAND ----------

config['data_domain'] = 'New Business'
config['data_owner'] = 'Sarah Young'
config['rule_owner'] = 'Sarah Young'
config['business_unit'] = 'Life (US)'

assets = [{'Source': 'jhems', 'tablename': 'evidencerequests', 'tbl_primarykey': 'RequestId'},
{'Source': 'jhems', 'tablename': 'evidenceresponses', 'tbl_primarykey': 'RequestId'},
# {'Source': 'jhems', 'tablename': 'VendorOrderResults', 'tbl_primarykey': 'RequestId'}
]
try:
    s3 = apply_dq_rules(assets, 'silver_jhems')
    uc_write(s3)
except Exception as e: 
    print(e)

# COMMAND ----------

config['data_domain'] = 'New Business'
config['data_owner'] = 'Sarah Young'
config['rule_owner'] = 'Sarah Young'
config['business_unit'] = 'Life (US)'

assets = [{'Source':'salesforce_top','tablename':'Contact','tbl_primarykey':'id'},
{'Source':'salesforce_top','tablename':'LFNB_Jurisdiction__c','tbl_primarykey':'Id'},
{'Source':'salesforce_top','tablename':'LFNB_Territory__c','tbl_primarykey':'Id'},
{'Source':'salesforce_top','tablename':'LFNB_RVP_to_Territory__c','tbl_primarykey':'Id'},
{'Source':'salesforce_top','tablename':'LFNB_RVP_Credit_Split_Model__c','tbl_primarykey':'Id'}
]
try:
    s4 = apply_dq_rules(assets, 'silver_salesforce_top')    
    uc_write(s4)
except Exception as e: 
    print(e)


# COMMAND ----------

assets = [{'Source':'aws','tablename':'aws_annuity_ctr','tbl_primarykey':'contactid'},
{'Source':'aws','tablename':'aws_inssales_transcript','tbl_primarykey':'contactid'},
{'Source':'aws','tablename':'aws_nbops_transcript','tbl_primarykey':'contactid'},
{'Source':'aws','tablename':'aws_life_transcript','tbl_primarykey':'contactid'},
{'Source':'aws','tablename':'aws_ltc_transcript','tbl_primarykey':'contactid'}, 
{'Source':'aws','tablename':'aws_inssales_ctr','tbl_primarykey':'contactid'}, 
{'Source':'aws','tablename':'aws_life_ctr','tbl_primarykey':'contactid'}, 
{'Source':'aws','tablename':'aws_nbops_ctr','tbl_primarykey':'contactid'}]

config['data_domain'] = 'Customer'
config['rule_owner'] = 'Gina Stewart'
config['data_owner'] = 'Amy Miskavitch'
config['business_unit'] = 'Life (US)'

try:
    s5 = apply_dq_rules(assets, 'silver_aws')    
    uc_write(s5)
except Exception as e: 
    print(e)


# COMMAND ----------

assets = [
{'Source': 'mcms', 'tablename': 'MCMS_CPV3R000', 'tbl_primarykey': 'CP_POL_NO'},
{'Source': 'mcms', 'tablename': 'MCMS_CPV3R001', 'tbl_primarykey': 'CP_POL_NO,CP_REC_SEQ_NO'},
{'Source': 'mcms', 'tablename': 'MCMS_CPV3R010', 'tbl_primarykey': 'CP_POL_NO,CP_REC_SEQ_NO'},
{'Source': 'mcms', 'tablename': 'MCMS_CPV3R020', 'tbl_primarykey': 'CP_POL_NO'},
{'Source': 'mcms', 'tablename': 'MCMS_CPV3R080', 'tbl_primarykey': 'CP_POL_NO'},
{'Source': 'mcms', 'tablename': 'MCMS_CPV3R090', 'tbl_primarykey': 'CP_POL_NO,CP_REC_SEQ_NO'},
{'Source': 'mcms', 'tablename': 'MCMS_CPV3R095', 'tbl_primarykey': 'CP_POL_NO,CP_REC_SEQ_NO'},
{'Source': 'mcms', 'tablename': 'MCMS_CPV3R100', 'tbl_primarykey': 'CP_POL_NO,CP_REC_SEQ_NO,CP_PRD_TYPE_CD'},
{'Source': 'mcms', 'tablename': 'MCMS_CPV3R101', 'tbl_primarykey': 'CP_POL_NO,CP_REC_SEQ_NO,CP_PRD_TYPE_CD'},
{'Source': 'mcms', 'tablename': 'MCMS_CPV3R102', 'tbl_primarykey': 'CP_POL_NO,CP_REC_SEQ_NO,CP_PRD_TYPE_CD'},
{'Source': 'mcms', 'tablename': 'MCMS_CPV3R200', 'tbl_primarykey': 'CP_POL_NO,CP_REC_SEQ_NO,CP_PRD_TYPE_CD,CP_COV_DESCR_ID'},
{'Source': 'mcms', 'tablename': 'MCMS_CPV3R304', 'tbl_primarykey': 'CP_POL_NO,CP_REC_SEQ_NO,CP_PRD_TYPE_CD,CP_COV_DESCR_ID'},
{'Source': 'mcms', 'tablename': 'MCMS_CPV3R306', 'tbl_primarykey': 'CP_POL_NO'},
{'Source': 'mcms', 'tablename': 'MCMS_CPV3R310', 'tbl_primarykey': 'CP_POL_NO,CP_PRD_TYPE_CD'}]

config['data_domain'] = 'Policy'
config['rule_owner'] = 'Gina Stewart'
config['data_owner'] = 'Amy Miskavitch'
config['business_unit'] = 'Life (US)'

try:
    s6 = apply_dq_rules(assets, 'silver_mcms')    
    uc_write(s6)
except Exception as e: 
    print(e)

# COMMAND ----------

assets = [{'Source': 'voc_salesforce_ltc', 'tablename': 'ACCOUNT', 'tbl_primarykey': 'Id,MASTER_ID'},
{'Source': 'voc_salesforce_ltc', 'tablename': 'CASE', 'tbl_primarykey': 'Id'},
{'Source': 'voc_salesforce_ltc', 'tablename': 'Claim__c', 'tbl_primarykey': 'Id'},
{'Source': 'voc_salesforce_ltc', 'tablename': 'CONTACT', 'tbl_primarykey': 'Id'},
{'Source': 'voc_salesforce_ltc', 'tablename': 'EmailMessage', 'tbl_primarykey': 'Id'},
{'Source': 'voc_salesforce_ltc', 'tablename': 'LTC_Case_Detail__c', 'tbl_primarykey': 'Id'},
{'Source': 'voc_salesforce_ltc', 'tablename': 'LTC_Claim_Invoice__c', 'tbl_primarykey': 'Id'},
{'Source': 'voc_salesforce_ltc', 'tablename': 'LTC_Claim_Invoice_Detail__c', 'tbl_primarykey': 'Id'},
{'Source': 'voc_salesforce_ltc', 'tablename': 'LTC_Claim_Invoice_Submission__c', 'tbl_primarykey': 'Id'},
{'Source': 'voc_salesforce_ltc', 'tablename': 'LTC_Inflation_Election_Offer__c', 'tbl_primarykey': 'Id'},
{'Source': 'voc_salesforce_ltc', 'tablename': 'LTC_Premium_Payment_Submission__c', 'tbl_primarykey': 'Id'},
{'Source': 'voc_salesforce_ltc', 'tablename': 'LTC_Premium_Payment_Submission_Detail__c', 'tbl_primarykey': 'Id'},
{'Source': 'voc_salesforce_ltc', 'tablename': 'LTC_Time_Log__c', 'tbl_primarykey': 'Id'},
{'Source': 'voc_salesforce_ltc', 'tablename': 'LTC_View_Tracking_History__c', 'tbl_primarykey': 'Id'},
{'Source': 'voc_salesforce_ltc', 'tablename': 'Party_Role__c', 'tbl_primarykey': 'Id'},
{'Source': 'voc_salesforce_ltc', 'tablename': 'Policy__c', 'tbl_primarykey': 'Id'},
{'Source': 'voc_salesforce_ltc', 'tablename': 'RecordType', 'tbl_primarykey': 'Id'},
{'Source': 'voc_salesforce_ltc', 'tablename': 'TASK', 'tbl_primarykey': 'Id'},
{'Source': 'voc_salesforce_ltc', 'tablename': 'User', 'tbl_primarykey': 'Id'},
{'Source': 'voc_salesforce_ltc', 'tablename': 'CASE_07May2023', 'tbl_primarykey': 'Id'},
{'Source': 'voc_salesforce_ltc', 'tablename': 'Product2', 'tbl_primarykey': 'Id'}]

config['business_unit'] = 'Long Term Care (US)'
config['data_domain'] = 'Policy'
config['data_owner'] = 'Charles Wiegersma'
config['rule_owner'] = 'Dale Armagost'


try:
    s7 = apply_dq_rules(assets, 'silver_voc_salesforce_ltc')    
    uc_write(s7)
except Exception as e: 
    print(e)

# COMMAND ----------

assets = [{'Source': 'gba', 'tablename': 'Case', 'tbl_primarykey': 'Id'},
{'Source': 'gba', 'tablename': 'EventLogFile', 'tbl_primarykey': 'Id'},
{'Source': 'gba', 'tablename': 'Policy_Contract__c', 'tbl_primarykey': 'Id'},
{'Source': 'gba', 'tablename': 'Policy_Role__c', 'tbl_primarykey': 'Id'},
{'Source': 'gba', 'tablename': 'Report', 'tbl_primarykey': 'Id'},
{'Source': 'gba', 'tablename': 'Special_Handling__c', 'tbl_primarykey': 'Id'},
{'Source': 'gba', 'tablename': 'Task', 'tbl_primarykey': 'Id'},
{'Source': 'gba', 'tablename': 'User', 'tbl_primarykey': 'Id'}]

config['business_unit'] = 'Life (US)'
config['data_domain'] = 'Policy'
config['data_owner'] = 'Amy Miskavitch'
config['rule_owner'] = 'Gina Stewart'


try:
    s8 = apply_dq_rules(assets, 'silver_gba')    
    uc_write(s8)
except Exception as e: 
    print(e)
