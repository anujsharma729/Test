# Databricks notebook source
# MAGIC %run ../utils

# COMMAND ----------

# MAGIC %run ./primarykey_utils

# COMMAND ----------

config['data_domain'] = 'Policy'
config['rule_owner'] = 'Dale Armagost'
config['data_owner'] = 'Charles Wiergersma'
config['business_unit'] = 'Long Term Care (US)'

assets = [{'Source': "BIDim", 'tablename':"BIDim_DM_T_FCT_CLAIMS_DIAG", 'tbl_primarykey':"CLAIM_DIAG_SEQ_NUM,CLAIM_KEY,DIAG_EFF_DT_KEY,DIAG_KEY", 'change_date': None},
{'Source': "BIDim", 'tablename':"BIDim_CL_LIFEPRO_PERSON", 'tbl_primarykey':"NAME_ID", 'change_date': None},
{'Source': "BIDim", 'tablename':"BIDim_DM_T_FCT_POLICY", 'tbl_primarykey':"POLICY_FACT_KEY", 'change_date': None},
{'Source': "BIDim", 'tablename':"BIDim_DM_T_FCT_CLAIM_STAT_DTL_SNP_MO", 'tbl_primarykey':"AS_OF_DT_KEY,CLAIM_DW_ID,CLAIM_KEY,CLAIM_STATUS_EFF_DT_KEY,CLAIM_TXN_SEQ_NUM,INSURED_KEY,POLICY_KEY", 'change_date': None},
{'Source': "BIDim", 'tablename':"BIDim_DM_T_DIM_POLICY_FORM_LKUP", 'tbl_primarykey':"POLICY_FORM", 'change_date': None},
{'Source': "BIDim", 'tablename':"BIDim_DM_T_DIM_INSURED_ADDR", 'tbl_primarykey':"INSURED_ADDR_KEY,INSURED_KEY,SEQ_NUM", 'change_date': None},
{'Source': "BIDim", 'tablename':"BIDim_DM_T_DIM_SERVICE_TYPE", 'tbl_primarykey':"SERVICE_TYPE_KEY", 'change_date': None},
{'Source': "BIDim", 'tablename':"BIDim_DM_T_DIM_INSURED", 'tbl_primarykey':"INSURED_KEY", 'change_date': None},
{'Source': "BIDim", 'tablename':"BIDim_DM_T_DIM_CLAIM_STATUS", 'tbl_primarykey':"CLAIM_STATUS_KEY", 'change_date': None},
# {'Source': "BIDim", 'tablename':"BIDim_DM_T_FCT_CLAIM_INVC_CHRG", 'tbl_primarykey':"CLAIM_DW_ID,CLAIM_KEY,INSURED_KEY,INVC_CHRG_SEQ_NUM,POLICY_KEY,REC_EFF_DT", 'change_date': None},
{'Source': "BIDim", 'tablename':"BIDim_DM_T_DIM_CLAIM_SUB_STATUS", 'tbl_primarykey':"CLAIM_SUB_STATUS_KEY", 'change_date': None},
{'Source': "BIDim", 'tablename':"BIDim_DM_T_DIM_CODE_LKUP", 'tbl_primarykey':"VALID_VALUE_CD,VALID_VALUE_CD_NM", 'change_date': None},
{'Source': "BIDim", 'tablename':"BIDim_DM_T_DIM_CLAIM", 'tbl_primarykey':"CLAIM_DW_ID,CLAIM_KEY", 'change_date': None},
{'Source': "BIDim", 'tablename':"BIDim_DM_T_DIM_POLICY_HIST", 'tbl_primarykey':"POLICY_KEY,REC_EFF_DT", 'change_date': None},
{'Source': "BIDim", 'tablename':"BIDim_DM_T_FCT_CLAIM_STAT_SNP_MO", 'tbl_primarykey':"AS_OF_DT_KEY,CLAIM_DW_ID,CLAIM_KEY,INSURED_KEY,POLICY_KEY", 'change_date': None},
# {'Source': "BIDim", 'tablename':"BIDim_DM_T_FCT_CHRG_PYMT", 'tbl_primarykey':"CHRG_PYMT_SEQ_NUM,CLAIM_DW_ID,CLAIM_KEY,INSURED_KEY,INVC_CHRG_SEQ_NUM,POLICY_KEY,REC_EFF_DT", 'change_date': None},
{'Source': "BIDim", 'tablename':"BIDim_DM_T_DIM_DIAG", 'tbl_primarykey':"DIAGNOSIS_KEY", 'change_date': None}]


try:
    s1 = apply_dq_rules(assets, 'silver_ltc_ext')
    uc_write(s1)
except Exception as e: 
    print(e)

# COMMAND ----------

assets = [{'Source': 'GLTC', 'tablename': 'GLTC_Plan', 'tbl_primarykey': 'Master_Case_Number,Class_Number,Group_Number', 'change_date': None},
{'Source': 'GLTC', 'tablename': 'GLTC_Service_Type_Lookup', 'tbl_primarykey': 'Service_Type_Code', 'change_date': None},
# {'Source': 'GLTC', 'tablename': 'GLTC_Provider - GLTC', 'tbl_primarykey': None, 'change_date': None},
{'Source': 'GLTC', 'tablename': 'GLTC_Plan_Maximums', 'tbl_primarykey': 'Plan_Maximum_ID', 'change_date': None},
{'Source': 'GLTC', 'tablename': 'GLTC_EFS_Metadata_GLTC', 'tbl_primarykey': 'Serial_Number', 'change_date': None},
{'Source': 'GLTC', 'tablename': 'GLTC_Claim_Status_Lookup', 'tbl_primarykey': 'Claim_Status_Code', 'change_date': None},
{'Source': 'GLTC', 'tablename': 'GLTC_tblServiceTypeLookup', 'tbl_primarykey': 'Service_Type_Code', 'change_date': None},
{'Source': 'GLTC', 'tablename': 'GLTC_ADL_Cert_Code_Lookup', 'tbl_primarykey': 'ADL_Cert_Code', 'change_date': None},
{'Source': 'GLTC', 'tablename': 'GLTC_Claim', 'tbl_primarykey': 'New_Claim_ID,Claim_ID', 'change_date': None},
{'Source': 'GLTC', 'tablename': 'GLTC_Claimant_Coverage_Levels', 'tbl_primarykey': 'Master_Case_Nbr,Assign_Nbr,Coverage_Eff_Dt', 'change_date': None},
{'Source': 'GLTC', 'tablename': 'GLTC_Relationship_Code_Lookup', 'tbl_primarykey': 'Relationship', 'change_date': None},
{'Source': 'GLTC', 'tablename': 'GLTC_Diagnosis_Lookup', 'tbl_primarykey': 'Code', 'change_date': None},
{'Source': 'GLTC', 'tablename': 'GLTC_Claim_Provider', 'tbl_primarykey': 'ClaimProviderKey', 'change_date': None},
{'Source': 'GLTC', 'tablename': 'GLTC_Plan_Service_Type', 'tbl_primarykey': 'Plan_Type_ID,Plan_Type_Name,Service_Type_Code', 'change_date': None},
{'Source': 'GLTC', 'tablename': 'GLTC_Claimant', 'tbl_primarykey': 'Master_Case_Nbr,Assign_Nbr', 'change_date': None},
{'Source': 'GLTC', 'tablename': 'GLTC_Provider_Notes', 'tbl_primarykey': 'Note_ID', 'change_date': None},
{'Source': 'GLTC', 'tablename': 'GLTC_Production_Data_Case_Mgr', 'tbl_primarykey': 'Serial_Number', 'change_date': None},
{'Source': 'GLTC', 'tablename': 'GLTC_Provider_GLTC_View', 'tbl_primarykey': 'Prov_Counter_Nbr,AList_Counter', 'change_date': None},
# {'Source': 'GLTC', 'tablename': 'GLTC_Payment_Data', 'tbl_primarykey': 'Claim_ID', 'change_date': None},
{'Source': 'GLTC', 'tablename': 'GLTC_ADL_Certification', 'tbl_primarykey': None, 'Claim_ID': None},
{'Source': 'GLTC', 'tablename': 'GLTC_Claim_Status', 'tbl_primarykey': 'Claim_ID,Status_Chg_Eff_Date,Claim_Status_Code', 'change_date': None},
{'Source': 'GLTC', 'tablename': 'GLTC_tblBenefitDetail', 'tbl_primarykey': 'seq_no', 'change_date': None}]

try:
    s2 = apply_dq_rules(assets, 'silver_ltc_ext')    
    uc_write(s2)
except Exception as e: 
    print(e)


assets = [{'Source': 'GLTC', 'tablename': 'CSC_T_INSURED_COVERAGE', 'tbl_primarykey': 'INSURED_COVERAGE_ID', 'change_date': None},
{'Source': 'GLTC', 'tablename': 'CSC_T_PARTY_NOTE', 'tbl_primarykey': 'PARTY_NOTE_ID', 'change_date': None}]

try:
    s3 = apply_dq_rules(assets, 'silver_ltc_ext')    
    uc_write(s3)
except Exception as e: 
    print(e)

# COMMAND ----------

assets = [{'Source': 'Care', 'tablename': 'Care_TBALANCING_AMOUNTS', 'tbl_primarykey': 'TRANS_PROC_DT_TIME,INS_ARR_TYPE_CD,TYPE_CODE,BALANCING_TAG','change_date': 'TRANS_PROC_DT_TIME,LAST_CHANGE_DT'},
{'Source': 'Care', 'tablename': 'Care_TCLIENT', 'tbl_primarykey': 'CLIENT_NBR', 'change_date': None},
{'Source': 'Care', 'tablename': 'Care_TCLIENT_MEMBER', 'tbl_primarykey': 'PERSON_ID,CLIENT_NBR', 'change_date': None},
{'Source': 'Care', 'tablename': 'Care_TCLIENT_PLCY_PLAN', 'tbl_primarykey': 'CLIENT_NBR,POLICY_NBR,PLAN_CD', 'change_date': 'CLIENT_NBR,LAST_CHANGE_DT'}, #PLAN_END_DT
{'Source': 'Care', 'tablename': 'Care_TCLIENT_POLICY', 'tbl_primarykey': 'CLIENT_NBR,POLICY_NBR', 'change_date': None},
{'Source': 'Care', 'tablename': 'Care_TCOVERAGE_LAYER', 'tbl_primarykey': 'PERSON_ID,CLIENT_NBR,COV_TYPE_CD', 'change_date': None},
{'Source': 'Care', 'tablename': 'Care_TCOVERAGE_SUMMARY', 'tbl_primarykey': 'PERSON_ID,CLIENT_NBR,COV_SUMM_SEQ_NBR', 'change_date': None},
{'Source': 'Care', 'tablename': 'Care_TCOVLAYR_PREM_HIST', 'tbl_primarykey': 'PERSON_ID,CLIENT_NBR,COV_TYPE_CD', 'change_date': None}, #REQ_REC_DT, PREM_END_DT
{'Source': 'Care', 'tablename': 'Care_TCOVSUMM_STAT_HIST', 'tbl_primarykey': 'PERSON_ID,CLIENT_NBR', 'change_date': None}, #COV_TYPE_CD, REQ_REC_DT, COV_STATUS_CD,COV_STATUS_END_DT,COV_STATUS_REAS_CD'
{'Source': 'Care', 'tablename': 'Care_TCOVSUMM_HISTORY', 'tbl_primarykey': 'PERSON_ID,CLIENT_NBR,COV_SUMM_SEQ_NBR,COVSUM_HIST_END_DT', 'change_date': None},
{'Source': 'Care', 'tablename': 'Care_TINSURED_BILL_HIST', 'tbl_primarykey': 'INSURED_PERSON_ID,PAYOR_PERSON_ID,CLIENT_NBR,BILLING_LOC_ID,BILLING_PERIOD_ID,BILLING_SEQ_NBR,BILLING_TYPE_CD', 'change_date': 'INSURED_PERSON_ID,LAST_CHANGE_DT'},
{'Source': 'Care', 'tablename': 'Care_TPERSON_ADDRESS', 'tbl_primarykey': 'PERSON_ID,ADDR_TYPE_CD,ADDR_END_DT', 'change_date': None},
{'Source': 'Care', 'tablename': 'Care_TPERSON', 'tbl_primarykey': 'PERSON_ID', 'change_date': None},
{'Source': 'Care', 'tablename': 'Care_TAPPLICANT_INSURED', 'tbl_primarykey': 'PERSON_ID,CLIENT_NBR,MBR_PERSON_ID,REL_CD,REL_END_DT', 'change_date': None},
{'Source': 'Care', 'tablename': 'Care_TPERSON', 'tbl_primarykey': 'PERSON_ID', 'change_date': None}]

try:
    s4 = apply_dq_rules(assets, 'silver_ltc_ext')    
    uc_write(s4)
except Exception as e: 
    print(e)