# Databricks notebook source
# MAGIC %run ../../utils

# COMMAND ----------

# MAGIC %run ../primarykey_utils

# COMMAND ----------

config['data_owner'] = "Amy Miskavitch"
config['business_unit'] = "Life (US)"
config['data_domain'] = "Policy"
config['rule_owner'] = "Gina Stewart"

assets = [{'Source': 'APS', 'tablename': 'datafields', 'tbl_primarykey': 'Id'},
{'Source': 'APS', 'tablename': 'aps_extract_report', 'tbl_primarykey': 'Id'},
{'Source': 'APS', 'tablename': 'codes', 'tbl_primarykey': 'Id'},
{'Source': 'APS', 'tablename': 'clientdataentries', 'tbl_primarykey': 'Id'},
{'Source': 'APS', 'tablename': 'datastatus', 'tbl_primarykey': 'Id'},
{'Source': 'APS', 'tablename': 'documentpages', 'tbl_primarykey': 'Id'},
{'Source': 'APS', 'tablename': 'datapoints', 'tbl_primarykey': 'Id'},
{'Source': 'APS', 'tablename': 'externallinks', 'tbl_primarykey': 'Id'},
{'Source': 'APS', 'tablename': 'documents', 'tbl_primarykey': 'Id'},
{'Source': 'APS', 'tablename': 'medicaldatacategories', 'tbl_primarykey': 'Id'},
{'Source': 'APS', 'tablename': 'medicalcodes', 'tbl_primarykey': 'Id'},
{'Source': 'APS', 'tablename': 'files', 'tbl_primarykey': 'Id'},
{'Source': 'APS', 'tablename': 'groups', 'tbl_primarykey': 'Id'},
{'Source': 'APS', 'tablename': 'subcategories', 'tbl_primarykey': 'Id'},
{'Source': 'APS', 'tablename': 'supportgroups', 'tbl_primarykey': 'Id'},
{'Source': 'APS', 'tablename': 'pdfpagenumlookup', 'tbl_primarykey': 'SynodexFileID'},
{'Source': 'APS', 'tablename': 'synodexfilelinkup', 'tbl_primarykey': 'SynodexFileID,FileName'},
{'Source': 'APS', 'tablename': 'aps_extract_entry_history', 'tbl_primarykey': 'SynodexFileID,ENTRY_DATE'},
{'Source': 'APS', 'tablename': 'reportcoverpages', 'tbl_primarykey': 'Id'}]

summary_df = apply_dq_rules(assets,'silver_aps_data')
uc_write(summary_df)
