# Databricks notebook source
# MAGIC %run ../../utils

# COMMAND ----------

# MAGIC %run ./aws_primarykey_utils

# COMMAND ----------

assets = [{'Source':'aws','tablename':'annuityctr/delta','tbl_primarykey':'contactid'}
]

# COMMAND ----------

config = {
"container": 'gold',
"parent_dir": 'aws/snapshot/incremental/consumption',
"asset_name": '',
"work_stream": "PrimaryKeys",
"data_system": "aws"
}

configure_spark()

# COMMAND ----------

summary_df = apply_dq_rules(assets, **config)

# COMMAND ----------

config['asset_name'] = 'annuityctr'
save_parquet_results(None, summary_df, **config)
