# Databricks notebook source
# MAGIC %run ../../utils

# COMMAND ----------

# MAGIC %run ./annuityctr

# COMMAND ----------

# MAGIC %run ./aws_combined

# COMMAND ----------

# MAGIC %run ./ins_salesctr

# COMMAND ----------

# MAGIC %run ./lifectr

# COMMAND ----------

# MAGIC %run ./ltcctr

# COMMAND ----------

# MAGIC %run ./nbopsctr
