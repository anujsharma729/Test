# Databricks notebook source
# MAGIC %run ../../utils

# COMMAND ----------

# MAGIC %run ../primarykey_utils

# COMMAND ----------

config['data_owner'] = "Amy Miskavitch"
config['business_unit'] = "Life (US)"
config['data_domain'] = "Policy"
config['rule_owner'] = "Gina Stewart"

assets = [{'Source': 'DTCPostIssueModel', 'tablename': 'AclEntries', 'tbl_primarykey': None},
{'Source': 'DTCPostIssueModel', 'tablename': 'Acls', 'tbl_primarykey': None},
{'Source': 'DTCPostIssueModel', 'tablename': 'APSOrigins', 'tbl_primarykey': None},
{'Source': 'DTCPostIssueModel', 'tablename': 'CancerTypes', 'tbl_primarykey': None},
{'Source': 'DTCPostIssueModel', 'tablename': 'CaseChanges', 'tbl_primarykey': None},
{'Source': 'DTCPostIssueModel', 'tablename': 'LifestyleImpairments', 'tbl_primarykey': None},
{'Source': 'DTCPostIssueModel', 'tablename': 'MedicalImpairments', 'tbl_primarykey': None},
{'Source': 'DTCPostIssueModel', 'tablename': 'Misreps', 'tbl_primarykey': None},
{'Source': 'DTCPostIssueModel', 'tablename': 'PostIssueContainerChanges', 'tbl_primarykey': None},
{'Source': 'DTCPostIssueModel', 'tablename': 'PostIssueContainerHistoryEntries', 'tbl_primarykey': None},
{'Source': 'DTCPostIssueModel', 'tablename': 'UWDecisions', 'tbl_primarykey': None},
{'Source': 'DTCPostIssueModel', 'tablename': 'TobaccoUses', 'tbl_primarykey': None},
{'Source': 'DTCPostIssueModel', 'tablename': 'CaseHistoryEntries', 'tbl_primarykey': 'Id'},
{'Source': 'DTCPostIssueModel', 'tablename': 'Cases', 'tbl_primarykey': 'Id'},
{'Source': 'DTCPostIssueModel', 'tablename': 'PostIssueContainerHistoryEntries', 'tbl_primarykey': 'Id'},
{'Source': 'DTCPostIssueModel', 'tablename': 'PostIssueContainers', 'tbl_primarykey': 'Id'}]

summary = apply_dq_rules(assets,'silver_dtcpostissuemodel')
uc_write(summary)
