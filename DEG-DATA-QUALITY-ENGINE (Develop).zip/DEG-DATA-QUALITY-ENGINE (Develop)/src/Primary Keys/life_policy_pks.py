# Databricks notebook source
# MAGIC %run ../utils

# COMMAND ----------

# MAGIC %run ./primarykey_utils

# COMMAND ----------

config['business_unit'] = 'Life (US)'
config['data_domain'] = 'Policy'
config['data_owner'] = 'Amy Miskavitch'
config['rule_owner'] = 'Kathy C MacDonald'

assets = [
{'Source': 'PT', 'tablename': 'PT_PTDIMAGT', 'tbl_primarykey': 'FE_POLICY,FE_SUFFIX,FE_AGENT,FE_SCHEDULE,FE_MANAGER_CODE'},
{'Source': 'PT', 'tablename': 'PT_PTDIMFIX', 'tbl_primarykey': 'FE_POLICY'},
{'Source': 'PT', 'tablename': 'PT_PTDIMLIF', 'tbl_primarykey': 'FE_POLICY,FE_SUFFIX,FE_RIDERNO'},
{'Source': 'PT', 'tablename': 'PT_PTDTTLB', 'tbl_primarykey': 'TTLB_POL_NUMBER'},
{'Source': 'PT', 'tablename': 'PT_PTDTTLL', 'tbl_primarykey': 'TTLL_POL_NUMBER'},
{'Source': 'PT', 'tablename': 'PT_PTDTTLN', 'tbl_primarykey': 'TTLN_POL_NUMBER,TTLN_CLIENT_ROLE'},
{'Source': 'PT', 'tablename': 'PT_PTDTTLA', 'tbl_primarykey': 'TTLA_POL_NUMBER,TTLA_CLIENT_ROLE'}]
try:
    s1 = apply_dq_rules(assets, 'silver_pt')    
    uc_write(s1)
except Exception as e: 
    print(e)

# COMMAND ----------

assets = [
{'Source': 'PS', 'tablename': 'PS_SPS10E33_01', 'tbl_primarykey': 'EMPOLNO'},
{'Source': 'PS', 'tablename': 'PS_SPS10E33_01_A01', 'tbl_primarykey': 'EMPOLNO,occurs'},
{'Source': 'PS', 'tablename': 'PS_SPS10E33_01_A02', 'tbl_primarykey': 'EMPOLNO,occurs'},
{'Source': 'PS', 'tablename': 'PS_SPS10E33_01_A05', 'tbl_primarykey': 'EMPOLNO,occurs'},
{'Source': 'PS', 'tablename': 'PS_SPS10E33_01_A06', 'tbl_primarykey': 'EMPOLNO,occurs'},
{'Source': 'PS', 'tablename': 'PS_SPS10E33_01_A07', 'tbl_primarykey': 'EMPOLNO,occurs'},
{'Source': 'PS', 'tablename': 'PS_SPS10E33_01_A08', 'tbl_primarykey': 'EMPOLNO,occurs'},
{'Source': 'PS', 'tablename': 'PS_SPS10E33_01_A09', 'tbl_primarykey': 'EMPOLNO,occurs'},
{'Source': 'PS', 'tablename': 'PS_SPS10E33_02', 'tbl_primarykey': 'EMPOLNO'},
{'Source': 'PS', 'tablename': 'PS_SPS10E33_02_A01', 'tbl_primarykey': 'EMPOLNO,occurs'},
{'Source': 'PS', 'tablename': 'PS_SPS10E33_02_A02', 'tbl_primarykey': 'EMPOLNO,occurs'}
]

try:
    s2 = apply_dq_rules(assets, 'silver_ps')    
    uc_write(s2)
except Exception as e: 
    print(e)


assets = [{'Source': 'tai', 'tablename': 's_policy_life_reins_tt', 'tbl_primarykey': 'EXT_POLICY,EXT_PLC,EXT_CO'}]

try:
    s3 = apply_dq_rules(assets, 'silver_tai')    
    uc_write(s3)
except Exception as e: 
    print(e)

# COMMAND ----------

config['data_owner'] = 'Chad Edwards'
config['business_unit'] = 'Annuities'
config['data_domain'] = 'Claims'
config['rule_owner'] = 'Wendy Merrifield'

assets = [{'Source': 'vtgods', 'tablename': 'tblDailyInforceExtract', 'tbl_primarykey': 'COMPANY_CODE,MASTER_ID'},
{'Source': 'vtgods', 'tablename': 'tblDailyPlcyValRsrv', 'tbl_primarykey': 'COMPANY_CODE,POLICY_NUMBER'},
{'Source': 'vtgods', 'tablename': 'tblDrctry', 'tbl_primarykey': 'CoCd,DrctryId'},
{'Source': 'vtgods', 'tablename': 'tblFAVDesc', 'tbl_primarykey': 'CoCd,FAVCd,EffctvDt'},
{'Source': 'vtgods', 'tablename': 'tblFndDesc', 'tbl_primarykey': 'FndNum'},
{'Source': 'vtgods', 'tablename': 'tblLOBDesc', 'tbl_primarykey': 'LOBCd'},
{'Source': 'vtgods', 'tablename': 'tblNAPymnt', 'tbl_primarykey': 'CoCd,MstrID,FileCd'},
{'Source': 'vtgods', 'tablename': 'tblPADthTrx', 'tbl_primarykey': 'CoCd,MstrId,FileCd'},
{'Source': 'vtgods', 'tablename': 'tblPADthTrxCPayee', 'tbl_primarykey': 'COMPANY_CODE,MASTER_ID,FILE_CODE,OCCURENCE_NO'},
{'Source': 'vtgods', 'tablename': 'tblPlanDesc', 'tbl_primarykey': 'PlanCd,CoCd'},
{'Source': 'vtgods', 'tablename': 'tblPlcy', 'tbl_primarykey': 'CoCd,PlcyNum'},
{'Source': 'vtgods', 'tablename': 'tblRiderDescription', 'tbl_primarykey': 'COMPANY_CODE,RIDER_CODE,RIDER_IND'},
{'Source': 'vtgods', 'tablename': 'tblRoles', 'tbl_primarykey': 'CoCd,PlcyNum,RoleCd,DrctryCoCd,DrctryId'},
{'Source': 'vtgods', 'tablename': 'tblSrrndrCTrx', 'tbl_primarykey': 'CoCd,PlcyNum,SeqNum,EntryNum'},
{'Source': 'vtgods', 'tablename': 'tblTAFullSrrndr', 'tbl_primarykey': 'CoCd,MstrId,FileCd'},
{'Source': 'vtgods', 'tablename': 'tblTBPartSrrndr', 'tbl_primarykey': 'CoCd,MstrId,FileCd'},
{'Source': 'vtgods', 'tablename': 'tblValtn', 'tbl_primarykey': 'CoCd,PlcyNum,FndNum'}]

try:
    s4 = apply_dq_rules(assets, 'silver_vtgods')    
    uc_write(s4)
except Exception as e: 
    print(e)
