# Databricks notebook source
# MAGIC %run ../utils

# COMMAND ----------

# MAGIC %run ./PowerBI_Utils/

# COMMAND ----------

configure_spark()
spark.conf.set("fs.azure.account.key.dlsmfceus2aaihubprd01.dfs.core.windows.net","databricks-prod-secret" )
import os
from pyspark.sql import Row


# COMMAND ----------

def read_asset_logging():
    path = f"abfss://dataquality@{ENV['storage_account']}.dfs.core.windows.net/KPI/data_quality_asset_logging"
    files = dbutils.fs.ls(path)
    csvfile = [file for file in files if "csv" in file.name]
    # print(csvfile[0].path)
    df = read_asset_csv(csvfile[0].path)
    return df

# COMMAND ----------

dir = 'abfss://purview@dlsmfceus2aaihubprd01.dfs.core.windows.net/Bulk_Upload_Process/Purview_Output_Files/Dated_Metadata_Extracts'
output = dbutils.fs.ls(dir)
most_recent = '2024-07'
for file in output:
    try:
        date = datetime.strptime(file.name.split('US_')[1].split('.csv')[0], "%m_%Y").strftime("%Y-%m")
        if date > most_recent:
            most_recent = date
            filepath = file.path
    except Exception as e:
        print(f"filepath {e}")

print(filepath)
df = spark.read.csv(filepath, header=True, inferSchema=True)
df = df.filter(df['managed_asset'] == 'Managed')
df = df.select('collection_name','asset_name', 'managed_asset')
df = df.withColumn('System Name', f.split(df['collection_name'], '/').getItem(1)).drop('collection_name', 'managed_asset').withColumnRenamed('asset_name', 'Asset Name')
# display(df)
    
        

# COMMAND ----------

dq_assets = read_asset_logging()
df = df.join(dq_assets, df['Asset Name'] == dq_assets['asset_name'], 'left_outer')
# display(df)
save_parquet_results(df)
