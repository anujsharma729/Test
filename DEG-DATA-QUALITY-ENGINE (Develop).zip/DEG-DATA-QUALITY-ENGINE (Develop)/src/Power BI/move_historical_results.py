# Databricks notebook source

df = spark.sql(f"SELECT * FROM usdo_uat_catalog.data_quality.dq_summary_legacy").distinct()
df.write.mode("append").option("appendSchema", "true").saveAsTable(f"usdo_prod_catalog.data_quality.dq_summary")

# COMMAND ----------

