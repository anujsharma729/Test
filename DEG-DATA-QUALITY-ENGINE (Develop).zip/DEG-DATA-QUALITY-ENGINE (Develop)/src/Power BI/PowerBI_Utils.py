# Databricks notebook source
# MAGIC %run ../utils

# COMMAND ----------

def value_counts(df, column):
    value_counts_df = df.groupBy(column).count().orderBy(f.col("Count").desc(),f.asc(column))
    display(value_counts_df)
    return value_counts_df

# COMMAND ----------

def save_parquet_results(df):
    df.write.parquet(f"abfss://dataquality@{ENV['storage_account']}.dfs.core.windows.net/KPI/DQControlKPI/{TIMESTAMP}")

