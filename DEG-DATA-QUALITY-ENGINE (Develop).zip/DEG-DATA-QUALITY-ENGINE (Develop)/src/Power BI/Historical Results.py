# Databricks notebook source
# MAGIC %run ../utils

# COMMAND ----------

from collections import defaultdict

def value_counts(df, column):
    value_counts_df = df.groupBy(column).count().orderBy(f.col("Count").desc(),f.asc(column))
    display(value_counts_df)
    return value_counts_df

def trim(df):
    for column in df.columns:
        df = df.withColumn(column, f.ltrim(f.rtrim(df[column])))
    return df

def format_summary(df):
    df = df.withColumn('DQ Dimension', f.when(df['Column Name'].contains('Conformity'), 'Conformity').otherwise(df['DQ Dimension']))
    df = df.withColumn('Column Name', f.when(df['Column Name'].contains('Conform'), f.split(df['Column Name'], " Conformity").getItem(0)).otherwise(df['Column Name']))
    df = df.withColumn('Asset Name', f.when(df['Asset Name'] == 'Tayseller', 'AGENCY_PRODUCER').otherwise(df['Asset Name']))

    df = df.withColumn('Data Quality Rule', f.when(f.lower(df['Data Quality Rule']).contains('contains po box information'), 'Must Not Contain PO Box Information')
    .when(df['Data Quality Rule'].contains('Must Not Contain PO Box InFormation'), 'Must Not Contain PO Box Information')
    .when(df['Data Quality Rule'].contains('Must not have same repeating Number'), 'Must Not Contain Only Repeating Numbers')
    .when(df['Data Quality Rule'].contains('Valid Address'), 'Must Contain Valid Address')
    .when(df['Data Quality Rule'].contains('Must be complete'), 'Must Contain Valid Address')
    .when(df['Data Quality Rule'].contains('Invalid Format'), 'Must Contain Valid Format')
    .when(df['Data Quality Rule'].contains('Retail or Group present'), 'Must Contain Retail or Group')
    .when(df['Data Quality Rule'].contains('Must contain Valid Address format'), 'Must Adhere to Address Format')
    .when(df['Data Quality Rule'].contains('Must contain Valid Address format or contain ATT or PO Box'), 'Must Adhere to Address Format')
    .when(df['Data Quality Rule'].contains('Must Adhere to Expected Format YYYYMMDD'), 'Must Adhere to Expected Format YYYY-MM-DD')
    .when(df['Data Quality Rule'].contains('Must Adhere to Phone Number Format (1231231234, 123-123-1234, (123) 123-1234, (123)123-1234)'), 'Must Adhere to Phone Number Format (1231231234)').when(df['Data Quality Rule'].contains('®'), 'Must Not Contain Any Invalid Punctuation').otherwise(df['Data Quality Rule']))

    df = df.filter(~(df['Column Name'].contains("MEDICARE_PROVIDER_NUMBER")))
    df = df.filter(df['Data Quality Rule'].isNotNull())
    df = df.filter(~(df['Data Quality Rule'].contains('Contains Valid Entry')))
    df = df.withColumn('DQ Dimension', f.initcap(df["DQ Dimension"]))
    df = df.withColumn('Data System', f.when(df['Data System'] == 'Dbo', "VTGODS").otherwise(df['Data System']))
    return df

# COMMAND ----------

def replace_must(column):
    return f.regexp_replace(column, r'(?i)\bmust\b', '%Must')
    
def cleanup_columns(df, dicts):
    system_name = dicts['System Name'].split('/')[0]
    asset_name = dicts['Asset Name'].split('/')[0]
    
    if 'Rule Description' in df.columns:
        df = df.withColumn('Rule Description', replace_must(df['Rule Description']))
        df = df.withColumn('Column Name', f.split(df['Rule Description'], '%').getItem(0)).withColumn('Data Quality Rule', f.split(df['Rule Description'], '%').getItem(1)).drop('Rule Description')

        df = df.withColumn('DQ Dimension', f.when(f.lower(df['Data Quality Rule']).contains('complete'), "Completeness").when(f.lower(df['Data Quality Rule']).contains('unique'), "Unqiueness").when(f.lower(df['Data Quality Rule']).contains('consistency'), "Consistency").when(f.lower(df['Data Quality Rule']).contains('accur'), "Accuracy").when(f.lower(df['Data Quality Rule']).contains('conform'), "Conformity").otherwise(None))
        
        df = df.withColumn('Data System', f.lit(system_name)).withColumn('Asset Name', f.lit(asset_name))

    if 'Column Name' not in df.columns:
        df = df.withColumn('Column Name', f.split(df['Data Quality Rule'], ': ').getItem(1)).withColumn('DQ Dimension', f.split(df['Data Quality Rule'], ': ').getItem(0))
        df = df.withColumn('Data Quality Rule', f.when(df['DQ Dimension'].contains('Completeness'), 'Must Contain Non Null Value').when(df['DQ Dimension'].contains('Unique'), 'Must Contain Unique Value'))
        df = df.withColumn('DQ Dimension', f.when(df['Column Name'].contains('Conformity'), 'Conformity').otherwise(df['DQ Dimension']))
        df = df.withColumn('Column Name', f.when(df['Column Name'].contains('Accuracy:'), f.split(df['Column Name'], ": ").getItem(1)).when(df['Column Name'].contains('Conform'), f.split(df['Column Name'], " ").getItem(0)).otherwise(df['Column Name']))

    return df

def format_summaries(file, dicts):
    summary_columns = ['Scan Date','Workstream', 'Data System', 'Asset Name', 'Column Name', 'DQ Dimension', 'Data Quality Rule', 'Total Rows', 'Rows Passed', 'Rows Failed', 'Score', 'Thresholds']
    scan_date = file.split('/')[-2][:10]
    if 'Historical_Trends' not in file:
        file = file + 'scan_summary/' 
    try: 
        df = spark.read.parquet(f"{file}", header ='True')
        if ('Rule Description' in df.columns) or ('Column Name' not in df.columns):
            df = df.withColumn('Scan Date', f.lit(scan_date))
            df = cleanup_columns(df, dicts)
        elif 'Historical_Trends' in file:
            df = df.withColumn('DQ Dimension', f.when(df['Column Name'].contains('Accuracy:'),'Accuracy').when(df['Column Name'].contains('Conform'), 'Conformity').otherwise(df['DQ Dimension']))
            df = df.withColumn('Column Name', f.when(df['Column Name'].contains('Accuracy:'), f.split(df['Column Name'], ": ").getItem(1)).when(df['Column Name'].contains('Conform'), f.split(df['Column Name'], " ").getItem(0)).otherwise(df['Column Name']))
        df = df.withColumn('Workstream', f.lit(dicts["Workstream"].split("/")[0])).withColumn('Thresholds', f.lit(0)).withColumn('Total Rows',df['Rows Passed'] + df['Rows Failed']).drop('Rows Ignored')

        df = df.withColumn("Score", f.when(f.col("Score") > 1, (f.col("Score") / 100).cast("decimal(10,4)")).otherwise(f.col("Score").cast("decimal(10,4)")))
        df = df.select(summary_columns)
        df = trim(df)
        return df
    except Exception as e:
        # print(f"Error reading Parquet file: {e}")
        # print(file)
        return None


# COMMAND ----------

dir = f"abfss://dataquality@{ENV['storage_account']}.dfs.core.windows.net/"
exclude = ['KPI/', '_logs/', '_templates/', '_test/', 'PowerBI/', 'ltc_ext/','PrimaryKeys/', 'DTCRepositoryModel/']
output = dbutils.fs.ls(dir)
workstreams = []
files = []
summary_df = None
for file in output:
    if file.name not in exclude:
        workstreams += [file.name]
for ws in workstreams:
    output = dbutils.fs.ls(dir + ws)
    for sys in output:
        if ('.' in sys.name) | ('test' in sys.name) | ('2' in sys.name): continue
        assets = dbutils.fs.ls(dir + ws + sys.name)
        for asset in assets:
            files.append({"Workstream" : ws , "System Name": sys.name, "Asset Name": asset.name})

grouped_data = defaultdict(list)
for record in files:
    # system_name = record['System Name']
    ws = record['Workstream']
    grouped_data[ws].append(record)

for ws, records in grouped_data.items():
    summary = None
    print(f"Processing system: {ws}")
    if ws in['Wellness/']:
        for file in records:
            path = dir + file['Workstream'] + file['System Name'] + file['Asset Name']
            output = dbutils.fs.ls(path)
            for value in output:
                summary = format_summaries(value.path, file)
                if summary is not None:
                    if summary_df is None: summary_df = summary
                    else: 
                        summary_df = summary_df.union(summary)
        df = format_summary(summary_df).distinct()
        df.write.parquet(f"abfss://dataquality@{ENV['storage_account']}.dfs.core.windows.net/{file['Workstream']}/Historical_Results/scan_summary/")
        print("Save Asset: ", ws)
    

# COMMAND ----------


