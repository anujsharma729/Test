# Databricks notebook source
# MAGIC %run ./Consolidate_Summary_Utils

# COMMAND ----------

# invalid_folders = ['_test/', '_templates/', '_logs/', 'Consolidated_Summaries/', 'KPI/', 'IDMC_CDQ']
# valid_folders = get_valid_folder(invalid_folders)
valid_folders = ['CAR', 'Claims_Annuities', 'Distributor', 'LTC_AntiFraud', 'PrimaryKeys', 'Producer', 'Wellness']

# COMMAND ----------

consolidate(valid_folders)