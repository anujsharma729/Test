# Databricks notebook source
# MAGIC %run ../../utils

# COMMAND ----------

configure_spark()
from functools import reduce
from pyspark.sql import DataFrame, Row
import re
from datetime import datetime

# COMMAND ----------

container = 'dataquality'
adls_path = f"abfss://{container}@{ENV['storage_account']}.dfs.core.windows.net/"
consolidated_DQ_path = adls_path + 'Consolidated_Summaries/BDQ_Consolidated_Summaries'
logs_path = adls_path + 'Consolidated_Summaries/BDQ_Logs'
sample_data_path = adls_path + 'Consolidated_Summaries/BDQ_Utility_Sample_Data'

file_filter_mod_date = 1724976000000 #(2024-08-30)
if ENV['storage_account'] == 'ihubgovuatadbstadls':
    file_filter_mod_date = 1724976000000 #(2024-08-30)
elif ENV['storage_account'] == 'dlsmfceus2aaihubprd01':
    file_filter_mod_date = 1725622200000 #(2024-09-06 11:30)


# COMMAND ----------

common_schema = StructType([
    StructField('Scan_Date', StringType(), True),
    StructField('Workstream', StringType(), True), 
    StructField('Data_System', StringType(), True),
    StructField('Asset_Name', StringType(), True),
    StructField('Column_Name', StringType(), True),
    StructField('DQ_Dimension', StringType(), True),
    StructField('Data_Quality_Rule', StringType(), True),
    StructField('Total_Rows', StringType(), True),
    StructField('Rows_Passed', StringType(), True),
    StructField('Rows_Failed', StringType(), True),
    StructField('Score', DoubleType(), True),
    StructField('Thresholds', IntegerType(), True)])

logs_schema = StructType([
    StructField('Path', StringType(), True),
    StructField('Capture_Date', TimestampType(), True),
    StructField('Status', StringType(), True)])

# COMMAND ----------

def get_valid_folder(invalid_folders):
    container_dir = dbutils.fs.ls(adls_path)
    valid_folders = [i.name for i in container_dir if i.isDir() and i.name not in invalid_folders]
    return valid_folders

# COMMAND ----------

def get_paths(folder):
    scan_summary_paths = []
    stack = [adls_path + folder]

    while stack:
        current_path = stack.pop()
        for file_info in dbutils.fs.ls(current_path):
            if file_info.isDir():
                if "scan_summary" in file_info.path:
                    if dbutils.fs.ls(file_info.path)[2].modificationTime >= file_filter_mod_date:
                        scan_summary_paths.append(file_info.path)
                else:
                    stack.append(file_info.path)

    return scan_summary_paths

# COMMAND ----------

# get new paths of data to be appended into the consolidated data

def get_new_paths(folder):
    all_paths = get_paths(folder)
    new_paths = []
    try:
        dbutils.fs.ls(logs_path)
        capture_logs = spark.read.format('delta').load(logs_path)
        existing_paths = capture_logs.select('Path').rdd.flatMap(lambda x: x).collect()
        new_paths = [path for path in all_paths if path not in existing_paths]

    except Exception as logpath_error:
        if "java.io.FileNotFoundException" in str(logpath_error):
            new_paths = all_paths
        else:
            print(f'Error: {logpath_error}')
    
    return new_paths

# COMMAND ----------

def capture_summaries(new_paths, folder=None):
    consolidated_scan_summary = None
    logs = []
    for path in new_paths:
        try:
            df = spark.read.parquet(path)
            df = df.withColumn('Score', f.col('Score').cast(DoubleType()))
            df = df.withColumn('Thresholds', f.col('Thresholds').cast(IntegerType()))
            consolidated_scan_summary = df if consolidated_scan_summary is None else consolidated_scan_summary.union(df)
            logs.append((path, datetime.now(), 'Success'))
        except:
            logs.append((path, datetime.now(), 'Failed'))
            print(f"Error reading {path}")

    new_logs_df = spark.createDataFrame(logs, logs_schema)

    if consolidated_scan_summary is not None:
        cleaned_columns = [re.sub(r'[ ,;{}()\n\t=]', '_', col) for col in consolidated_scan_summary.columns]
        consolidated_scan_summary = consolidated_scan_summary.toDF(*cleaned_columns)
    
    if consolidated_scan_summary is not None:
        print(f'{folder}: scan summary captured.')

    return consolidated_scan_summary, new_logs_df

# COMMAND ----------

# def ensure_sample_data(sample_paths):
#     if len(sample_paths) > 0:
#         sample_data = None
#         try:
#             dbutils.fs.ls(sample_data_path)
#             print('Utility sample data ALREADY EXISTS.')
#             pass
#         except Exception as e:
#             if 'java.io.FileNotFoundException' in str(e):
#                 for path in sample_paths:
#                     df = spark.read.parquet(path)
#                     df = df.withColumn('Score', f.col('Score').cast(DoubleType()))
#                     df = df.withColumn('Thresholds', f.col('Thresholds').cast(IntegerType()))
#                     sample_data = df if sample_data is None else sample_data.union(df)

#                 cleaned_columns = [re.sub(r'[ ,;{}()\n\t=]', '_', col) for col in sample_data.columns]
#                 sample_data = sample_data.toDF(*cleaned_columns)
#                 sample_data.write.format('delta').mode('overwrite').save(sample_data_path)
#             print('Utility sample data CREATED.')
#     else:
#         pass

# COMMAND ----------

def save_consolidated_data_and_logs(consolidated_scan_summary, new_logs_df, folder=None):
    if consolidated_scan_summary is not None:
        try:
            dbutils.fs.ls(f"{consolidated_DQ_path}/_delta_log/")
            consolidated_scan_summary.write.format('delta').mode('append').save(consolidated_DQ_path)
            print(f'{folder}: Consolidated scan summaries saved.')

            try:
                dbutils.fs.ls(f"{logs_path}/_delta_log/")
                new_logs_df.write.format('delta').mode('append').save(logs_path)
            except Exception as log_e:
                if "java.io.FileNotFoundException" in str(log_e):
                    new_logs_df.write.format('delta').mode('overwrite').save(logs_path)
                else:
                    print(f'Failed to append or overwrite logs (append - try block). Error: {log_e}')

        except Exception as e:
            if "java.io.FileNotFoundException" in str(e):
                consolidated_scan_summary.write.format('delta').mode('overwrite').save(consolidated_DQ_path)
                print(f'Delta table does not exist, {consolidated_DQ_path} created.')
                print(f'{folder}: Consolidated scan summaries saved.')

                try:
                    dbutils.fs.ls(f"{logs_path}/_delta_log/")
                    new_logs_df.write.format('delta').mode('append').save(logs_path)
                except Exception as log_e:
                    if "java.io.FileNotFoundException" in str(log_e):
                        new_logs_df.write.format('delta').mode('overwrite').save(logs_path)
                    else:
                        print(f'Failed to append or overwrite logs (overwrite - filenotfound except block). Error: {log_e}')

            else:
                print(f'Failed to do append or overwrite operation (overwrite - else except block). Error: {e}')
    
    else:
        pass

# COMMAND ----------

def consolidate(valid_folders):
    all_new_paths = []
    for folder in valid_folders:
        new_paths = get_new_paths(folder)
        all_new_paths.extend(new_paths)
        consolidated_scan_summary, new_logs_df = capture_summaries(new_paths=new_paths, folder=folder)
        save_consolidated_data_and_logs(consolidated_scan_summary, new_logs_df, folder=folder)

    if len(all_new_paths) > 0:
        print('Consolidated data saved.')
        try:
            df = spark.read.format('delta').load(consolidated_DQ_path)
            df.repartition(1).write.format("delta").mode("overwrite").save(consolidated_DQ_path)
            print('Consolidated delta table repartitioned')

            df_logs = spark.read.format('delta').load(logs_path)
            df_logs.repartition(1).write.format("delta").mode("overwrite").save(logs_path)
            print('Logs delta table repartitioned')

        except Exception as e:
            print(f'Repartition Error: {e}')

    else:
        print('No new data to consolidate.')