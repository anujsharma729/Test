# Databricks notebook source
# MAGIC %run ./../utils

# COMMAND ----------

df = spark.sql(f"SELECT * FROM usdo_prod_catalog.data_quality.dq_summary").distinct()

# COMMAND ----------

for column in ['source_system', 'asset_name', 'workstream', 'data_quality_rule']:
    df = df.withColumn(column, f.lower(df[column]))

df.write.mode("overwrite").option("overwriteSchema", "true").saveAsTable(f"usdo_prod_catalog.data_quality.dq_summary")

# COMMAND ----------

