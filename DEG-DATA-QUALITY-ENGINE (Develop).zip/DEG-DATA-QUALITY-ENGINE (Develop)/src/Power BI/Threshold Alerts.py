# Databricks notebook source
# MAGIC %run ../utils

# COMMAND ----------

configure_spark()

# COMMAND ----------

from office365.runtime.auth.authentication_context import AuthenticationContext
from office365.runtime.auth.user_credential import UserCredential
from office365.sharepoint.files.creation_information import FileCreationInformation
from office365.sharepoint.client_context import ClientContext
from office365.runtime.auth.client_credential import ClientCredential
from office365.sharepoint.files.file import File 
import pandas as pd
import tempfile
import io
import os

# COMMAND ----------

def get_summary_files(workstream):
    base_folder = f"abfss://dataquality@{ENV['storage_account']}.dfs.core.windows.net/{workstream}"
    tables = []

    for system_dir in dbutils.fs.ls(base_folder):
        if system_dir.isDir():
            system_name = system_dir.name 
            for table_dir in dbutils.fs.ls(system_dir.path):
                if table_dir.isDir():
                    table_name = table_dir.name
                    latest_summary_files = get_most_recent_files(table_dir.path)
                    if latest_summary_files:
                        tables.append(latest_summary_files)
    return tables

def get_most_recent_files(base_folder):
    latest_folder = None
    latest_date = datetime.min
    for item in dbutils.fs.ls(base_folder):
        if item.isDir():
            try: 
                folder_date = datetime.strptime(item.name.split('/')[0][:10], '%Y-%m-%d')
                if folder_date > latest_date:
                    latest_date = folder_date
                    latest_folder = item.path

            except ValueError:
                continue

    if latest_folder:
        files_in_latest_folder = [file.path for file in dbutils.fs.ls(latest_folder) if 'scan_summary' in file.name]
        return files_in_latest_folder
    else:
        return None

def get_cde_below_threshold(workstreams):
    most_recent_summary_files = []
    summary = None
    for ws in workstreams:
        most_recent_files = get_summary_files(ws)
        for value in most_recent_files:
            most_recent_summary_files.append(value[0])

    for value in most_recent_summary_files:
        try:
            df = spark.read.parquet(value, header ='True')
            df = df.select('Scan Date', 'Workstream','Data System', 'Asset Name', 'Column Name', 'Data Quality Rule', 'Score', 'Thresholds')
            if summary is None:
                summary = df
            else: summary = summary.union(df)
        except:
            pass

    summary = summary.filter(summary['Thresholds'] > summary['Score'])
    return summary
    

    # summary = summary.drop('Data Quality Rule', 'DQ Dimension', 'Rows Passed', 'Rows Failed')
    # results = summary.select('Column Name').distinct().rdd.map(lambda row: row[0]).collect()
    # df = summary.groupBy('Column Name', 'Scan Date','Asset Name', 'Data System', 'Workstream').agg(f.round(f.sum(summary['Score'])/f.count(summary['Score']), 4).alias('Average Score'))

    # abfss_path = f"abfss://dataquality@{ENV['storage_account']}.dfs.core.windows.net/KPI/Data Quality Thresholds.csv"
    # thresholds = spark.read.format("com.databricks.spark.csv").option("header", 'true').option("inferSchema", "true").load(abfss_path)
    # df = df.join(thresholds, (df['Column Name'] == thresholds['Row Labels']) & (df['Asset Name'] == thresholds['Table Name']), 'left_outer')
    # df = df.select('Scan Date', 'Workstream', 'Data System', 'Asset Name','Column Name', 'Average Score', 'Threshold').filter(df['Average Score'] < df['Threshold'])
    # return df

# COMMAND ----------

def print_folder_contents(ctx, folder_url):
    try:
        folder = ctx.web.get_folder_by_server_relative_url(folder_url)
        fold_names = []
        sub_folders = folder.files #Replace files with folders for getting list of folders
        ctx.load(sub_folders)
        ctx.execute_query()

        for s_folder in sub_folders:
            fold_names.append(s_folder.properties["Name"])
        return fold_names

    except Exception as e:
        print('Problem printing out library contents: ', e)

def save_csv_to_sp(df, ctx):
    # Create a temporary CSV file from the DataFrame
    with tempfile.NamedTemporaryFile(mode='w+', suffix='.csv', delete=False) as tmp:
        df.to_csv(tmp.name, index=False)
        new_file_path = "/tmp/dq_score.csv"
    os.rename(tmp.name, new_file_path)

    # Upload the renamed file to SharePoint
    with open(new_file_path, 'rb') as file_content:
        file_info = FileCreationInformation()
        file_info.content = file_content.read()
        file_info.url = os.path.basename(new_file_path)  # Extract the new file name
        file_info.overwrite = True
        target_folder = ctx.web.get_folder_by_server_relative_url(folder)
        upload_file = target_folder.upload_file(file_info.url, file_info.content).execute_query()

    print(f'File {file_info.url} uploaded to SharePoint folder {folder}')
    os.remove(new_file_path)

# COMMAND ----------

def get_ws():
    ws =[]
    dir = f"abfss://dataquality@{ENV['storage_account']}.dfs.core.windows.net/"
    output = dbutils.fs.ls(dir)
    for w in output:
        if w.name not in ['KPI/', 'PowerBI/', '_logs/', '_templates/', '_test/']:
            ws.append(w.name)
    return ws

def authenticate_sharepoint():
    client_id = ENV['client_id']
    client_secret = dbutils.secrets.get(scope=ENV['scope'], key=ENV['key'])
    sharepoint_site_url = 'https://mfc.sharepoint.com/sites/USDG'
    client_credentials = ClientCredential(client_id, client_secret)
    ctx = ClientContext(sharepoint_site_url).with_credentials(client_credentials)
    return ctx

# COMMAND ----------

workstreams = get_ws()
df = get_cde_below_threshold(workstreams)
df = df.toPandas()
df["Score"] = df['Score'] * 100
df['Score'] = df['Score'].apply(lambda x: f'{x:.2f}%')
df["Thresholds"] = df['Thresholds'] * 100
df['Thresholds'] = df['Thresholds'].apply(lambda x: f'{x:.2f}%')

ctx = authenticate_sharepoint()
url = 'https://mfc.sharepoint.com/sites/USDG'
folder = '/sites/USDG/DataQuality/Thresholds%20&%20Alerts/DQResult'
# filelist_shrpt=print_folder_contents(ctx, folder)
# current = read_from_sp(ctx, 'DQ_SCORE.csv', folder)
save_csv_to_sp(df, ctx)

# COMMAND ----------

# def authenticate_sharepoint(username, password, url, folder):
#     ctx_auth = AuthenticationContext(url)
#     if ctx_auth.acquire_token_for_user(username, password):
#         ctx = ClientContext(url, ctx_auth)
#         web = ctx.web
#         ctx.load(web)
#         ctx.execute_query()
#         print('Authenticated into sharepoint as: ',web.properties['Title'])
#         return ctx
#     else:
#         print(ctx_auth.get_last_error())
#         return None
