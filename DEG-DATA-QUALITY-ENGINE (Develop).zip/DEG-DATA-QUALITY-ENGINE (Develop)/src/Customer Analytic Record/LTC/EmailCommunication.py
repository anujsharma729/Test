# Databricks notebook source
# MAGIC %run ../../utils

# COMMAND ----------

configure_spark()
config = {
"container": 'usdo-car-gold-pii',
"parent_dir": 'car/ltc',
"asset_name": '',
"work_stream": "CAR",
"data_system": "CAR_LTC",
"data_owner": "Charles Wiegersma",
"business_unit": "Long Term Care (US)",
"data_domain": "Customer", 
"rule_owner": "Bunty Ramrakhyani"
}

config['asset_name'] = 'EmailCommunication'
df = read_asset_delta(**config)

#print(df.count())

# COMMAND ----------

config['asset_name'] = 'ServiceRequest/TASK'
df2 = read_asset_delta(**config)


# COMMAND ----------

df2 = df2.select("ServiceRequestId").distinct()
df2 = df2.withColumnRenamed('ServiceRequestId', 'TaskServiceRequestId')

# COMMAND ----------

df = df.join(df2.withColumn("flag",f.lit(True)), df.ServiceRequestActivityId==df2.TaskServiceRequestId, "left").select(df.columns + ["flag"])
df = df.fillna(False, subset=["flag"])
print(df.count())


# COMMAND ----------

#Consistency
df = df.withColumn('Consistency: ServiceRequestActivityId',
   f.when(df['ServiceRequestActivityId'] == '', 'fail: Must not contain empty strings') 
    .when(df['flag'] == 'True', 'pass: ServiceRequestActivityId exists in ServiceRequest') 
    .otherwise('fail: ServiceRequestActivityId exists in ServiceRequest'))
df = df.drop("flag")

# COMMAND ----------

df = df.withColumn('EmailCreatedDate', f.trim(df['EmailCreatedDate'].substr(1,19)))
df = df.withColumn('EmailMessageDate', f.trim(df['EmailMessageDate'].substr(1,19)))
df = df.withColumn('LastUpdateTimeStamp', f.trim(df['LastUpdateTimeStamp'].substr(1,19)))
df = df.withColumn('UpdateTimeStamp', f.trim(df['UpdateTimeStamp'].substr(1,19)))
df = df.withColumn('CurationTimestamp', f.trim(df['CurationTimestamp'].substr(1,19)))
df = df.withColumn('SrcSystemModStamp', f.trim(df['SrcSystemModStamp'].substr(1,19)))

# COMMAND ----------

#THRESHOLD
threshold_scores = {
    'ServiceRequestId': [
        {'Rule': 'Must Contain Non Null Value', 'Threshold': 0.15}
    ],
    'ServiceRequestActivityId': [
        {'Rule': 'ServiceRequestActivityId exists in ServiceRequest', 'Threshold': 0.85}
    ],
    'Subject': [
        {'Rule': 'Must Contain Non Null Value', 'Threshold': 0.95}
    ],
    'LatestEmailTranscript_unscrubbed': [
        {'Rule': 'Must Contain Non Null Value', 'Threshold': 0.97}
    ],
    'EmailTranscript_unscrubbed': [
        {'Rule': 'Must Contain Non Null Value', 'Threshold': 0.97}
    ],
    'SenderName': [
        {'Rule': 'Must Contain Non Null Value', 'Threshold': 0.99}
    ],
    'RequestCreatedBy': [
        {'Rule': 'Must Contain a Value', 'Threshold': 1.0}
    ],
    'CustomerPartyId_AccountMDMId': [
        {'Rule': 'Must Contain a Value', 'Threshold': 0.15}
    ],
    'PolicyNo': [
        {'Rule': 'Must Contain Non Null Value', 'Threshold': 0.10}
    ]

}

# COMMAND ----------

#UNIQUENESS CHECK
uniqueness_check_columns = ['EmailCommunicationId']
for column in uniqueness_check_columns:
    df = uniqueness_check(df,column)

# COMMAND ----------

#COMPLETENESS CHECK
completeness_check_columns = ['EmailCommunicationId','ServiceRequestId','Segment', 'Country', 'IssuingCompany','BusinessUnit', 'LineofBusiness','CCSourceSystem','Channel','EmailDirection', 'EmailCreatedDate', 'EmailMessageDate','Subject','LatestEmailTranscript_unscrubbed','EmailTranscript_unscrubbed','SenderType','SenderName','EmailStatus','LastUpdateTimeStamp','UpdateTimeStamp','CurationTimestamp','SrcSystemModStamp','PolicyNo']
for column in completeness_check_columns:
    df = completeness_check(df, column)

# COMMAND ----------

#CONFORMITY CHECK

df = df.withColumn('Conformity: Segment',
    f.when((df['Segment'] == 'US'), 'pass: Value should be US')
    .otherwise('fail: Value should be US'))

df = df.withColumn('Conformity: Country',
    f.when((df['Country'] == 'US'), 'pass: Value should be US')
    .otherwise('fail: Value should be US'))

df = df.withColumn('Conformity: IssuingCompany',
    f.when((df['IssuingCompany'] == 'JohnHancock'), 'pass: Value should be JohnHancock')
    .otherwise('fail: Value should be JohnHancock'))

df = df.withColumn('Conformity: BusinessUnit',
    f.when((df['BusinessUnit'] == 'LTC'), 'pass: Value should be LTC')
    .otherwise('fail: Value should be LTC'))

df = df.withColumn('Conformity: LineofBusiness',
    f.when((df['LineofBusiness'] == 'Insurance'), 'pass: Value should be Insurance')
    .otherwise('fail: Value should be Insurance'))

df = df.withColumn('Conformity: EmailDirection',
    f.when((df['EmailDirection'] == 'INBOUND')|(df['EmailDirection'] == 'OUTBOUND'), 'pass: Must have value inbound or outbound')
    .otherwise('fail: Must have value inbound or outbound')) 

df = df.withColumn('Conformity: EmailCreatedDate',
    f.when(df['EmailCreatedDate'].rlike(r'^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$'), 'pass: Must conform to DateTime Format')
    .otherwise('fail: Must conform to DateTime Format'))

df = df.withColumn('Conformity: EmailMessageDate',
    f.when(df['EmailMessageDate'].rlike(r'^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$'), 'pass: Must conform to DateTime Format')
    .otherwise('fail: Must conform to DateTime Format'))

df = df.withColumn('Conformity: SenderType',
    f.when((df['SenderType'] == 'Customer')|(df['SenderType'] == 'Agent'), 'pass: Must have value Customer or Agent')
    .when(df['SenderType'].isNull(),'fail: Must Contain Non Null Value')
    .otherwise('fail: Must have value Customer or Agent'))

df = df.withColumn('Conformity: LatestEmailScope',
    f.when((df['LatestEmailScope'] == 'Internal')|(df['LatestEmailScope'] == 'External'), 'pass: Must have value Internal or External')
    .when(df['LatestEmailScope'].isNull(),'fail: Must Contain Non Null Value')
    .otherwise('fail: Must have value Internal or External'))

sender_email_conditions = (df['SenderEmailAddress.EmailAddress'].rlike(r'^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$'))
sender_null_conditions = (df['SenderEmailAddress.EmailAddress'].isNull())
df = df.withColumn('Conformity: SenderEmailAddress',
    f.when(sender_email_conditions, 'pass: Must be in email id format')
    .when(sender_null_conditions,'fail: Must Contain Non Null Value')
    .otherwise('fail: Must be in email id format'))



# COMMAND ----------

df = df.withColumn("ToEmailAddress",f.explode("ReceiverEmailAddress.ToEmailAddress")) \
.withColumn("CCEmailAddress", f.explode("ReceiverEmailAddress.CCEmailAddress"))\
.withColumn("BCCEmailAddress", f.explode("ReceiverEmailAddress.BCCEmailAddress"))

# COMMAND ----------

 df = df.withColumn('Conformity: ReceiverEmailAddressToEmailAddress',
    f.when((df['ToEmailAddress'].rlike(r'^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$')), 'pass: Must be in email id format')
    .when(df['ToEmailAddress'].isNull(),'fail: Must Contain Non Null Value')
    .otherwise('fail: Must be in email id format'))

# COMMAND ----------

 df = df.withColumn('Conformity: ReceiverEmailAddressCCEmailAddress',
    f.when((df['CCEmailAddress'].rlike(r'^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$')), 'pass: Must be in email id format')
    .when(df['CCEmailAddress'].isNull(),'fail: Must Contain Non Null Value')
    .otherwise('fail: Must be in email id format'))

# COMMAND ----------

 df = df.withColumn('Conformity: ReceiverEmailAddressBCCEmailAddres',
    f.when((df['BCCEmailAddress'].rlike(r'^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$')), 'pass: Must be in email id format')
    .when(df['BCCEmailAddress'].isNull(),'fail: Must Contain Non Null Value')
    .otherwise('fail: Must be in email id format'))

# COMMAND ----------

#Check ReplyToEmailCommunicationId exists in EmailCommunicationId

df_check = df.select("EmailCommunicationId").distinct().withColumnRenamed("EmailCommunicationId","EmailCommunicationId_unique")
broadcast_col2_df = f.broadcast(df_check)
df = df.join(broadcast_col2_df.withColumn("flag",f.lit(True)), df["ReplyToEmailCommunicationId"] == broadcast_col2_df["EmailCommunicationId_unique"] , "left").select(df.columns + ["flag"])
df = df.fillna(False, subset=["flag"])


# COMMAND ----------

df = df.withColumn('Conformity: ReplyToEmailCommunicationId',
    f.when(df['flag'] == 'True', 'pass: Exist in EmailCommunication')
    .when((df['ReplyToEmailCommunicationId'].isNull()) & (df['flag'] == 'False'), 'pass: Exist in EmailCommunication')
    .otherwise('fail: Exist in EmailCommunication'))

df = df.withColumn('Conformity: EmailSeqNumByParentId',
    f.when(df['EmailSeqNumByParentId'] >= 0, 'pass: Value must be greater than or equal to 0')
    .when(df['EmailSeqNumByParentId'].isNull(), 'fail: Must Contain Non Null Value')
    .otherwise('fail: Value must be greater than or equal to 0'))

df = df.withColumn('Conformity: RequestCreatedBy',
    f.when(df['RequestCreatedBy.Email'].rlike(r'.+'), 'pass: Must Contain a Value')
    .otherwise('fail: Must Contain a Value'))

df = df.withColumn('Conformity: LastUpdateTimeStamp',
    f.when(df['LastUpdateTimeStamp'].rlike(r'^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$'), 'pass: Must conform to DateTime Format')
    .otherwise('fail: Must conform to DateTime Format'))

df = df.withColumn('Conformity: UpdateTimeStamp',
    f.when(df['UpdateTimeStamp'].rlike(r'^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$'), 'pass: Must conform to DateTime Format')
    .otherwise('fail: Must conform to DateTime Format'))

df = df.withColumn('Conformity: CurationTimestamp',
    f.when(df['CurationTimestamp'].rlike(r'^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$'), 'pass: Must conform to DateTime Format')
    .otherwise('fail: Must conform to DateTime Format'))

df = df.withColumn('Conformity: SrcSystemModStamp',
    f.when(df['SrcSystemModStamp'].rlike(r'^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$'), 'pass: Must conform to DateTime Format')
    .otherwise('fail: Must conform to DateTime Format'))

df = df.withColumn('Conformity: CustomerPartyId_AccountMDMId',
    f.when(df['CustomerPartyId.AccountMDMId'].rlike(r'^\d+$'), 'pass: Must Contain a Value')
    .otherwise('fail: Must Contain a Value'))



# COMMAND ----------

config['asset_name'] = 'EmailCommunication'
summary_df = get_summary(df,threshold_scores, **config)
failed_rows_df = get_failed_rows(df)

# COMMAND ----------

#display(summary_df)
# display(failed_rows_df)

# COMMAND ----------

save_parquet_results(failed_rows_df, summary_df, **config)
