# Databricks notebook source
# MAGIC %run ../../utils

# COMMAND ----------

configure_spark()
config = {
"container": 'usdo-car-gold-pii',
"parent_dir": 'car/ltc',
"asset_name": '',
"work_stream": "CAR",
"data_system": "CAR_LTC"
}

config['asset_name'] = 'Claims'
df = read_asset_delta(**config)

# COMMAND ----------

display(df)

# COMMAND ----------

df = df.withColumn('CurationTimestamp', f.trim(df['CurationTimestamp'].substr(1,19)))

# COMMAND ----------

# #THRESHOLD
# threshold_scores = {
#     'PartyRole': [
#         {'Rule':'Must Contain Non Null Value', 'Threshold': 0.2}
#     ],
#     'PolicyNo': [
#         {'Rule': 'Must Contain Non Null Value', 'Threshold': 0.15}
#     ],
#     'PartyId': [
#         {'Rule': 'Must Contain a Value', 'Threshold': 0.2}
#     ],
#     'CustomerPartyId': [
#         {'Rule': 'Must Contain a Value', 'Threshold': 0.6}
#     ],
#     'ProductId Code': [
#         {'Rule': 'Must Contain a Value', 'Threshold': 0.15}
#     ],
#     'ProductId Name': [
#         {'Rule': 'Must Contain a Value', 'Threshold': 0.15}
#     ],
#     'AddlServiceRequestJoinId SFPolicyId': [
#         {'Rule': 'Must Contain a Value', 'Threshold': 0.1}
#     ],
#     'AddlServiceRequestJoinId SFPolicyOwnerId': [
#         {'Rule': 'Must Contain a Value', 'Threshold': 0.1}
#     ],
# }

# COMMAND ----------

#UNIQUENESS CHECK
uniqueness_check_columns = ['ClaimId']
for column in uniqueness_check_columns:
    df = uniqueness_check(df,column)

# COMMAND ----------

#COMPLETENESS CHECK
completeness_check_columns = ['ClaimParentId', 'PolicyNo', 'CurationTimestamp']
for column in completeness_check_columns:
    df = completeness_check(df, column)

# COMMAND ----------

#CONFORMITY CHECK

df = df.withColumn('Conformity: Segment',
    f.when((df['Segment'] == 'US'), 'pass: Value should be US')
    .otherwise('fail: Value should be US'))

df = df.withColumn('Conformity: Country',
    f.when((df['Country'] == 'US'), 'pass: Value should be US')
    .otherwise('fail: Value should be US'))

df = df.withColumn('Conformity: IssuingCompany',
    f.when(((df['Segment'] == 'US') & (df['IssuingCompany'] == 'JohnHancock')), 'pass: For US segment, value should be JohnHancock')
    .when(((df['Segment'] == 'Canada') & (df['IssuingCompany'] == 'Manulife')), 'pass: For Canada segment, value should Manulife')
    .when(((df['Segment'] == 'GWAM') & ((df['IssuingCompany'] == 'JohnHancock') |(df['IssuingCompany'] == 'Manulife'))), 'pass: For GWAM, value should be JohnHancock or Manulife')
    .otherwise('fail: Value does not reflect correct segment')) 

df = df.withColumn('Conformity: BusinessUnit',
    f.when((df['BusinessUnit'] == 'LTC'), 'pass: Value should be LTC')
    .otherwise('fail: Value should be LTC'))

df = df.withColumn('Conformity: LineofBusiness',
    f.when((df['LineofBusiness'] == 'Insurance'), 'pass: Value should be Insurance')
    .otherwise('fail: Value should be Insurance'))


# COMMAND ----------

summary_df = get_summary(df, None, **config)
failed_rows_df = get_failed_rows(df)

# COMMAND ----------

display(summary_df)

# COMMAND ----------

display(failed_rows_df)

# COMMAND ----------

# save_parquet_results(failed_rows_df, summary_df, **config)
