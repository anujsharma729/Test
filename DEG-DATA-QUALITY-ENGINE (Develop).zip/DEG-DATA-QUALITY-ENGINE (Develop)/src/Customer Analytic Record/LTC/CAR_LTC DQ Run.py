# Databricks notebook source
# MAGIC %run ../../utils

# COMMAND ----------

# MAGIC %run ./ServiceRequest

# COMMAND ----------

# MAGIC %run ./TelephoneCommunication

# COMMAND ----------

# MAGIC %run ./EmailCommunication
