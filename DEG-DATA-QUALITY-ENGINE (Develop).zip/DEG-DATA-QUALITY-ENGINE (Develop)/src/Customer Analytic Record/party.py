# Databricks notebook source
# MAGIC %run ../utils

# COMMAND ----------

# MAGIC %run ../rules

# COMMAND ----------

# MAGIC %run ./car_utils

# COMMAND ----------

config['container'] = 'usdo-car-gold-non-pii'
config['parent_dir'] = 'US/PARTY'
config['data_system'] = 'car_party'

#PartyPublicDemographics
config['asset_name'] = 'PartyPublicDemographics'
df1 = read_asset_delta(**config)

df1 = format_dates(df1, 'CurationTimestamp')
completeness_check_columns = ['PostalCode', 'EmploymentRateCharacteristics', 'HealthInsuranceCoverageCharacteristics', 'HousingOccupancyCharacteristics', 'MaritalStatusCharacteristics', 'HouseHoldCharacteristics']
for column in completeness_check_columns:
    df1 = completeness_check(df1, column)

df1 = conformity_digit(df1, 'EstimatedIncome')
df1 = conformity_digit(df1, 'EstimatedMedianAge')
df1 = conformity_digit(df1, 'TotalPopulation')
df1 = conformity_digit(df1, 'CensusYear')
df1 = conformity_datetime(df1, 'CurationTimestamp')

s1 = get_summary(df1, None, **config)

#PartyNonPII
config['asset_name'] = 'PartyNonPII'
df2 = read_asset_delta(**config)

df2 = format_dates(df2, 'CurationTimestamp')
for column in ['PartyId', 'PartyType', 'PersonOrgCode', 'PostalCode' ]:
    df2 = completeness_check(df2, column)
df2 = conformity_digit(df2, 'YearOfBirth')
df2 = conformity_datetime(df2, 'CurationTimestamp')
s2 = get_summary(df2, None, **config)

#PartyIdentifiersNonPII
config['asset_name'] = 'PartyIdentifiersNonPII'
df3 = read_asset_delta(**config)

df3 = format_dates(df3, 'CurationTimestamp')
for column in ['PartyId', 'BusinessUnit', 'EnterpriseId' ]:
    df3 = completeness_check(df3, column)
df3 = conformity_datetime(df3, 'CurationTimestamp')

s3 = get_summary(df3, None, **config)
summary_df = s1.union(s2).union(s3)

# COMMAND ----------

display(summary_df)