# Databricks notebook source
# MAGIC %run ../../utils

# COMMAND ----------

configure_spark()
config = {
"container": 'usdo-car-gold-pii',
"parent_dir": 'car/b2b/nbops',
"asset_name": '',
"work_stream": "CAR",
"data_system": "CAR_B2B"
}

config['asset_name'] = 'TelephoneCommunication'
df = read_asset_delta(**config)


# COMMAND ----------

df2 = spark.read.format('delta').load(f'abfss://usdo-car-gold-pii@{PROD_ADLS_STORAGE_ACCOUNT}.dfs.core.windows.net/car/life/ServiceRequest/TASK')

df2 = df2.select("ServiceRequestJoinId").distinct()


# COMMAND ----------

df = df.join(df2.withColumn("flag",f.lit(True)), "ServiceRequestJoinId", "left").select(df.columns + ["flag"])
df = df.fillna(False, subset=["flag"])

#Consistency
df = df.withColumn('Consistency: ServiceRequestJoinId',
   f.when(df['ServiceRequestJoinId'] == '', 'fail: Must not contain empty strings') 
    .when(df['flag'] == 'True', 'pass: ServiceRequestJoinId exists in ServiceRequest') 
    .otherwise('fail: ServiceRequestJoinId exists in ServiceRequest'))
df = df.drop("flag")

# COMMAND ----------

df = df.withColumn('CurationTimestamp', f.trim(df['CurationTimestamp'].substr(1,19)))
df = df.withColumn('UpdateTimeStamp', f.trim(df['UpdateTimeStamp'].substr(1,19)))

# COMMAND ----------

#THRESHOLD
threshold_scores = {
    'CallQueue': [
        {'Rule':'Must Contain Non Null Value', 'Threshold': 0.6}
    ],
    'CustomAttributes': [
        {'Rule': 'Must Contain Non Null Value', 'Threshold': 1.0}
    ],
    'CARCustomAttributes': [
        {'Rule': 'Must Contain Non Null Value', 'Threshold': 1.0}
    ],
    'CCAgentUserName': [
        {'Rule': 'Must have valid username', 'Threshold': 0.5},
        {'Rule': 'Must Contain Non Null Value', 'Threshold': 0.5}
    ]
}

# COMMAND ----------

#UNIQUENESS CHECK
uniqueness_check_columns = ['TelephoneCommunicationId']
for column in uniqueness_check_columns:
    df = uniqueness_check(df,column)

# COMMAND ----------

#COMPLETENESS CHECK
completeness_check_columns = ['ServiceRequestJoinId', 'Segment', 'Country', 'IssuingCompany','BusinessUnit', 'CallCentreCodeName', 'Channel', 'CallDirection' ,'CallQueue','CustomAttributes', 'CARCustomAttributes']
for column in completeness_check_columns:
    df = completeness_check(df, column)


# COMMAND ----------

#CONFORMITY CHECK

df = df.withColumn('Conformity: Segment',
    f.when(((df['Segment'] == 'US') | (df['Segment'] == 'Canada') | (df['Segment'] == 'GWAM')) , 'pass: Value should reflect proper segment')
    .otherwise('fail: Value should reflect proper segment'))

df = df.withColumn('Conformity: Country',
    f.when(((df['Segment'] == 'US') & (df['Country'] == 'US')), 'pass: For US segment, value should be US')
    .when(((df['Segment'] == 'Canada') & (df['Country'] == 'Canada')), 'pass: For Canada segment, value should Canada')
    .when(((df['Segment'] == 'GWAM') & ((df['Country'] == 'US') |(df['Country'] == 'Canada'))), 'pass: For GWAM, value should be US or Canada')
    .otherwise('fail: Value does not reflect correct segment'))  

df = df.withColumn('Conformity: IssuingCompany',
    f.when(((df['Segment'] == 'US') & (df['IssuingCompany'] == 'JohnHancock')), 'pass: For US segment, value should be JohnHancock')
    .when(((df['Segment'] == 'Canada') & (df['IssuingCompany'] == 'Manulife')), 'pass: For Canada segment, value should Manulife')
    .when(((df['Segment'] == 'GWAM') & ((df['IssuingCompany'] == 'JohnHancock') |(df['IssuingCompany'] == 'Manulife'))), 'pass: For GWAM, value should be JohnHancock or Manulife')
    .otherwise('fail: Value does not reflect correct segment'))     

df = df.withColumn('Conformity: BusinessUnit',
    f.when((df['BusinessUnit'] == 'LIFE'), 'pass: Value should be LIFE')
    .otherwise('fail: Value should be LIFE'))

df = df.withColumn('Conformity: Channel',
    f.when((df['Channel'] == 'VOICE')|(df['Channel'] == 'CHAT'), 'pass: Must have value Voice or Chat')
    .when(df['Channel'].isNull(),'fail: Must Contain Non Null Value')
    .otherwise('fail: Must have value Voice or Chat'))

df = df.withColumn('Conformity: CallInitiationTimestamp',
    f.when(df['CallInitiationTimestamp'].rlike(r'^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$'), 'pass: Must conform to DateTime Format')
    .otherwise('fail: Must conform to DateTime Format'))

df = df.withColumn('Conformity: CallConnectedToSystemTimestamp',
    f.when(df['CallConnectedToSystemTimestamp'].rlike(r'^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$'), 'pass: Must conform to DateTime Format')
    .otherwise('fail: Must conform to DateTime Format'))

df = df.withColumn('Conformity: CallInteractionDuration', 
    f.when(df['CallInteractionDuration'].rlike(r'^\d*[1-9]\d*$'), 'pass: Must be a positive numeric value')                              
    .otherwise('fail: Must be a positive numeric value'))

df = df.withColumn('Conformity: Language',
    f.when(((df['Country'] == 'US') & (df['Language'] == 'English')), 'pass: For US, value should be English')
    .when(((df['Country'] == 'Canada') & ((df['Language'] == 'English') |(df['Language'] == 'French'))), 'pass: For Canada, value should be English or French')
    .otherwise('fail: For US, value should be English. For Canada, value should be English or French'))


# COMMAND ----------

#CONFORMITY CHECK

#Conditions for CallAbandoned Column
conditions = (df['CallAbandoned.IVR_Abandoned'].cast('string').isin('true', 'false')) &\
    (df['CallAbandoned.Queue_Abandoned'].cast('string').isin('true', 'false')) &\
    (df['CallAbandoned.Abandoned'].cast('string').isin('true', 'false'))

df = df.withColumn('Conformity: CallAbandoned',
    f.when(conditions, 'pass: Sub-attributes must contain value True or False')
    .otherwise('fail: Sub-attributes must contain value True or False'))

# COMMAND ----------

#CONFORMITY CHECK

df = df.withColumn('Conformity: CallTransfersByInitialContact', 
    f.when(df['CallTransfersByInitialContact'].rlike(r'^\d*[1-9]\d*$'), 'pass: Must be a positive numeric value')                   
    .when((df['CallTransfersByInitialContact'] == '')|(df['CallTransfersByInitialContact'].isNull()),'fail: Must Contain Non Null Value')           
    .otherwise('fail: Must be a positive numeric value'))


df = df.withColumn('Conformity: CCAgentUserName',
    f.when(df['CCAgentUserName'].rlike(r'^[A-Za-z09._%+-]+@MFCGD\.COM$'), 'pass: Must have valid username')
    .when(df['CCAgentUserName'].isNull(), 'fail: Must Contain Non Null Value')  
    .otherwise('fail: Must have valid username'))


# COMMAND ----------

#CONFORMITY CHECK

#Conditions for CCSentiment Column
conditions2 = (df['CCSentiment.AGENT'] >= -10.0) & (df['CCSentiment.CUSTOMER'] >=-10.0)

df = df.withColumn('Conformity: CCSentiment',
    f.when(conditions2, 'pass: Agent and Customer must have numeric values')
    .otherwise('fail: Agent and Customer must have numeric values'))

# COMMAND ----------

conditions_agent = (df['CCSentiment.AGENT'] >= -10.0)
df = df.withColumn('Conformity: CCSentiment Agent',
    f.when(conditions_agent, 'pass: Agent must have numeric values')
    .otherwise('fail: Agent must have numeric values'))

# COMMAND ----------

conditions_customer = (df['CCSentiment.CUSTOMER'] >= -10.0)
df = df.withColumn('Conformity: CCSentiment Customer',
    f.when(conditions_customer, 'pass: Customer must have numeric values')
    .otherwise('fail: Customer must have numeric values'))

# COMMAND ----------

#CONFORMITY CHECK

df = df.withColumn('Conformity: LastUpdateTimeStamp',
    f.when(df['LastUpdateTimeStamp'].rlike(r'^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$'), 'pass: Must conform to DateTime Format')
    .otherwise('fail: Must conform to DateTime Format'))

df = df.withColumn('Conformity: UpdateTimeStamp',
    f.when(df['UpdateTimeStamp'].rlike(r'^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$'), 'pass: Must conform to DateTime Format')
    .otherwise('fail: Must conform to DateTime Format'))

df = df.withColumn('Conformity: CurationTimestamp',
    f.when(df['CurationTimestamp'].rlike(r'^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$'), 'pass: Must conform to DateTime Format')
    .otherwise('fail: Must conform to DateTime Format'))

# COMMAND ----------

config['asset_name'] = 'B2B_NBOps_TelephoneCommunication'

# COMMAND ----------

summary_df = get_summary(df, threshold_scores, **config)
failed_rows_df = get_failed_rows(df)

# COMMAND ----------

save_parquet_results(failed_rows_df, summary_df, **config)
