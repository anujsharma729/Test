# Databricks notebook source
# MAGIC %run ../../utils

# COMMAND ----------

configure_spark()
config = {
"container": 'usdo-car-gold-pii',
"parent_dir": 'car/life',
"asset_name": '',
"work_stream": "CAR",
"data_system": "CAR_Life",
"data_owner": "Amy Miskavitch",
"business_unit": "Life (US)",
"data_domain": "Customer", 
"rule_owner": "Bunty Ramrakhyani"

}

# df = spark.read.format('delta').load(f'abfss://usdo-car-gold-pii@{PROD_ADLS_STORAGE_ACCOUNT}.dfs.core.windows.net/car/life/ServiceRequest/TASK')

config['asset_name'] = 'ServiceRequest/TASK'
df = read_asset_delta(**config)

# COMMAND ----------

config['asset_name'] = 'TelephoneCommunication'
df2 = read_asset_delta(**config)

# COMMAND ----------

join_column = 'TelephoneCommunicationId'
joined_df = df.join(df2.select(join_column), df[join_column] == df2[join_column], 'left')

# COMMAND ----------

joined_df= consistency_check(joined_df, 'TelephoneCommunication','TelephoneCommunicationId','TelephoneCommunicationId','Segment', 'Segment')

# COMMAND ----------

df = df.withColumn('RequestCreatedDate', f.trim(df['RequestCreatedDate'].substr(1,19)))
df = df.withColumn('CurationTimestamp', f.trim(df['CurationTimestamp'].substr(1,19)))

# COMMAND ----------

#THRESHOLD
threshold_scores = {
    'PartyRole': [
        {'Rule':'Must Contain Non Null Value', 'Threshold': 0.2}
    ],
    'PolicyNo': [
        {'Rule': 'Must Contain Non Null Value', 'Threshold': 0.15}
    ],
    'PartyId': [
        {'Rule': 'Must Contain a Value', 'Threshold': 0.2}
    ],
    'CustomerPartyId': [
        {'Rule': 'Must Contain a Value', 'Threshold': 0.6}
    ],
    'ProductId Code': [
        {'Rule': 'Must Contain a Value', 'Threshold': 0.15}
    ],
    'ProductId Name': [
        {'Rule': 'Must Contain a Value', 'Threshold': 0.15}
    ],
    'AddlServiceRequestJoinId SFPolicyId': [
        {'Rule': 'Must Contain a Value', 'Threshold': 0.1}
    ],
    'AddlServiceRequestJoinId SFPolicyOwnerId': [
        {'Rule': 'Must Contain a Value', 'Threshold': 0.1}
    ],
}

# COMMAND ----------

#UNIQUENESS CHECK
uniqueness_check_columns = ['ServiceRequestId']
for column in uniqueness_check_columns:
    df = uniqueness_check(df,column)

# COMMAND ----------

#COMPLETENESS CHECK
completeness_check_columns = ['CRMObjectType', 'PartyRole', 'PartyType', 'PolicyNo', 'RequestStatus', 'SrcSystemModStamp', 'ServiceRequestJoinId']
for column in completeness_check_columns:
    df = completeness_check(df, column)

# COMMAND ----------

#CONFORMITY CHECK

df = df.withColumn('Conformity: Segment',
    f.when((df['Segment'] == 'US'), 'pass: Value should be US')
    .otherwise('fail: Value should be US'))

df = df.withColumn('Conformity: Country',
    f.when((df['Country'] == 'US'), 'pass: Value should be US')
    .otherwise('fail: Value should be US'))

df = df.withColumn('Conformity: IssuingCompany',
    f.when(((df['Segment'] == 'US') & (df['IssuingCompany'] == 'JohnHancock')), 'pass: For US segment, value should be JohnHancock')
    .when(((df['Segment'] == 'Canada') & (df['IssuingCompany'] == 'Manulife')), 'pass: For Canada segment, value should Manulife')
    .when(((df['Segment'] == 'GWAM') & ((df['IssuingCompany'] == 'JohnHancock') |(df['IssuingCompany'] == 'Manulife'))), 'pass: For GWAM, value should be JohnHancock or Manulife')
    .otherwise('fail: Value does not reflect correct segment')) 

df = df.withColumn('Conformity: BusinessUnit',
    f.when((df['BusinessUnit'] == 'LifeInsurance'), 'pass: Value should be LifeInsurance')
    .otherwise('fail: Value should be LifeInsurance'))

df = df.withColumn('Conformity: LineofBusiness',
    f.when((df['LineofBusiness'] == 'Insurance'), 'pass: Value should be Insurance')
    .otherwise('fail: Value should be Insurance'))

df = df.withColumn('Conformity: RequestCreatedDate',
    f.when(df['RequestCreatedDate'].rlike(r'^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$'), 'pass: Must conform to DateTime Format')
    .otherwise('fail: Must conform to DateTime Format'))

df = df.withColumn('Conformity: PartyId',
    f.when(df['PartyId.SFContactID'].rlike(r'.+'), 'pass: Must Contain a Value')
    .otherwise('fail: Must Contain a Value'))

df = df.withColumn('Conformity: CustomerPartyId',
    f.when(df['CustomerPartyId.AccountMDMId'].rlike(r'.+'), 'pass: Must Contain a Value')
    .otherwise('fail: Must Contain a Value'))

df = df.withColumn('Conformity: ProductId Code',
    f.when(df['ProductId.Code'].rlike(r'.+'), 'pass: Must Contain a Value')
    .otherwise('fail: Must Contain a Value'))

df = df.withColumn('Conformity: ProductId Name',
    f.when(df['ProductId.Name'].rlike(r'.+'), 'pass: Must Contain a Value')
    .otherwise('fail: Must Contain a Value'))

df = df.withColumn('Conformity: RequestCreatedBy',
    f.when(df['RequestCreatedBy.Email'].rlike(r'.+'), 'pass: Must Contain a Value')
    .otherwise('fail: Must Contain a Value'))

df = df.withColumn('Conformity: CurationTimestamp',
    f.when(df['CurationTimestamp'].rlike(r'^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$'), 'pass: Must conform to DateTime Format')
    .otherwise('fail: Must conform to DateTime Format'))

df = df.withColumn('Conformity: AddlServiceRequestJoinId SFPolicyId',
    f.when(df['AddlServiceRequestJoinId.SFPolicyId'].rlike(r'.+'), 'pass: Must Contain a Value')
    .otherwise('fail: Must Contain a Value'))  

df = df.withColumn('Conformity: AddlServiceRequestJoinId SFPolicyOwnerId',
    f.when(df['AddlServiceRequestJoinId.SFPolicyOwnerId'].rlike(r'.+'), 'pass: Must Contain a Value')
    .otherwise('fail: Must Contain a Value'))        

# COMMAND ----------

config['asset_name'] = 'ServiceRequest'
summary_df = get_summary(df, threshold_scores, **config)
failed_rows_df = get_failed_rows(df)

# COMMAND ----------

joined_summary = get_summary(joined_df, threshold_scores, **config )
failed_joined = get_failed_rows (joined_df)

# COMMAND ----------

summary_df = summary_df.union(joined_summary)

# COMMAND ----------

save_parquet_results(failed_rows_df, summary_df, **config)
