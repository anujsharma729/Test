# Databricks notebook source
# MAGIC %run ../../utils

# COMMAND ----------

configure_spark()
config = {
"container": 'usdo-car-gold-pii',
"parent_dir": 'car/life',
"asset_name": '',
"work_stream": "CAR",
"data_system": "CAR_Life"
}

config['asset_name'] = 'Claims'
df = read_asset_delta(**config)

# COMMAND ----------

df = df.withColumn('CurationTimestamp', f.trim(df['CurationTimestamp'].substr(1,19)))

# COMMAND ----------

# #THRESHOLD
threshold_scores = {
    'ClaimId': [
        {'Rule':'Must Contain Unique Value', 'Threshold': 1.0}
    ],
    'ClaimParentId': [
        {'Rule': 'Must Contain Non Null Value', 'Threshold': 1.0}
    ],
    'PolicyNo': [
        {'Rule': 'Must Contain Non Null Value', 'Threshold': 1.0}
    ],
    'CurationTimestamp': [
        {'Rule': 'Must Contain Non Null Value', 'Threshold': 1.0}
    ]
}

# COMMAND ----------

#UNIQUENESS CHECK
uniqueness_check_columns = ['ClaimId']
for column in uniqueness_check_columns:
    df = uniqueness_check(df,column)

# COMMAND ----------

#COMPLETENESS CHECK
completeness_check_columns = ['ClaimParentId','PolicyNo', 'CurationTimestamp']
for column in completeness_check_columns:
    df = completeness_check(df, column)

# COMMAND ----------

#CONFORMITY CHECK

df = df.withColumn('Conformity: Segment',
    f.when((df['Segment'] == 'US'), 'pass: Value should be US')
    .otherwise('fail: Value should be US'))

df = df.withColumn('Conformity: Country',
    f.when((df['Country'] == 'US'), 'pass: Value should be US')
    .otherwise('fail: Value should be US'))

df = df.withColumn('Conformity: IssuingCompany',
    f.when(((df['Segment'] == 'US') & (df['IssuingCompany'] == 'JohnHancock')), 'pass: For US segment, value should be JohnHancock')
    .when(((df['Segment'] == 'Canada') & (df['IssuingCompany'] == 'Manulife')), 'pass: For Canada segment, value should Manulife')
    .when(((df['Segment'] == 'GWAM') & ((df['IssuingCompany'] == 'JohnHancock') |(df['IssuingCompany'] == 'Manulife'))), 'pass: For GWAM, value should be JohnHancock or Manulife')
    .otherwise('fail: Value does not reflect correct segment')) 

df = df.withColumn('Conformity: BusinessUnit',
    f.when((df['BusinessUnit'] == 'LIFE'), 'pass: Value should be LIFE')
    .otherwise('fail: Value should be LIFE'))

df = df.withColumn('Conformity: LineofBusiness',
    f.when((df['LineofBusiness'] == 'Insurance'), 'pass: Value should be Insurance')
    .otherwise('fail: Value should be Insurance'))

# COMMAND ----------

summary_df = get_summary(df, threshold_scores, **config)
failed_rows_df = get_failed_rows(df)

# COMMAND ----------

save_parquet_results(failed_rows_df, summary_df, **config)
