# Databricks notebook source
# MAGIC %run ../../utils

# COMMAND ----------

# MAGIC %run ./EmailCommunication

# COMMAND ----------

# MAGIC %run ./EmailCommunication_scrubbed

# COMMAND ----------

# MAGIC %run ./ServiceRequest

# COMMAND ----------

# MAGIC %run ./TelephoneCommunication

# COMMAND ----------

# MAGIC %run ./TelephoneCommunication_Scrubbed

# COMMAND ----------

# MAGIC %run ./Transcripts

# COMMAND ----------

# MAGIC %run ./Claims
