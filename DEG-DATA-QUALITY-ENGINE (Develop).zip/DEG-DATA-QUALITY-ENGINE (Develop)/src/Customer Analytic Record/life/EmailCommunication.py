# Databricks notebook source
# MAGIC %run ../../utils

# COMMAND ----------

from pyspark.sql.types import StringType

# COMMAND ----------

configure_spark()
config = {
"container": 'usdo-car-gold-pii',
"parent_dir": 'car/life',
"asset_name": '',
"work_stream": 'CAR',
"data_system": 'CAR_Life',
"data_owner": "Amy Miskavitch",
"business_unit": "Life (US)",
"data_domain": "Customer", 
"rule_owner": "Bunty Ramrakhyani"
}

# df = spark.read.format('delta').load(f'abfss://usdo-car-gold-pii@{PROD_ADLS_STORAGE_ACCOUNT}.dfs.core.windows.net/car/life/EmailCommunication')
config['asset_name'] = 'EmailCommunication'
df = read_asset_delta(**config)

# COMMAND ----------

config['asset_name'] = 'ServiceRequest/TASK'
df2 = read_asset_delta(**config)

# COMMAND ----------

df3 = df

# COMMAND ----------

df4 = df

# COMMAND ----------

join_column = 'ServiceRequestId'
joined_df = df.join(df2.select(join_column), df[join_column] == df2[join_column], 'left')

# COMMAND ----------

joined_df = consistency_check(joined_df, 'ServiceRequest','ServiceRequestId', 'ServiceRequestJoinId', 'Segment', 'Segment')

# COMMAND ----------

df = df.withColumn('EmailCreatedDate', f.trim(df['EmailCreatedDate'].substr(1,19)))
df = df.withColumn('EmailMessageDate', f.trim(df['EmailMessageDate'].substr(1,19)))
df = df.withColumn('LastUpdateTimeStamp', f.trim(df['LastUpdateTimeStamp'].substr(1,19)))
df = df.withColumn('UpdateTimeStamp', f.trim(df['UpdateTimeStamp'].substr(1,19)))
df = df.withColumn('CurationTimestamp', f.trim(df['CurationTimestamp'].substr(1,19)))
df = df.withColumn('SrcSystemModStamp', f.trim(df['SrcSystemModStamp'].substr(1,19)))

# COMMAND ----------

#THRESHOLD
threshold_scores = {
    'LatestEmailTranscript_scrubbed': [
        {'Rule': 'Must Contain Non Null Value', 'Threshold': 0.2}
    ],
    'EmailTranscript_unscrubbed': [
        {'Rule': 'Must Contain Non Null Value', 'Threshold': 0.97}
    ],
    'SenderName': [
        {'Rule': 'Must Contain Non Null Value', 'Threshold': 0.97}
    ],
    'EmailStatus': [
        {'Rule': 'Must Contain Non Null Value', 'Threshold': 0.99}
    ],
    'RequestCreatedBy': [
        {'Rule': 'Must Contain a Value', 'Threshold': 1.0}
    ],
    'CustomerPartyId': [
        {'Rule': 'Must Contain a Value', 'Threshold': 0.1}
    ],
    'ProductId': [
        {'Rule': 'Must Contain a Value', 'Threshold': 0.1}
    ],

}

# COMMAND ----------

#UNIQUENESS CHECK
uniqueness_check_columns = ['EmailCommunicationId']
for column in uniqueness_check_columns:
    df = uniqueness_check(df,column)

# COMMAND ----------

#COMPLETENESS CHECK
completeness_check_columns = ['EmailCommunicationId', 'Segment', 'Country', 'IssuingCompany','BusinessUnit', 'LineofBusiness', 'CCSourceSystem', 'Channel', 'EmailDirection', 'EmailCreatedDate', 'EmailMessageDate', 'Subject', 'SenderType', 'PolicyNo', 'LatestEmailTranscript_unscrubbed', 'EmailTranscript_unscrubbed', 'SenderName', 'EmailStatus' ]
for column in completeness_check_columns:
    df = completeness_check(df, column)

# COMMAND ----------

#CONFORMITY CHECK

df = df.withColumn('Conformity: Segment',
    f.when((df['Segment'] == 'US'), 'pass: Value should be US')
    .otherwise('fail: Value should be US'))

df = df.withColumn('Conformity: Country',
    f.when((df['Country'] == 'US'), 'pass: Value should be US')
    .otherwise('fail: Value should be US'))

df = df.withColumn('Conformity: IssuingCompany',
    f.when(((df['Segment'] == 'US') & (df['IssuingCompany'] == 'JohnHancock')), 'pass: For US segment, value should be JohnHancock')
    .when(((df['Segment'] == 'Canada') & (df['IssuingCompany'] == 'Manulife')), 'pass: For Canada segment, value should Manulife')
    .when(((df['Segment'] == 'GWAM') & ((df['IssuingCompany'] == 'JohnHancock') |(df['IssuingCompany'] == 'Manulife'))), 'pass: For GWAM, value should be JohnHancock or Manulife')
    .otherwise('fail: Value does not reflect correct segment')) 

df = df.withColumn('Conformity: BusinessUnit',
    f.when((df['BusinessUnit'] == 'LifeInsurance'), 'pass: Value should be LifeInsurance')
    .otherwise('fail: Value should be LifeInsurance'))

df = df.withColumn('Conformity: LineofBusiness',
    f.when((df['LineofBusiness'] == 'Insurance'), 'pass: Value should be Insurance')
    .otherwise('fail: Value should be Insurance')) 

df = df.withColumn('Conformity: EmailDirection',
    f.when((df['EmailDirection'] == 'INBOUND')|(df['EmailDirection'] == 'OUTBOUND'), 'pass: Must have value inbound or outbound')
    .when(df['EmailDirection'].isNull(),'fail: Must Contain Non Null Value')
    .otherwise('fail: Must have value inbound or outbound'))   

df = df.withColumn('Conformity: EmailCreatedDate',
    f.when(df['EmailCreatedDate'].rlike(r'^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$'), 'pass: Must conform to DateTime Format')
    .otherwise('fail: Must conform to DateTime Format'))

df = df.withColumn('Conformity: EmailMessageDate',
    f.when(df['EmailMessageDate'].rlike(r'^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$'), 'pass: Must conform to DateTime Format')
    .otherwise('fail: Must conform to DateTime Format'))

df = df.withColumn('Conformity: SenderType',
    f.when((df['SenderType'] == 'Customer')|(df['SenderType'] == 'Agent'), 'pass: Must have value Customer or Agent')
    .when(df['SenderType'].isNull(),'fail: Must Contain Non Null Value')
    .otherwise('fail: Must have value Customer or Agent'))

df = df.withColumn('Conformity: LatestEmailScope',
    f.when((df['LatestEmailScope'] == 'Internal')|(df['LatestEmailScope'] == 'External'), 'pass: Must have value Internal or External')
    .when(df['LatestEmailScope'].isNull(),'fail: Must Contain Non Null Value')
    .otherwise('fail: Must have value Internal or External'))

# COMMAND ----------

sender_email_conditions = (df['SenderEmailAddress.EmailAddress'].rlike(r'^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$'))
sender_null_conditions = (df['SenderEmailAddress.EmailAddress'].isNull())
df = df.withColumn('Conformity: SenderEmailAddress',
    f.when(sender_email_conditions, 'pass: Must be in email id format')
    .when(sender_null_conditions,'fail: Must Contain Non Null Value')
    .otherwise('fail: Must be in email id format'))



# COMMAND ----------

# email_conditions = (df['SenderEmailAddress.EmailAddress'].rlike(r'^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$')) & (df['SenderEmailAddress.EmailDomain'].rlike(r'[A-Za-z0-9.-]+\.[A-Za-z]{2,}$'))
# null_conditions = (df['SenderEmailAddress.EmailAddress'].isNull()) & (df['SenderEmailAddress.EmailDomain'].isNull())
                                                                                                                        
# df = df.withColumn('Conformity: SenderEmailAddress',
#     f.when(email_conditions, 'pass: Must have value inbound or outbound')
#     .when(null_conditions,'fail: Must Contain Non Null Value')
#     .otherwise('fail: Must have value inbound or outbound'))

# COMMAND ----------

#second version with apostrophes and $ sign in the email

# emails_conditions = (df['SenderEmailAddress.EmailAddress'].rlike(r'^[A-Za-z0-9._%+-$]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$')) & (df['SenderEmailAddress.EmailDomain'].rlike(r'[A-Za-z0-9.-]+\.[A-Za-z]{2,}$'))
# nulls_conditions = (df['SenderEmailAddress.EmailAddress'].isNull()) & (df['SenderEmailAddress.EmailDomain'].isNull())
                                                                                                                        
# df = df.withColumn('Conformity: SenderEmailAddress',
#     f.when(emails_conditions, 'pass: Must have value inbound or outbound')
#     .when(nulls_conditions,'fail: Must Contain Non Null Value')
#     .otherwise('fail: Must have value inbound or outbound'))

# COMMAND ----------

# #seperate version if needed. Can do the domain sperperate
# df = df.withColumn('Conformity: SenderEmailAddress',
#     f.when((df['SenderEmailAddress.EmailAddress'].rlike(r'^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$')), 'pass: Must have value inbound or outbound')
#     .when(df['SenderEmailAddress.EmailAddress'].isNull(),'fail: Must Contain Non Null Value')
#     .otherwise('fail: Must have value inbound or outbound'))

# COMMAND ----------

distinct_column1 = set([row['EmailCommunicationId'] for row in df4.select('EmailCommunicationId').distinct().collect()])
broadcast_values = spark.sparkContext.broadcast(distinct_column1)

def value_in_list(value):
    return value in broadcast_values.value

df4 = df4.filter(df4['ReplyToEmailCommunicationId'].isNotNull())
value_in_list_udf = f.udf(value_in_list, BooleanType())

df4 = df4.withColumn('EmailCommunicationId_New', value_in_list_udf(f.col('ReplyToEmailCommunicationId')))

df4 = df4.withColumn('Conformity: ReplyToEmailCommunicationId',
    f.when((df4['EmailCommunicationId_New'] == 'TRUE'), 'pass: Exist in EmailCommunication')
    .otherwise('fail: Exist in EmailCommunication'))

# COMMAND ----------

df3 = df3.select("*", f.explode(df3.ReceiverEmailAddress.ToEmailAddress).alias('ToEmailAddress'))

# COMMAND ----------

df3 = df3.withColumn('ToEmailAddress', f.split(df3.ToEmailAddress, ';'))
df3 = df3.select("*", f.explode(df3.ToEmailAddress).alias('ToEmailAddressNew'))
df3 = df3.withColumn('ToEmailAddressNew', f.trim(df3.ToEmailAddressNew))


# COMMAND ----------

df3 = df3.select("*", f.explode(df3.ReceiverEmailAddress.CCEmailAddress).alias('CCEmailAddress'))

# COMMAND ----------

df3 = df3.withColumn('CCEmailAddress', f.split(df3.CCEmailAddress, ';'))
df3 = df3.select("*", f.explode(df3.CCEmailAddress).alias('CCEmailAddressNew'))
df3 = df3.withColumn('CCEmailAddressNew', f.trim(df3.CCEmailAddressNew))

# COMMAND ----------

df3 = df3.select("*", f.explode(df3.ReceiverEmailAddress.BCCEmailAddress).alias('BCCEmailAddress'))

# COMMAND ----------

df3 = df3.withColumn('BCCEmailAddress', f.split(df3.BCCEmailAddress, ';'))
df3 = df3.select("*", f.explode(df3.BCCEmailAddress).alias('BCCEmailAddressNew'))
df3 = df3.withColumn('BCCEmailAddressNew', f.trim(df3.BCCEmailAddressNew))

# COMMAND ----------

 df3 = df3.withColumn('Conformity: ReceiverEmailAddressToEmailAddress',
    f.when((df3['ToEmailAddressNew'].rlike(r'^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$')), 'pass: Must be in email id format')
    .when(df3['ToEmailAddressNew'].isNull(),'fail: Must Contain Non Null Value')
    .otherwise('fail: Must be in email id format'))

# COMMAND ----------

 df3 = df3.withColumn('Conformity: ReceiverEmailAddressCCEmailAddress',
    f.when((df3['CCEmailAddressNew'].rlike(r'^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$')), 'pass: Must be in email id format')
    .when(df3['CCEmailAddressNew'].isNull(),'fail: Must Contain Non Null Value')
    .otherwise('fail: Must be in email id format'))

# COMMAND ----------

 df3 = df3.withColumn('Conformity: ReceiverEmailAddressBCCEmailAddres',
    f.when((df3['BCCEmailAddressNew'].rlike(r'^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$')), 'pass: Must be in email id format')
    .when(df3['BCCEmailAddressNew'].isNull(),'fail: Must Contain Non Null Value')
    .otherwise('fail: Must be in email id format'))

# COMMAND ----------

df = df.withColumn('Conformity: EmailSeqNumByParentId',
    f.when(df['EmailSeqNumByParentId'] >= 1, 'pass: Value must be greater than 1')
    .when(df['EmailSeqNumByParentId'].isNull(), 'fail: Must Contain Non Null Value')
    .otherwise('fail: Value must be greater than 1'))

df = df.withColumn('Conformity: RequestCreatedBy',
    f.when(df['RequestCreatedBy.Email'].rlike(r'.+'), 'pass: Must Contain a Value')
    .otherwise('fail: Must Contain a Value'))

df = df.withColumn('Conformity: LastUpdateTimeStamp',
    f.when(df['LastUpdateTimeStamp'].rlike(r'^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$'), 'pass: Must conform to DateTime Format')
    .otherwise('fail: Must conform to DateTime Format'))

df = df.withColumn('Conformity: UpdateTimeStamp',
    f.when(df['UpdateTimeStamp'].rlike(r'^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$'), 'pass: Must conform to DateTime Format')
    .otherwise('fail: Must conform to DateTime Format'))

df = df.withColumn('Conformity: CurationTimestamp',
    f.when(df['CurationTimestamp'].rlike(r'^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$'), 'pass: Must conform to DateTime Format')
    .otherwise('fail: Must conform to DateTime Format'))

df = df.withColumn('Conformity: SrcSystemModStamp',
    f.when(df['SrcSystemModStamp'].rlike(r'^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$'), 'pass: Must conform to DateTime Format')
    .otherwise('fail: Must conform to DateTime Format'))

df = df.withColumn('Conformity: CustomerPartyId',
    f.when(df['CustomerPartyId.PolicyOwnerMDMId'].rlike(r'^\d+$'), 'pass: Must Contain a Value')
    .otherwise('fail: Must Contain a Value'))

df = df.withColumn('Conformity: ProductId',
    f.when(df['ProductId.ProductCode'].rlike(r'.+'), 'pass: Must Contain a Value')
    .otherwise('fail: Must Contain a Value'))

# COMMAND ----------

config['asset_name'] = 'EmailCommunication'
summary_df = get_summary(df, threshold_scores, **config)
failed_rows_df = get_failed_rows(df)

# COMMAND ----------


joined_summary = get_summary(joined_df, threshold_scores, **config )
failed_joined = get_failed_rows (joined_df)

# COMMAND ----------


summary_df3 = get_summary(df3, threshold_scores, **config)
failed_rows_df3 = get_failed_rows(df3)

# COMMAND ----------


summary_df4 = get_summary(df4, threshold_scores, **config)
failed_rows_df4 = get_failed_rows(df4)

# COMMAND ----------

summary_df = summary_df.union(joined_summary)

# COMMAND ----------

summary_df = summary_df.union(summary_df3)

# COMMAND ----------

summary_df = summary_df.union(summary_df4)

# COMMAND ----------

save_parquet_results(failed_rows_df, summary_df, **config)
