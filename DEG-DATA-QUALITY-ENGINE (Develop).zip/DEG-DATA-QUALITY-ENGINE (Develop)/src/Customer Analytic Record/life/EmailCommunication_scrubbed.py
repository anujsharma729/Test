# Databricks notebook source
# MAGIC %run ../../utils

# COMMAND ----------

from pyspark.sql.functions import year, month, col, dayofmonth, hour, to_timestamp

configure_spark()
config = {
"container": 'usdo-car-gold-non-pii',
"parent_dir": 'US/LIFE',
"asset_name": '',
"work_stream": "CAR",
"data_system": "CAR_Life",
"data_owner": "Amy Miskavitch",
"business_unit": "Life (US)",
"data_domain": "Customer", 
"rule_owner": "Bunty Ramrakhyani"
}
# df = spark.read.format('delta').load(f'abfss://usdo-car-gold-non-pii@{PROD_ADLS_STORAGE_ACCOUNT}.dfs.core.windows.net/US/LIFE/EmailCommunication_Scrubbed')

config['asset_name'] = 'EmailCommunication_Scrubbed'

df = read_asset_delta(**config)

# COMMAND ----------

config2 = {
"container": 'usdo-car-gold-pii',
"parent_dir": 'car/life',
"asset_name": '',
"work_stream": 'CAR',
"data_system": 'CAR_Life',
"data_owner": "Charles Wiegersma",
"business_unit": "Long Term Care (US)",
"data_domain": "Customer", 
"rule_owner": "Bunty Ramrakhyani"
}

# df2 = spark.read.format('delta').load(f'abfss://usdo-car-gold-pii@{PROD_ADLS_STORAGE_ACCOUNT}.dfs.core.windows.net/car/life/EmailCommunication')
config2['asset_name'] = 'EmailCommunication'
df2 = read_asset_delta(**config2)
df2 = df2.select("EmailCommunicationId")

# COMMAND ----------

df = df.withColumn('load_timestamp', f.trim(df['load_timestamp'].substr(1,19)))
df = df.withColumn('srcload_timestamp', f.trim(df['srcload_timestamp'].substr(1,19)))


# COMMAND ----------

#THRESHOLD
threshold_scores = {
    'EmailCommunicationId': [
        {'Rule':'Must Contain Non Null Value', 'Threshold': 1.0},
        {'Rule':'Must Contain Unique Value', 'Threshold': 1.0},
        {'Rule':'EmailCommunicationId exists in EmailCommunication', 'Threshold': 1.0}
    ],
    'LatestEmailTranscript_scrubbed': [
        {'Rule': 'Must not contain empty strings', 'Threshold': 1.0},
        {'Rule': 'Must Contain Non Null Value', 'Threshold': 1.0}
    ],
    'load_timestamp': [
        {'Rule': 'Must conform to DateTime Format', 'Threshold': 1.0}
    ],
    'srcload_timestamp': [
        {'Rule': 'Must conform to DateTime Format', 'Threshold': 1.0}
    ],
    'year': [
        {'Rule': 'Must be the year from load_timestamp', 'Threshold': 1.0}
    ],
    'month': [
        {'Rule': 'Must be the month from load_timestamp', 'Threshold': 1.0}
    ],
    'hour': [
        {'Rule': 'Must be the hour from load_timestamp', 'Threshold': 1.0}
    ],
    'day': [
        {'Rule': 'Must be the day from load_timestamp', 'Threshold': 1.0}
    ],

}

# COMMAND ----------

#COMPLETENESS CHECK
completeness_check_columns = ['EmailCommunicationId','LatestEmailTranscript_scrubbed']
for column in completeness_check_columns:
    df = completeness_check(df, column)


#UNIQUENESS CHECK
uniqueness_check_columns = ['EmailCommunicationId']
for column in uniqueness_check_columns:
    df = uniqueness_check(df,column)

#CONFORMITY CHECK 

df = df.withColumn('Conformity: EmailCommunicationId',
    f.when(df['EmailCommunicationId'] == '', 'fail: Must not contain empty strings') 
    .otherwise('pass: Must not contain empty strings'))

df = df.withColumn('Conformity: LatestEmailTranscript_scrubbed',
    f.when(df['LatestEmailTranscript_scrubbed'] == '', 'fail: Must not contain empty strings') 
    .otherwise('pass: Must not contain empty strings'))

df = df.withColumn('Conformity: load_timestamp',
    f.when(df['load_timestamp'].rlike(r'^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$'), 'pass: Must conform to DateTime Format')
    .otherwise('fail: Must conform to DateTime Format'))

df = df.withColumn('Conformity: srcload_timestamp',
     f.when(df['srcload_timestamp'].rlike(r'^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$'), 'pass: Must conform to DateTime Format')
    .otherwise('fail: Must conform to DateTime Format'))

df = df.withColumn('Conformity: year',
    f.when(col('year')== year("load_timestamp"), 'pass: Must be the year from load_timestamp')
    .when(df['year'].rlike(r'^\d*[1-9]\d*$'), 'pass: Must be a positive numeric value')
    .otherwise('fail: Must be numeric and year from load_timestamp'))

df = df.withColumn('Conformity: month',
    f.when(col('month')== month("load_timestamp"), 'pass: Must be the month from load_timestamp')
    .when(df['month'].rlike(r'^\d*[1-9]\d*$'), 'pass: Must be a positive numeric value')
    .when(col('month').between(1, 12), 'pass: Must be a valid month')
    .otherwise('fail: Must be numeric and month from load_timestamp'))

df = df.withColumn('Conformity: day',
    f.when(col('day')== dayofmonth("load_timestamp"), 'pass: Must be the day from load_timestamp')
    .when(df['day'].rlike(r'^\d*[1-9]\d*$'), 'pass: Must be a positive numeric value')
    .when(col('day').between(1, 31), 'pass: Must be a valid day')
    .otherwise('fail: Must be numeric and day from load_timestamp'))

df = df.withColumn('Conformity: hour',
    f.when(col('hour')== hour("load_timestamp"), 'pass: Must be the hour from load_timestamp')
    .when(df['hour'].rlike(r'^\d*[1-9]\d*$'), 'pass: Must be a positive numeric value')
    .otherwise('fail: Must be numeric and hour from load_timestamp'))


# COMMAND ----------

df = df.join(df2.withColumn("flag",f.lit(True)), "EmailCommunicationId", "left").select(df.columns + ["flag"])
df = df.fillna(False, subset=["flag"])

df = df.withColumn('Conformity: EmailCommunicationId',
   f.when(df['EmailCommunicationId'] == '', 'fail: Must not contain empty strings') 
    .when(df['flag'] == 'True', 'pass: EmailCommunicationId exists in EmailCommunication') 
    .otherwise('fail: EmailCommunicationId exists in EmailCommunication'))
df = df.drop("flag")

# COMMAND ----------

config['asset_name'] = 'EmailCommunication_Scrubbed'
summary_df = get_summary(df, threshold_scores, **config)
failed_rows_df = get_failed_rows(df)

# COMMAND ----------

save_parquet_results(failed_rows_df, summary_df, **config)
