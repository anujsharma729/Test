# Databricks notebook source
# MAGIC %run ../../utils

# COMMAND ----------

configure_spark()
config = {
"container": 'usdo-car-gold-non-pii',
"parent_dir": 'US/PARTY',
"asset_name": '',
"work_stream": "CAR",
"data_system": "CAR_Party"
}

config['asset_name'] = 'PartyPublicDemographics'
df = read_asset_delta(**config)

# COMMAND ----------

df = df.withColumn('CurationTimestamp', f.trim(df['CurationTimestamp'].substr(1,19)))

# COMMAND ----------

#THRESHOLD
threshold_scores = {
    'PostalCode': [
        {'Rule':'Must Contain Non Null Value', 'Threshold': 1.0}
    ],
    'EstimatedIncome': [
        {'Rule': 'Must be a numeric value', 'Threshold': 0.85}
    ],
    'EstimatedMedianAge': [
        {'Rule': 'Must be a positive numeric value', 'Threshold': 0.85}
    ],
    'TotalPopulation': [
        {'Rule': 'Must be a positive numeric value', 'Threshold': 0.85}
    ],
    'EmploymentRateCharacteristics': [
        {'Rule': 'Must Contain Non Null Value', 'Threshold': 0.85}
    ],
    'HealthInsuranceCoverageCharacteristics': [
        {'Rule': 'Must Contain Non Null Value', 'Threshold': 0.85}
    ],
    'HousingOccupancyCharacteristics': [
        {'Rule':'Must Contain Non Null Value', 'Threshold': 0.85}
    ],
    'MaritalStatusCharacteristics': [
        {'Rule': 'Must Contain Non Null Value', 'Threshold': 0.85}
    ],
    'HouseHoldCharacteristics': [
        {'Rule': 'Must Contain Non Null Value', 'Threshold': 0.85}
    ],
    'CurationTimestamp': [
        {'Rule': 'Must conform to DateTime Format', 'Threshold': 1.0}
    ],
    'CensusYear': [
        {'Rule': 'Must be a numeric value', 'Threshold': 1.0}
    ]
}

# COMMAND ----------

#COMPLETENESS CHECK
completeness_check_columns = ['PostalCode', 'EmploymentRateCharacteristics', 'HealthInsuranceCoverageCharacteristics', 'HousingOccupancyCharacteristics', 'MaritalStatusCharacteristics', 'HouseHoldCharacteristics']
for column in completeness_check_columns:
    df = completeness_check(df, column)

# COMMAND ----------

#CONFORMITY CHECK
df = df.withColumn('Conformity: EstimatedIncome',
    f.when(df['EstimatedIncome'].rlike(r'^-?\d+(\.\d+)?$'), 'pass: Must be a numeric value')
    .when(df['EstimatedIncome'] == '', 'fail: Must Contain Non Null Value')
    .otherwise('fail: Must be a numeric value'))

df = df.withColumn('Conformity: EstimatedMedianAge',
    f.when(df['EstimatedMedianAge'].rlike(r'^\d+(\.\d+)?$'), 'pass: Must be a positive numeric value')
    .when(df['EstimatedMedianAge'] == '', 'fail: Must Contain Non Null Value')
    .otherwise('fail: Must be a positive numeric value'))

df = df.withColumn('Conformity: TotalPopulation',
    f.when(df['TotalPopulation'].rlike(r'^\d+(\.\d+)?$'), 'pass: Must be a positive numeric value')
    .when(df['TotalPopulation'] == '', 'fail: Must Contain Non Null Value')
    .otherwise('fail: Must be a positive numeric value'))

df = df.withColumn('Conformity: CurationTimestamp',
    f.when(df['CurationTimestamp'].rlike(r'^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$'), 'pass: Must conform to DateTime Format')
    .otherwise('fail: Must conform to DateTime Format'))

df = df.withColumn('Conformity: CensusYear',
    f.when(df['CensusYear'].rlike(r'^-?\d+(\.\d+)?$'), 'pass: Must be a numeric value')
    .when(df['CensusYear'] == '', 'fail: Must Contain Non Null Value')
    .otherwise('fail: Must be a numeric value'))

# COMMAND ----------

config['asset_name'] = 'PartyPublicDemographics'
summary_df = get_summary(df, threshold_scores, **config)
failed_rows_df = get_failed_rows(df)

# COMMAND ----------

save_parquet_results(failed_rows_df, summary_df, **config)
