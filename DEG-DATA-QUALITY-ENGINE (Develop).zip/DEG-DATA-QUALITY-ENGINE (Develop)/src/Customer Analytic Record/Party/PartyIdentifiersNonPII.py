# Databricks notebook source
# MAGIC %run ../../utils

# COMMAND ----------

configure_spark()
config = {
"container": 'usdo-car-gold-non-pii',
"parent_dir": 'US/LIFE/PARTY',
"asset_name": '',
"work_stream": "CAR",
"data_system": "CAR_Party"
}

config['asset_name'] = 'PartyIdentifiersNonPII'
df = read_asset_delta(**config)

# COMMAND ----------

df = df.withColumn('CurationTimestamp', f.trim(df['CurationTimestamp'].substr(1,19)))

# COMMAND ----------

#THRESHOLD
threshold_scores = {
    'PartyId': [
        {'Rule':'Must Contain Non Null Value', 'Threshold': 1.0}
    ],
    'EnterpriseId': [
        {'Rule': 'Must Contain Non Null Value', 'Threshold': 0.25}
    ],
    'BusinessUnit': [
        {'Rule': 'Must Contain Non Null Value', 'Threshold': 1.0}
    ],
    'CurationTimestamp': [
        {'Rule': 'Must conform to DateTime Format', 'Threshold': 1.0}
    ]
}

# COMMAND ----------

#COMPLETENESS CHECK
completeness_check_columns = ['PartyId', 'BusinessUnit', 'EnterpriseId' ]
for column in completeness_check_columns:
    df = completeness_check(df, column)

# COMMAND ----------

#CONFORMITY CHECK
df = df.withColumn('Conformity: CurationTimestamp',
    f.when(df['CurationTimestamp'].rlike(r'^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$'), 'pass: Must conform to DateTime Format')
    .otherwise('fail: Must conform to DateTime Format'))

# COMMAND ----------

config['asset_name'] = 'PartyIdentifiersNonPII'
summary_df = get_summary(df, threshold_scores, **config)
failed_rows_df = get_failed_rows(df)

# COMMAND ----------

save_parquet_results(failed_rows_df, summary_df, **config)
