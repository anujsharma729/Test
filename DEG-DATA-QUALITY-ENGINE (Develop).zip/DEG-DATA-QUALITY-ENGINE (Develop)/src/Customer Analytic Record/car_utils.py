# Databricks notebook source
from pyspark.sql.functions import year, month, col, dayofmonth, hour, to_timestamp

config = {'container': '',
 'parent_dir': '',
 'asset_name': '',
 'work_stream': 'CAR',
 'data_system': 'car life',
 'data_owner': 'Amy Miskavitch',
 'business_unit': 'Life (US)',
 'data_domain': 'Customer',
 'rule_owner': 'Bunty Ramrakhyani'}

# COMMAND ----------

def uc_read(asset):
    df = spark.sql(f"SELECT * FROM usdo_uat_catalog.gold_car.{asset}")
    config['parent_dir'] = f"usdo_uat_catalog.gold_car.{asset}" 
    config['asset_name'] = asset
    return df

def format_dates(df, columns):
    if isinstance(columns, str):
        df = df.withColumn(columns, f.trim(df[columns].substr(1,19)))

    elif isinstance(columns, list):
        for column in columns:
            df = df.withColumn(column, f.trim(df[column].substr(1,19)))
    return df

def format_nested_array(df, main_column, subcolumns):
    if isinstance(subcolumns, str):
        c = main_column + '.' + subcolumns
        df = df.withColumn(c, f.explode(f.col(c)))
    elif isinstance(subcolumns, list): 
        for column in subcolumns:
            c = main_column + '.' + column
            df = df.withColumn(c, f.explode(f.col(c)))

    df = df.drop(main_column)
    return df

# COMMAND ----------

def conformity_segment_or_country(df, column):
    df = df.withColumn(f'Conformity: {column}',
    f.when((df[column] == 'US'), f'pass: value must be US')
    .otherwise('fail: value must be US'))
    return df

def accuracy_country_segment(df, c1, c2):
    rule = 'value must reflect correct country: segment [US: US], [Canada: Canada], [GWAM: US or Canada]'
    df = df.withColumn('Conformity: {c1}',
    f.when(((df[c1] == 'US') & (df[c2] == 'US')), f'pass: {rule}')
    .when(((df[c1] == 'Canada') & (df[c2] == 'Canada')), f'pass: {rule}')
    .when(((df[c1] == 'GWAM') & ((df[c2] == 'US') |(df[c2] == 'Canada'))), f'pass: {rule}')
    .otherwise(f'fail: {rule}'))
    return df

def conformity_issuingCompany(df, column):
    rule = 'value must reflect correct segment [US: JohnHancock], [Canada: Manulife], [GWAM: JohnHancock or Manulife]'
    df = df.withColumn('Conformity: IssuingCompany',
        f.when(((df['Segment'] == 'US') & (df[column] == 'JohnHancock')), f'pass: {rule}')
        .when(((df['Segment'] == 'Canada') & (df[column] == 'Manulife')), f'pass: {rule}')
        .when(((df['Segment'] == 'GWAM') & ((df[column] == 'JohnHancock') |(df[column] == 'Manulife'))), f'pass: {rule}')
        .otherwise(f'fail: {rule}')) 
    return df

def conformity_dateformats(df, column):
    df = df.withColumn(f'Conformity: {column}',
        f.when(df[column].rlike(r'^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$'), f'pass: must conform to datetime format')
        .otherwise('fail: must conform to datetime format'))
    return df

def conformity_checkforvalue(df, column):
    df = df.withColumn(f'Conformity: {column}', f.when(df[column].rlike(r'.+'), f'pass: must contain a value').otherwise('fail: must contain a value'))
    return df

def accuracy_year(df, column):
    df = df.withColumn('Accuracy: {column}', f.when(col(column)== year("load_timestamp"), f'pass: value must match load_timestamp').otherwise('fail: value must match load_timestamp'))
    return df

def accuracy_month(df, column):
    df = df.withColumn('Accuracy: month', f.when((col(column)== month("load_timestamp")) & (col('month').between(1, 12)), f'pass: value must match load_timestamp and be between 1-12').otherwise('fail: value must match load_timestamp and be between 1-12'))
    return df

def accuracy_day(df, column):
    df = df.withColumn('Accuracy: day', f.when((col(column)== day("load_timestamp")) & (col(column).between(1, 31)), f'pass: value must match load_timestamp and be between 1-31').otherwise('fail: value must match load_timestamp and be between 1-31'))
    return df

def accuracy_hour(df, column):
    df = df.withColumn('Accuracy: hour', f.when((col(column)== hour("load_timestamp")) & (col('hour').between(1, 24)), f'pass: value must match load_timestamp and be between 1-24').otherwise('fail: value must match load_timestamp and be between 1-24'))
    return df

def conformity_digit(df, column):
    df = df.withColumn(f'Conformity: {column}',
    f.when(df[column].rlike(r'^-?\d+(\.\d+)?$'), f'pass: must contain numeric value')
    .otherwise('fail: must contain numeric value'))
    return df

def consistency_flag(df, asset_name, column):
    df_asset = config['asset_name']
    df2 = uc_read(asset_name).select(column)
    df = df.join(df2.withColumn("flag",f.lit(True)), column, "left").select(df.columns + ["flag"])
    df = df.fillna(False, subset=["flag"])
    df = df.withColumn(f'Consistency: {column}',
   f.when(df[column] == '', 'fail: fail: {column} exists in {df_asset}').when(df['flag'] == 'True', f'pass: fail: {column} exists in {df_asset}').otherwise(f'fail: {column} exists in {df_asset}')).drop("flag")
    return df
   
def accuracy_language(df, column, country):
    rule = 'value must reflect correct language for each country [US: English], [Canada: English or French]'

    df = df.withColumn(f'Conformity: {column}',
        f.when((f.col(country) == 'US') & (f.col(column) == 'English'), f.lit(f'pass: {rule}')).when((f.col(country) == 'Canada') & (f.col(column).isin('English', 'French')), f.lit(f'pass: {rule}')).otherwise(f.lit(f'fail: {rule}')))
    return df


def conformity_username(df, column):
    df = df.withColumn(f'Conformity: {column}',
        f.when(df[column].rlike(r'^[A-Za-z09._%+-]+@MfCGD\.COM$'), 'pass: must contain valid username')
        .otherwise('fail: must contain valid username'))
    return df

def dependency_accuracy_check_value(df, columns, values):
    if len(columns) == 2:
        df = df.withColumn(f'Accuracy: {columns[0], columns[1]}', f.when((df[columns[0]].isin(values)) & (df[columns[1]].isin(values)), f'pass: must contain {values}').otherwise(f'fail: must contain {values}'))
    elif len(columns) == 3:
        df = df.withColumn(f'Accuracy: {columns[0], columns[1], columns[-1]}', f.when((df[columns[0]].isin(values)) & (df[columns[1]].isin(values))& (df[columns[-1]].isin(values)), f'pass: must contain {values}').otherwise(f'fail: must contain {values}'))
    
    return df

# COMMAND ----------

#THRESHOLD
annuity_thresholds = {
    'CallQueue': [
        {'Rule':'must contain non null value', 'Threshold': 0.6}
    ],
    'CustomAttributes': [
        {'Rule': 'must contain non null value', 'Threshold': 1.0}
    ],
    'CARCustomAttributes': [
        {'Rule': 'must contain non null value', 'Threshold': 1.0}
    ],
    'CCAgentUserName': [
        {'Rule': 'Must have valid username', 'Threshold': 0.5},
        {'Rule': 'must contain non null value', 'Threshold': 0.5}
    ],
    'IsAuthenticated': [
        {'Rule': 'Must have value Authenticated or Not Authenticated', 'Threshold': 0.6},
        {'Rule': 'must contain non null value', 'Threshold': 0.6}
    ]}

# COMMAND ----------

#THRESHOLD
life_thresholds = {
    'LatestEmailTranscript_scrubbed': [
        {'Rule': 'must contain non null value', 'Threshold': 0.2}
    ],
    'EmailTranscript_unscrubbed': [
        {'Rule': 'must contain non null value', 'Threshold': 0.97}
    ],
    'SenderName': [
        {'Rule': 'must contain non null value', 'Threshold': 0.97}
    ],
    'EmailStatus': [
        {'Rule': 'must contain non null value', 'Threshold': 0.99}
    ],
    'RequestCreatedBy': [
        {'Rule': 'must contain a value', 'Threshold': 1.0}
    ],
    'CustomerPartyId': [
        {'Rule': 'must contain a value', 'Threshold': 0.1}
    ],
    'ProductId': [
        {'Rule': 'must contain a value', 'Threshold': 0.1}
    ],

}

#THRESHOLD
service_request_thresholds = {
    'PartyRole': [
        {'Rule':'Must Contain Non Null Value', 'Threshold': 0.2}
    ],
    'PolicyNo': [
        {'Rule': 'Must Contain Non Null Value', 'Threshold': 0.15}
    ],
    'PartyId': [
        {'Rule': 'Must Contain a Value', 'Threshold': 0.2}
    ],
    'CustomerPartyId': [
        {'Rule': 'Must Contain a Value', 'Threshold': 0.6}
    ],
    'ProductId Code': [
        {'Rule': 'Must Contain a Value', 'Threshold': 0.15}
    ],
    'ProductId Name': [
        {'Rule': 'Must Contain a Value', 'Threshold': 0.15}
    ],
    'AddlServiceRequestJoinId SFPolicyId': [
        {'Rule': 'Must Contain a Value', 'Threshold': 0.1}
    ],
    'AddlServiceRequestJoinId SFPolicyOwnerId': [
        {'Rule': 'Must Contain a Value', 'Threshold': 0.1}
    ],
}