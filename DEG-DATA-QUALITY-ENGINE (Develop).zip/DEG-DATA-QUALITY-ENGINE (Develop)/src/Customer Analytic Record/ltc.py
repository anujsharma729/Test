# Databricks notebook source
# MAGIC %run ../utils

# COMMAND ----------

# MAGIC %run ../rules

# COMMAND ----------

# MAGIC %run ./car_utils

# COMMAND ----------

df3 = uc_read('ltc_emailcommunication')
df2 = uc_read('ltc_servicerequest_task')
df1 = uc_read('ltc_telephonecommunication')

df1 = format_dates(df1, ['CurationTimestamp', 'UpdateTimeStamp'])


# COMMAND ----------

#TelephoneCommunication
df1 = consistency_flag(df1, 'ltc_servicerequest_task', 'ServiceRequestJoinId')
df1 = uniqueness_check(df1,'TelephoneCommunicationId')

completeness_check_columns = ['ServiceRequestJoinId', 'Segment', 'Country', 'IssuingCompany','BusinessUnit', 'CallCentreCodeName', 'Channel', 'CallDirection' ,'CallQueue','CustomAttributes', 'CARCustomAttributes']
for column in completeness_check_columns:
    df1 = completeness_check(df1, column)

df1 = accuracy_check_value(df1, 'Segment', ['US', 'Canada', 'GWAM'])
df1 = conformity_issuingCompany(df1, 'IssuingCompany')
df1 = accuracy_country_segment(df1, 'Segment', 'Country')
df1 = accuracy_check_value(df1, 'BusinessUnit', 'LTC')
df1 = accuracy_check_value(df1, 'Channel', ['VOICE', 'CHAT'])
df1 = accuracy_check_value(df1, 'IsAuthenticated', ['Not Authenticated', 'Authenticated'])
df1 = conformity_check_value_integer(df1, 'CallInteractionDuration')
df1 = conformity_check_value_integer(df1, 'CallTransfersByInitialContact')
df1 = accuracy_language(df1, 'Language', 'Country')
#df1 = conformity_check_datetime(df1, ['LastUpdateTimeStamp','UpdateTimeStamp', 'CurationTimestamp', 'CallInitiationTimestamp', 'CallConnectedToSystemTimestamp'])
for dt_col in ['CallInitiationTimestamp', 'CallConnectedToSystemTimestamp','LastUpdateTimeStamp', 'UpdateTimeStamp','CurationTimestamp']:
        df1 = conformity_datetime(df1, dt_col)
df1 =conformity_username(df1, 'CCAgentUserName')

#Conditions for CallAbandoned Column
conditions = (df1['CallAbandoned.IVR_Abandoned'].cast('string').isin('true', 'false')) &\
    (df1['CallAbandoned.Queue_Abandoned'].cast('string').isin('true', 'false')) &\
    (df1['CallAbandoned.Abandoned'].cast('string').isin('true', 'false'))
df1 = df1.withColumn('Conformity: CallAbandoned',
    f.when(conditions, 'pass: sub-attributes must contain value true or false')
    .otherwise('fail: sub-attributes must contain value true or false'))

#Conditions for CCSentiment Column
conditions2 = (df1['CCSentiment.AGENT'] >= -10.0) & (df1['CCSentiment.CUSTOMER'] >=-10.0)
df1 = df1.withColumn('Conformity: CCSentiment',
    f.when(conditions2, 'pass: agent and customer must have numeric values')
    .otherwise('fail: agent and customer must have numeric values'))

conditions_agent = (df1['CCSentiment.AGENT'] >= -10.0)
df1 = df1.withColumn('Conformity: CCSentiment Agent',
    f.when(conditions_agent, 'pass: agent must have numeric values')
    .otherwise('fail: agent must have numeric values'))
conditions_customer = (df1['CCSentiment.CUSTOMER'] >= -10.0)
df1 = df1.withColumn('Conformity: CCSentiment Customer',
    f.when(conditions_customer, 'pass: customer must have numeric values')
    .otherwise('fail: customer must have numeric values'))


# COMMAND ----------

s1 = get_summary(df1, None, **config)

# COMMAND ----------

#EmailCommunication
config['asset_name'] = 'EmailCommunication'
df3 = read_asset_delta(**config)
dates = ['CurationTimestamp', 'UpdateTimeStamp', 'EmailCreatedDate', 'EmailMessageDate', 'SrcSystemModStamp','LastUpdateTimeStamp']
df3 = format_dates(df3, dates)

df3 = consistency_flag(df3, 'ltc_servicerequest_task', 'ServiceRequestId')
df3 = uniqueness_check(df3,'EmailCommunicationId')

completeness_check_columns = ['EmailCommunicationId','ServiceRequestId','Segment', 'Country', 'IssuingCompany','BusinessUnit', 'LineofBusiness','CCSourceSystem','Channel','EmailDirection', 'EmailCreatedDate', 'EmailMessageDate','Subject','LatestEmailTranscript_unscrubbed','EmailTranscript_unscrubbed','SenderType','SenderName','EmailStatus','LastUpdateTimeStamp','UpdateTimeStamp','CurationTimestamp','SrcSystemModStamp','PolicyNo']
for column in completeness_check_columns:
    df3 = completeness_check(df3, column)

df2 = conformity_segment_or_country(df2, 'Segment')
df2 = conformity_segment_or_country(df2, 'Segment')
df2 = conformity_issuingCompany(df2, 'IssuingCompany')
df2 = accuracy_check_value(df2, 'IssuingCompany', 'Insurance')
df2 = accuracy_check_value(df2, 'BusinessUnit', 'LTC')
df2 = accuracy_check_value(df2, 'EmailDirection', ['INBOUND', 'OUTBOUND'])
df2 = accuracy_check_value(df2, 'SenderType', ['Customer', 'Agent'])
df2 = accuracy_check_value(df2, 'LatestEmailScope', ['Internal', 'External'])

df2 = conformity_email(df2, 'SenderEmailAddress.EmailAddress')

for date in dates: df2 = conformity_datetime(df2, date)
