# Databricks notebook source
# MAGIC %run ../../utils

# COMMAND ----------

# MAGIC %run ../../rules

# COMMAND ----------

# MAGIC %run ../car_utils

# COMMAND ----------

configure_spark()
config = {
"container": 'usdo-car-gold-pii',
"parent_dir": 'Medallia_Surveys/',
"asset_name": '',
'work_stream': 'CAR',
'data_system': 'CAR Life',
'data_owner': 'Amy Miskavitch',
'business_unit': 'Life (US)',
'data_domain': 'Customer',
'rule_owner': 'Bunty Ramrakhyani'}


# COMMAND ----------

def apply_data_quality(df, asset):
    if 'Communication' in asset:
        df = df.withColumn('ResponseDate', f.trim(df['ResponseDate'].substr(1,19)))
        for column in ['SurveyCommunicationId', 'SurveyProgramId', 'SurveyName', 'FeedbackType','BusinessUnit','LineofBusiness', 'Channel', 'PartyType', 'KeyMetric', 'VitalityAttributes']:
            df = completeness_check(df, column)
        df = uniqueness_check(df,'SurveyCommunicationId')
        df = accuracy_check_value(df, 'Segment', 'US')
        df = accuracy_check_value(df, 'Country', 'US')
        df = accuracy_check_value(df, 'IssuingCompany', 'JohnHancock')
        df = conformity_datetime(df, 'ResponseDate')
    else:
        df = accuracy_check_value(df, 'ResponseTypeYN', ['Yes', 'No', None])
        for column in ['Qid', 'ResponseTypeScore', 'ResponseVar']:
            df = completeness_check(df, column, '')
        
        df = df.withColumn('Consistency: SurveyCommunicationId',
        f.when(df['flag'] == 'True', 'pass: SurveyCommunicationId exists in SurveyCommunication') 
            .otherwise('fail: SurveyCommunicationId exists in SurveyCommunication')).drop('flag')
    
    keywords = ['Uniqueness', 'Conformity', 'Completeness', 'Accuracy']
    df = df.select([c for c in df.columns if any(k in c for k in keywords)])
    return df

# COMMAND ----------

# config['data_system'] = 'car survey'
assets = ['SurveyResponse', 'SurveyCommunication']
areas = ['Digital', 'rNPS_Insurance_Distribution', 'rNPS_Vitality', 'tNPS_cc', 'tNPS_Claims', 'tNPS_Compensation', 'tNPS_Vitality']
summary_df = None
for area in areas:
    for asset in assets:
        # df = uc_read(schema, value)
        print(area, asset)
        config['asset_name'] = area + '/' + asset
        df = read_asset_delta(**config)
        if 'Response' in asset:
            config['asset_name'] = area + '/SurveyCommunication'
            df2 = read_asset_delta(**config).select("SurveyCommunicationId")
            df = df.join(df2.withColumn("flag",f.lit(True)), "SurveyCommunicationId", "left").fillna(False, subset=["flag"])

        df = apply_data_quality(df, asset)
        config['asset_name'] = area + '/' + asset
        summary = get_summary(df, None, **config)
        if summary_df == None: summary_df = summary
        else: summary_df = summary_df.union(summary)

# COMMAND ----------

display(summary_df)

# COMMAND ----------

