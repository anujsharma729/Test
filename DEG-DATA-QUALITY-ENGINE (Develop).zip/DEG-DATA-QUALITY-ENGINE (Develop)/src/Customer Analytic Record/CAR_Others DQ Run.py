# Databricks notebook source
# MAGIC %run ../utils

# COMMAND ----------

# MAGIC %run ./Annuities/TelephoneCommunication

# COMMAND ----------

# MAGIC %run "./B2B Insurance Sales/TelephoneCommunication"

# COMMAND ----------

# MAGIC %run "./B2B NBOps/TelephoneCommunication"
