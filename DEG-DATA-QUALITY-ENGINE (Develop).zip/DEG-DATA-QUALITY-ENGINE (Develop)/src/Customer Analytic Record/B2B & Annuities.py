# Databricks notebook source
# MAGIC %run ../utils

# COMMAND ----------

# MAGIC %run ../rules

# COMMAND ----------

# MAGIC %run ./car_utils

# COMMAND ----------

def apply_rules_b2b(df):
    df = format_dates(df, ['CurationTimestamp', 'UpdateTimeStamp'])
    df = consistency_flag(df,'life_servicerequest_task' ,'ServiceRequestJoinId')
    df = uniqueness_check(df,'TelephoneCommunicationId')

    completeness_check_columns = ['ServiceRequestJoinId', 'Segment', 'Country', 'IssuingCompany','BusinessUnit', 'CallCentreCodeName', 'Channel', 'CallDirection' ,'CallQueue','CustomAttributes', 'CARCustomAttributes']
    for column in completeness_check_columns:
        df = completeness_check(df, column)

    df = accuracy_check_value(df, 'Segment', ['US', 'Canada', 'GWAM'])
    df = accuracy_country_segment(df, 'Segment', 'Country')
    df = conformity_issuingCompany(df, 'IssuingCompany')
    for dt_col in ['CallInitiationTimestamp', 'CallConnectedToSystemTimestamp','LastUpdateTimeStamp', 'UpdateTimeStamp','CurationTimestamp']:
        df = conformity_datetime(df, dt_col)

    df = conformity_check_value_integer(df, 'CallInteractionDuration')
    df = conformity_check_value_integer(df, 'CallTransfersByInitialContact')
    df = conformity_username(df, 'CCAgentUserName')
    df = accuracy_check_value(df, 'BusinessUnit', 'LIFE')
    df = accuracy_check_value(df, 'Channel', ['VOICE', 'CHAT'])
    df = accuracy_language(df, 'Language', 'Country')
    df = accuarcy_greaterthan(df, "CCSentiment.AGENT", -10.0)
    df = accuarcy_greaterthan(df, "CCSentiment.CUSTOMER", -10.0)
    # CallAbandoned fields are BOOLEAN, not arrays — extract and cast to string instead of explode
    for sub_col in ['IVR_Abandoned', 'Queue_Abandoned', 'Abandoned']:
        df = df.withColumn(f'CallAbandoned_{sub_col}', f.col(f'CallAbandoned.{sub_col}').cast('string'))
    df = df.drop('CallAbandoned')
    df = dependency_accuracy_check_value(df, ['CallAbandoned_IVR_Abandoned', 'CallAbandoned_Queue_Abandoned', 'CallAbandoned_Abandoned'], ['true', 'false'])
    return df

# COMMAND ----------

dimensions = ('Completeness:','Uniqueness:','Conformity:','Accuracy:','Timeliness:')
def filter_dimension_columns(df, dimensions=dimensions):
    df = df.select([col(f"`{x}`") for x in df.columns if x.startswith((dimensions))])
    return df

# COMMAND ----------

#THRESHOLD
threshold_scores = {
    'CallQueue': [
        {'Rule':'Must Contain Non Null Value', 'Threshold': 0.6}
    ],
    'CustomAttributes': [
        {'Rule': 'Must Contain Non Null Value', 'Threshold': 1.0}
    ],
    'CARCustomAttributes': [
        {'Rule': 'Must Contain Non Null Value', 'Threshold': 1.0}
    ],
    'CCAgentUserName': [
        {'Rule': 'Must have valid username', 'Threshold': 0.5},
        {'Rule': 'Must Contain Non Null Value', 'Threshold': 0.5}
    ]
}

# COMMAND ----------

df1 = uc_read('nbops_telephonecommunication')
df2 = uc_read('ins_sales_telephonecommunication')
df3 = uc_read('annuities_telephonecommunication')

df1 = apply_rules_b2b(df1)
df2 = apply_rules_b2b(df2)
df3 = apply_rules_b2b(df3)

df3 = filter_dimension_columns(df3)

s1 = get_summary(df1, config)
s2 = get_summary(df2, config)
config['asset_name'] = 'annuities_telephonecommunication'
s3 = get_summary(df3, config)
display(s3)
summary = s1.union(s2).union(s3)

# COMMAND ----------

s3 = get_summary(df3, None, **config).display()


# COMMAND ----------

#uc_write(summary)