# Databricks notebook source
# MAGIC %run ../utils

# COMMAND ----------

# MAGIC %run ../rules

# COMMAND ----------

# MAGIC %run ./car_utils

# COMMAND ----------

df1 = uc_read('life_emailcommunication')
df2 = uc_read('life_servicerequest_task')
df3 = uc_read('life_emailcommunication_scrubbed')
df4 = uc_read('life_claims_curation')
#df5 = uc_read('life_telephonecommunication_scrubbed')
#df6 = uc_read('life_transcripts') #Transcripts
df7 = uc_read('life_telephonecommunication')

df1 = format_dates(df1, ['EmailCreatedDate', 'EmailMessageDate', 'LastUpdateTimeStamp','UpdateTimeStamp','CurationTimestamp','SrcSystemModStamp'])
df2 = format_dates(df2, ['RequestCreatedDate', 'CurationTimestamp'])
df3 = format_dates(df3, ['load_timestamp', 'srcload_timestamp'])
df4 = format_dates(df4, 'CurationTimestamp')
#df5 = format_dates(df5, ['load_timestamp', 'srcload_timestamp'])
# df6 = format_dates(df6,'load_timestamp')
df7 = format_dates(df7, ['CurationTimestamp', 'UpdateTimeStamp'])

# COMMAND ----------

#life_emailcommunication
communication_ids = set([row['EmailCommunicationId'] for row in df1.select('EmailCommunicationId').distinct().collect()])

completeness_check_columns = ['EmailCommunicationId', 'Segment', 'Country', 'IssuingCompany','BusinessUnit', 'LineofBusiness', 'CCSourceSystem', 'Channel', 'EmailDirection', 'EmailCreatedDate', 'EmailMessageDate', 'Subject', 'SenderType', 'PolicyNo', 'LatestEmailTranscript_unscrubbed', 'EmailTranscript_unscrubbed', 'SenderName', 'EmailStatus' ]
for column in completeness_check_columns:
    df1 = completeness_check(df1, column)

df1 = accuracy_check_value(df1, 'Country', 'US')
df1 = accuracy_check_value(df1, 'Segment', 'US')
df1 = accuracy_check_value(df1, 'BusinessUnit', 'LifeInsurance')
df1 = accuracy_check_value(df1, 'LineofBusiness', 'Insurance')
df1 = accuracy_check_value(df1, 'EmailDirection', ['INBOUND', 'OUTBOUND'])
df1 = accuracy_check_value(df1, 'SenderType', ['Agent', 'Customer'])
df1 = accuracy_check_value(df1, 'LatestEmailScope', ['Internal', 'External'])
df1 = accuracy_check_value(df1, 'ReplyToEmailCommunicationId', communication_ids)
df1 = accuarcy_greaterthan(df1, 'EmailSeqNumByParentId', 1)

df1 = consistency_flag(df1, 'life_servicerequest_task', 'ServiceRequestId')

for column in ['CustomerPartyId.PolicyOwnerMDMId', 'RequestCreatedBy.Email', 'ProductId.ProductCode']:
    df1 = conformity_checkforvalue(df1, column)

for column in ['EmailCreatedDate', 'EmailMessageDate', 'LastUpdateTimeStamp', 'UpdateTimeStamp', 'SrcSystemModStamp']:
    df1 = conformity_dateformats(df1, column)

df1 = uniqueness_check(df1,'EmailCommunicationId')

df1 = format_nested_array(df1, 'ReceiverEmailAddress', ['ToEmailAddress', 'CCEmailAddress', 'BCCEmailAddress'])
for column in ["ReceiverEmailAddress.ToEmailAddress", "ReceiverEmailAddress.CCEmailAddress", "ReceiverEmailAddress.BCCEmailAddress"]:
    df1 = conformity_email(df1, column)

# COMMAND ----------

#life_servicerequest_task
df2 = consistency_flag(df2, 'life_telephonecommunication', 'TelephoneCommunicationId')
df2 = conformity_segment_or_country(df2, 'Segment')
df2 = conformity_segment_or_country(df2, 'Country')
df2 = conformity_issuingCompany(df2, 'IssuingCompany')

df2 = accuracy_check_value(df2, 'BusinessUnit', 'LifeInsurance')
df2 = accuracy_check_value(df2, 'LineofBusiness', 'Insurance')

for column in ['RequestCreatedDate', 'CurationTimestamp']:
    df2 = conformity_dateformats(df2, column)

for column in ['PartyId.SFContactID', 'CustomerPartyId.AccountMDMId', 'ProductId.Code', 'ProductId.Name', 'RequestCreatedBy.Email', 'AddlServiceRequestJoinId.SFPolicyId', 'AddlServiceRequestJoinId.SFPolicyOwnerId']:
    df2 = conformity_checkforvalue(df2, column)

df2= consistency_check(df2, 'TelephoneCommunication','TelephoneCommunicationId','TelephoneCommunicationId','Segment', 'Segment')

df2 = uniqueness_check(df2,'ServiceRequestId')

completeness_check_columns = ['CRMObjectType', 'PartyRole', 'PartyType', 'PolicyNo', 'RequestStatus', 'SrcSystemModStamp', 'ServiceRequestJoinId']
for column in completeness_check_columns:
    df2 = completeness_check(df2, column)

# COMMAND ----------

#life_emailcommunication_scrubbed
for column in ['EmailCommunicationId','LatestEmailTranscript_scrubbed']:
    df3 = completeness_check(df3, column, '')

df3 = uniqueness_check(df3,'EmailCommunicationId')
for column in ['load_timestamp', 'srcload_timestamp']:
    df3 = conformity_dateformats(df3, column)

for column in ['year','month','day','hour']:
    df3 = conformity_check_value_integer(df3, column)

df3 = consistency_flag(df3,'life_emailcommunication', 'EmailCommunicationId')

# COMMAND ----------

#life_claims_curation
df4 = uniqueness_check(df4,'ClaimId')

for column in ['ClaimParentId','PolicyNo', 'CurationTimestamp']:
    df4 = completeness_check(df4, column)

df4 = accuracy_check_value(df4, 'Country', 'US')
df4 = accuracy_check_value(df4, 'Segment', 'US')
df4 = conformity_issuingCompany(df4, 'IssuingCompany')
df4 = accuracy_check_value(df4, 'BusinessUnit', 'LIFE')
df4 = accuracy_check_value(df4, 'LineofBusiness', 'Insurance')

# COMMAND ----------

'''
#life_telephonecommunication_scrubbed
completeness_check_columns = ['TelephoneCommunicationId','SequencedTranscript_scrubbed','SequencedAgentTranscript_scrubbed','SequencedCallerTranscript_scrubbed']
for column in completeness_check_columns:
    df5 = completeness_check(df5, column, '')

df5 = uniqueness_check(df5,'TelephoneCommunicationId')

for column in ['load_timestamp', 'srcload_timestamp']:
    df5 = conformity_dateformats(df5, column)

for column in ['year','month','day','hour']:
    df5 = conformity_check_value_integer(df5, column)

df5 = accuracy_year(df5, 'year')
df5 = accuracy_month(df5, 'month')
# df5 = accuracy_day(df5, 'day')
df5 = accuracy_hour(df5, 'hour')
df5 = consistency_flag(df5, 'life_telephonecommunication', 'TelephoneCommunicationId')
'''

# COMMAND ----------

#Transcripts

# completeness_check_columns = ['ContactId','SequencedTranscript_unscrubbed','SequencedAgentTranscript_unscrubbed','SequencedCallerTranscript_unscrubbed']
# for column in completeness_check_columns:
#     df6 = completeness_check(df6, column, '')

# df6 = uniqueness_check(df6,column)
# for column in ['load_timestamp', 'year', 'month', 'day', 'hour']:
#     df6 = conformity_datetime(df6,column)

# df6 = consistency_flag(df, 'TelephoneCommunication', 'TelephoneCommunicationId')

# COMMAND ----------

#life_telephonecommunication
df7= consistency_check(df7, 'ServiceRequest','ServiceRequestJoinId','ServiceRequestJoinId','Segment', 'Segment')
df7 = uniqueness_check(df7,'TelephoneCommunicationId')

completeness_check_columns = ['ServiceRequestJoinId', 'Segment', 'Country', 'IssuingCompany','BusinessUnit', 'LineofBusiness', 'CallCentreCodeName', 'CCSourceSystem','Channel', 'CallDirection', 'CallQueue', 'CustomAttributes', 'CARCustomAttributes']
for column in completeness_check_columns:
    df7 = completeness_check(df7, column)

df7 = conformity_segment_or_country(df7, 'Segment')
df7 = conformity_segment_or_country(df7, 'Country')
df7 = conformity_issuingCompany(df7, 'IssuingCompany')
df7 = conformity_username(df7, 'CCAgentUserName')
df7 = conformity_check_value_integer(df7, 'CallInteractionDuration')
df7 = conformity_check_value_integer(df7, 'CallTransfersByInitialContact')
for column in ['CallInitiationTimestamp', 'CallConnectedToSystemTimestamp', 'LastUpdateTimeStamp', 'UpdateTimeStamp', 'CurationTimestamp']:
    df7 = conformity_dateformats(df7, column)

df7 = accuracy_check_value(df7, 'BusinessUnit', 'LIFE') 
df7 = accuracy_check_value(df7, 'Channel', ['CHAT', 'VOICE'])
df7 = accuracy_check_value(df7, 'IsAuthenticated', ['Authenticated', 'Not Authenticated'])
df7 = accuracy_language(df7, 'Language', 'Country')
df7 = accuarcy_greaterthan(df7, "CCSentiment.AGENT", -10.0)
df7 = accuarcy_greaterthan(df7, "CCSentiment.CUSTOMER", -10.0)
df7 = dependency_accuracy_check_value(df7, ['CallAbandoned.IVR_Abandoned', 'CallAbandoned.Queue_Abandoned', 'CallAbandoned.Abandoned'], [True, False])


# COMMAND ----------

s1 = get_summary(df1, config)
#s2 = get_summary(df2, None, **config)
#s3 = get_summary(df3, None, **config)
#s4 = get_summary(df4, None, **config)
#s5 = get_summary(df5, None, **config)
# s6 = get_summary(df6, None, **config)
#s7 = get_summary(df7, None, **config)


#summary = s1.union(s2).union(s3).union(s4).union(s5).union(s7)#.union(s6)

# COMMAND ----------

display(summary)

# COMMAND ----------

#uc_write(summary)