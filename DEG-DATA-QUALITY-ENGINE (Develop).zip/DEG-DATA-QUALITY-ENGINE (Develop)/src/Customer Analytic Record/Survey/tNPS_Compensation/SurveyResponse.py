# Databricks notebook source
# MAGIC %run ../../../utils

# COMMAND ----------

configure_spark()
config = {
"container": 'usdo-car-gold-pii',
"parent_dir": 'Medallia_Surveys/tNPS_Compensation',
"asset_name": '',
"work_stream": "CAR",
"data_system": "CAR_Survey"
}

config['asset_name'] = 'SurveyResponse'
df = read_asset_delta(**config)

# COMMAND ----------

config2 = {
"container": 'usdo-car-gold-pii',
"parent_dir": 'Medallia_Surveys/tNPS_Compensation',
"asset_name": '',
"work_stream": 'CAR',
"data_system": 'CAR_Survey'
}
config2['asset_name'] = 'SurveyCommunication'
df2 = read_asset_delta(**config)
df2 = df2.select("SurveyCommunicationId")

# COMMAND ----------

#CONFORMITY CHECK 
df = df.withColumn('Conformity: Qid',
    f.when(df['Qid'] == '', 'fail: Must not contain empty strings') 
    .otherwise('pass: Must not contain empty strings'))

df = df.withColumn('Conformity: ResponseTypeScore',
    f.when(df['ResponseTypeScore'] == '', 'fail: Must not contain empty strings') 
    .otherwise('pass: Must not contain empty strings'))

df = df.withColumn('Conformity: ResponseVar',
    f.when(df['ResponseVar'] == '', 'fail: Must not contain empty strings') 
    .otherwise('pass: Must not contain empty strings'))

df = df.withColumn('Conformity: ResponseTypeYN',
    f.when((df['ResponseTypeYN'] == 'Yes')|(df['ResponseTypeYN'] == 'No')|(df['ResponseTypeYN'].isNull()), 'pass: Must have value Yes, No or null')
    .otherwise('fail: Must have value inbound or outbound'))

# COMMAND ----------

df = df.join(df2.withColumn("flag",f.lit(True)), "SurveyCommunicationId", "left").select(df.columns + ["flag"])
df = df.fillna(False, subset=["flag"])

df = df.withColumn('Conformity: SurveyCommunicationId',
   f.when(df['flag'] == 'True', 'pass: SurveyCommunicationId exists in SurveyCommunication') 
    .otherwise('fail: SurveyCommunicationId exists in SurveyCommunication'))
df = df.drop("flag")

# COMMAND ----------

config['asset_name'] = 'tNPS_Compensation_SurveyResponse'

# COMMAND ----------

summary_df = get_summary(df, None, **config)
failed_rows_df = get_failed_rows(df)

# COMMAND ----------

save_parquet_results(failed_rows_df, summary_df, **config)
