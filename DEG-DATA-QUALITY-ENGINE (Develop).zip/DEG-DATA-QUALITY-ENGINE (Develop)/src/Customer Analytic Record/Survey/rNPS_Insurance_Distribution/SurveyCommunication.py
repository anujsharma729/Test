# Databricks notebook source
# MAGIC %run ../../../utils

# COMMAND ----------

configure_spark()
config = {
"container": 'usdo-car-gold-pii',
"parent_dir": 'Medallia_Surveys/rNPS_Insurance_Distribution',
"asset_name": '',
"work_stream": "CAR",
"data_system": "CAR_Survey"
}

config['asset_name'] = 'SurveyCommunication'
df = read_asset_delta(**config)

# COMMAND ----------

df = df.withColumn('ResponseDate', f.trim(df['ResponseDate'].substr(1,19)))

# COMMAND ----------

#UNIQUENESS CHECK
uniqueness_check_columns = ['SurveyCommunicationId']
for column in uniqueness_check_columns:
    df = uniqueness_check(df,column)

# COMMAND ----------

#COMPLETENESS CHECK
completeness_check_columns = ['SurveyCommunicationId', 'SurveyProgramId', 'SurveyName', 'FeedbackType','BusinessUnit','LineofBusiness', 'Channel', 'PartyType', 'KeyMetric']
for column in completeness_check_columns:
    df = completeness_check(df, column)

# COMMAND ----------

#CONFORMITY CHECK 
df = df.withColumn('Conformity: SurveyCommunicationId',
    f.when(df['SurveyCommunicationId'] == '', 'fail: Must not contain empty strings') 
    .otherwise('pass: Must not contain empty strings'))

df = df.withColumn('Conformity: Segment',
    f.when((df['Segment'] == 'US'), 'pass: Value should be US')
    .otherwise('fail: Value should be US')) 

df = df.withColumn('Conformity: Country',
    f.when((df['Country'] == 'US'), 'pass: Value should be US')
    .otherwise('fail: Value should be US')) 

df = df.withColumn('Conformity: IssuingCompany',
    f.when((df['IssuingCompany'] == 'JohnHancock'), 'pass: Value should be JohnHancock')
    .otherwise('fail: Value should be JohnHancock')) 

df = df.withColumn('Conformity: ResponseDate',
    f.when(df['ResponseDate'].rlike(r'^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$'), 'pass: Must conform to DateTime Format')
    .when(df['SurveyCommunicationId'].isNull(),'fail: Must Contain Non Null Value')
    .otherwise('fail: Must conform to DateTime Format'))

# COMMAND ----------

config['asset_name'] = 'rNPS_Insurance_Distribution_SurveyCommunication'

# COMMAND ----------

summary_df = get_summary(df, None, **config)
failed_rows_df = get_failed_rows(df)

# COMMAND ----------

save_parquet_results(failed_rows_df, summary_df, **config)
