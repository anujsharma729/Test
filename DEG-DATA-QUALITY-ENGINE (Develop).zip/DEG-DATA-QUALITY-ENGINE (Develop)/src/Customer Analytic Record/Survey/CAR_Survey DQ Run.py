# Databricks notebook source
# MAGIC %run ../../utils

# COMMAND ----------

# MAGIC %run ././Digital/SurveyCommunication

# COMMAND ----------

# MAGIC %run ././Digital/SurveyResponse

# COMMAND ----------

# MAGIC %run ././rNPS_Insurance_Distribution/SurveyCommunication

# COMMAND ----------

# MAGIC %run ././rNPS_Insurance_Distribution/SurveyResponse

# COMMAND ----------

# MAGIC %run ././rNPS_Vitality/SurveyCommunication

# COMMAND ----------

# MAGIC %run ././rNPS_Vitality/SurveyResponse

# COMMAND ----------

# MAGIC %run ././tNPS_cc/SurveyCommunication

# COMMAND ----------

# MAGIC %run ././tNPS_cc/SurveyResponse

# COMMAND ----------

# MAGIC %run ././tNPS_Claims/SurveyCommunication

# COMMAND ----------

# MAGIC %run ././tNPS_Claims/SurveyResponse

# COMMAND ----------

# MAGIC %run ././tNPS_Compensation/SurveyCommunication

# COMMAND ----------

# MAGIC %run ././tNPS_Compensation/SurveyResponse

# COMMAND ----------

# MAGIC %run ././tNPS_Vitality/SurveyCommunication

# COMMAND ----------

# MAGIC %run ././tNPS_Vitality/SurveyResponse
