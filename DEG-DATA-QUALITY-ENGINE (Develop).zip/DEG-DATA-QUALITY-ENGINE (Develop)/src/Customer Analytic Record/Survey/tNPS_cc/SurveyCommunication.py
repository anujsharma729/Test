# Databricks notebook source
# MAGIC %run ../../../utils

# COMMAND ----------

configure_spark()
config = {
"container": 'usdo-car-gold-pii',
"parent_dir": 'Medallia_Surveys/tNPS_cc',
"asset_name": '',
"work_stream": "CAR",
"data_system": "CAR_Survey"
}

config['asset_name'] = 'SurveyCommunication'
df = read_asset_delta(**config)

# COMMAND ----------


config2 = {
"container": 'usdo-car-gold-pii',
"parent_dir": 'car/life',
"asset_name": '',
"work_stream": "CAR",
"data_system": "CAR_Life"
}

config2['asset_name'] = 'TelephoneCommunication'
df2 = read_asset_delta(**config2)
df2 = df2.select("TelephoneCommunicationId")

# COMMAND ----------

config2['asset_name'] = 'ServiceRequest/TASK'
df5 = read_asset_delta(**config2)
df5 = df5.select("ServiceRequestId")

# COMMAND ----------

config3 = {
"container": 'usdo-car-gold-pii',
"parent_dir": 'car/ltc',
"asset_name": '',
"work_stream": "CAR",
"data_system": "CAR_LTC"
}

config3['asset_name'] = 'TelephoneCommunication'
df3 = read_asset_delta(**config3)
df3 = df3.select("TelephoneCommunicationId")

# COMMAND ----------

config3['asset_name'] = 'ServiceRequest/TASK'
df6 = read_asset_delta(**config3)
df6 = df6.select("ServiceRequestId")

# COMMAND ----------

config4 = {
"container": 'usdo-car-gold-pii',
"parent_dir": 'car/annuity',
"asset_name": '',
"work_stream": "CAR",
"data_system": "CAR_Annuity"
}

config4['asset_name'] = 'TelephoneCommunication'
df4 = read_asset_delta(**config4)
df4 = df4.select("TelephoneCommunicationId")

# COMMAND ----------

config7 = {
"container": 'usdo-car-gold-pii',
"parent_dir": 'car/b2b/inssales',
"asset_name": '',
"work_stream": "CAR",
"data_system": "CAR_b2b"
}

config7['asset_name'] = 'TelephoneCommunication'
df7 = read_asset_delta(**config7)
df7 = df7.select("TelephoneCommunicationId")

# COMMAND ----------

config8 = {
"container": 'usdo-car-gold-pii',
"parent_dir": 'car/b2b/nbops',
"asset_name": '',
"work_stream": "CAR",
"data_system": "CAR_b2b"
}

config8['asset_name'] = 'TelephoneCommunication'
df8 = read_asset_delta(**config8)
df8 = df8.select("TelephoneCommunicationId")

# COMMAND ----------

#THRESHOLD
threshold_scores = {
    'ServiceRequestId': [
        {'Rule':'ServiceRequestId exists in ServiceRequest ', 'Threshold': 0.6}
    ]
}

# COMMAND ----------

df = df.withColumn('ResponseDate', f.trim(df['ResponseDate'].substr(1,19)))
df = df.withColumn('InteractionDate', f.trim(df['InteractionDate'].substr(1,19)))

# COMMAND ----------

datetime = '2024-01-01 00:00:00'

# COMMAND ----------

compare_datetime = f.to_timestamp(f.lit(datetime), 'yyyy-MM-dd HH:mm:ss')

# COMMAND ----------

filtered_df = df.filter(df['InteractionDate'] > compare_datetime )

# COMMAND ----------

#UNIQUENESS CHECK
uniqueness_check_columns = ['SurveyCommunicationId']
for column in uniqueness_check_columns:
    df = uniqueness_check(df,column)

# COMMAND ----------

#COMPLETENESS CHECK
completeness_check_columns = ['SurveyCommunicationId', 'SurveyProgramId', 'SurveyName', 'FeedbackType','BusinessUnit','LineofBusiness', 'Channel', 'PartyType', 'KeyMetric']
for column in completeness_check_columns:
    df = completeness_check(df, column)

# COMMAND ----------

df = df.withColumn('Conformity: SurveyCommunicationId',
    f.when(df['SurveyCommunicationId'] == '', 'fail: Must not contain empty strings') 
    .otherwise('pass: Must not contain empty strings'))

df = df.withColumn('Conformity: Segment',
    f.when((df['Segment'] == 'US'), 'pass: Value should be US')
    .otherwise('fail: Value should be US')) 

df = df.withColumn('Conformity: Country',
    f.when((df['Country'] == 'US'), 'pass: Value should be US')
    .otherwise('fail: Value should be US')) 

df = df.withColumn('Conformity: IssuingCompany',
    f.when((df['IssuingCompany'] == 'JohnHancock'), 'pass: Value should be JohnHancock')
    .otherwise('fail: Value should be JohnHancock')) 

df = df.withColumn('Conformity: ResponseDate',
    f.when(df['ResponseDate'].rlike(r'^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$'), 'pass: Must conform to DateTime Format')
    .when(df['SurveyCommunicationId'].isNull(),'fail: Must Contain Non Null Value')
    .otherwise('fail: Must conform to DateTime Format'))


# COMMAND ----------

df_merged = df2.join(df3, on=['TelephoneCommunicationId'], how='outer')

# COMMAND ----------

df_merged1 = df_merged.join(df4, on=['TelephoneCommunicationId'], how='outer')

# COMMAND ----------

df_merged1_1 = df_merged1.join(df7, on=['TelephoneCommunicationId'], how='outer')

# COMMAND ----------

df_merged2 = df_merged1_1.join(df8, on=['TelephoneCommunicationId'], how='outer')

# COMMAND ----------

filtered_df = filtered_df.join(df_merged2.withColumn("flag",f.lit(True)), "TelephoneCommunicationId", "left").select(filtered_df.columns + ["flag"])
filtered_df = filtered_df.fillna(False, subset=["flag"])

filtered_df = filtered_df.withColumn('Conformity: TelephoneCommunicationId',
    f.when(filtered_df['flag'] == 'True', 'pass: TelephoneCommunicationId exists in TelephoneCommunication if InteractionDate > 01-01-2024') 
    .otherwise('fail: TelephoneCommunicationId exists in TelephoneCommunication if InteractionDate > 01-01-2024'))
filtered_df = filtered_df.drop("flag")

# COMMAND ----------

df_merged_tel = df5.join(df6, on=['ServiceRequestId'], how='outer')

# COMMAND ----------

df = df.join(df_merged_tel.withColumn("flag",f.lit(True)), "ServiceRequestId", "left").select(df.columns + ["flag"])
df = df.fillna(False, subset=["flag"])

df = df.withColumn('Conformity: ServiceRequestId',
    f.when(df['flag'] == 'True', 'pass: ServiceRequestId exists in ServiceRequest ') 
    .otherwise('fail: ServiceRequestId exists in ServiceRequest '))
df = df.drop("flag")

# COMMAND ----------

config['asset_name'] = 'tNPS_cc_SurveyCommunication'

# COMMAND ----------

summary_df = get_summary(df, threshold_scores, **config)
failed_rows_df = get_failed_rows(df)

# COMMAND ----------

filtered_summary_df = get_summary(filtered_df, threshold_scores, **config)

# COMMAND ----------

summary_df = summary_df.union(filtered_summary_df)

# COMMAND ----------

save_parquet_results(failed_rows_df, summary_df, **config)
