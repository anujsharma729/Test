# Databricks notebook source
# MAGIC %run ../../utils

# COMMAND ----------

# MAGIC %run ./wellness_utils

# COMMAND ----------

configure_spark()
config['asset_name'] = 'MALL'
df = read_asset(**config)
df = clean(df)
df = df.filter(df['sys_eff_to'] == '9999-12-31')

# COMMAND ----------

#COMPLETENESS
columns = ['JH_DISCOUNT_PERCENTAGE', 'JH_RETAIL_PRICE', 'TOTAL_COST']
for column in columns:
    df = df.withColumn(f'Completeness: {column}', f.when(df[column] == 0.0, 'fail: Must Contain Non Null Value').when(df[column].isNotNull(), 'pass: Must Contain Non Null Value').otherwise('fail: Must Contain Non Null Value'))

#CONFORMITY
for column in columns:
    df = df.withColumn(f'Conformity: {column}', f.when(df[column] == 0.0, 'pass: Must Contain Numeric Value').when(df[column].rlike(r"[0-9.]"),  'pass: Must Contain Numeric Value').otherwise('fail: Must Contain Numeric Value'))

#ACCURACY
df = df.withColumn('TOTAL_COST', f.col('TOTAL_COST').cast('float'))
df = df.withColumn('JH_DISCOUNT_PERCENTAGE', f.col('JH_DISCOUNT_PERCENTAGE').cast('float'))
df = df.withColumn('JH_RETAIL_PRICE', f.col('JH_RETAIL_PRICE').cast('float'))
df = df.withColumn('Accuracy: TOTAL_COST', check_mall_total_cost(df['TOTAL_COST'], df['JH_DISCOUNT_PERCENTAGE'], df['JH_RETAIL_PRICE']))

# COMMAND ----------

summary_df = get_summary(df, threshold_scores, **config)
failed_rows_df = get_failed_rows(df)
save_parquet_results(failed_rows_df, summary_df, **config)
