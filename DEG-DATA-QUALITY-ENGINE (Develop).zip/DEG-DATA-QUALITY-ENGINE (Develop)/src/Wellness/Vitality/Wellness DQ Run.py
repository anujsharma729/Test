# Databricks notebook source
# MAGIC %run ../../utils

# COMMAND ----------

# MAGIC %run ./ATTRIBUTES

# COMMAND ----------

# MAGIC %run ./EVENT_LOOKUP

# COMMAND ----------

# MAGIC %run ./EVENTSTATUS

# COMMAND ----------

# MAGIC %run ./MEMBERDETAILS

# COMMAND ----------

# MAGIC %run ./MALL

# COMMAND ----------

# MAGIC %run ./WATERFALL
