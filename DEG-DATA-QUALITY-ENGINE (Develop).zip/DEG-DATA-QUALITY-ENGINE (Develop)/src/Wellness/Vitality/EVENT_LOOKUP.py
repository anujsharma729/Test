# Databricks notebook source
# MAGIC %run ../../utils

# COMMAND ----------

# MAGIC %run ./wellness_utils

# COMMAND ----------

configure_spark()
config['asset_name'] = 'EVENT_LOOKUP'

df = read_asset(**config)
df = df.filter(df['sys_eff_to'] == '9999-12-31')
events_df = read_asset(**events_config)
events_df = events_df.select('DET_CATEGORY_ID')
df = events_df.join(df, events_df['DET_CATEGORY_ID'] == df['EVENT_ID'])
df = clean(df)

# COMMAND ----------

#COMPLETENESS
df = completeness_check(df, 'EVENT_ID')

# #CONFORMITY
df = df.withColumn('Conformity: EVENT_ID', f.when(df['EVENT_ID'].rlike(r'\d{3,4}'),'pass: Must Contain 3-4 Digit Number')
    .when(df['EVENT_ID'].isNull(), 'pass: Must Contain 3-4 Digit Number').otherwise('fail: Must Contain 3-4 Digit Number'))

#CONSISTENCY
df = df.withColumn('Consistency: EVENT_ID', f.when(df['EVENT_ID'].isin(df["DET_CATEGORY_ID"]), 'pass: EVENT_ID Must Exist in DEF_CATEGORY_ID')
    .when(df['EVENT_ID'].isNull(), 'pass: EVENT_ID Must Exist in DEF_CATEGORY_ID').otherwise('fail: EVENT_ID Must Exist in DEF_CATEGORY_ID'))


# COMMAND ----------

summary_df = get_summary(df, threshold_scores, **config)
failed_rows_df = get_failed_rows(df)
save_parquet_results(failed_rows_df, summary_df, **config)
