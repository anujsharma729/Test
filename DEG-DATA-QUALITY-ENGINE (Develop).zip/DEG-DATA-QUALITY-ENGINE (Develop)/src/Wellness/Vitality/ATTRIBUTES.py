# Databricks notebook source
# MAGIC %run ../../utils

# COMMAND ----------

# MAGIC %run ./wellness_utils

# COMMAND ----------

configure_spark()
config['asset_name'] = 'ATTRIBUTES'

df = read_asset(**config)
df = df.filter(df['ATTRIBUTE_DESC']== "Body Mass Index (BMI)")
df = df.withColumn('ATTRIBUTE_VALUE_BMI', df['ATTRIBUTE_VALUE'])
df = df.filter(df['sys_eff_to'] == '9999-12-31')

# COMMAND ----------

#COMPLETENESS
df = completeness_check(df, 'ATTRIBUTE_VALUE_BMI')

#UNIQUENESS

#CONFORMITY
df = df.withColumn('Conformity: ATTRIBUTE_VALUE_BMI', f.when(f.regexp_replace(df['ATTRIBUTE_VALUE_BMI'],r"[0-9.]", "") == '',  'pass: Must Contain Numeric Value').otherwise('fail: Must Contain Numeric Value'))

#CONSISTENCY

#ACCURACY
df = df.withColumn('Accuracy: ATTRIBUTE_VALUE_BMI', f.when(f.col('ATTRIBUTE_VALUE_BMI').between(0, 60), "pass: BMI Must Be Between 0 And 60").otherwise("fail: BMI Must Be Between 0 And 60"))

# COMMAND ----------

summary_df = get_summary(df, threshold_scores, **config)
failed_rows_df = get_failed_rows(df)
save_parquet_results(failed_rows_df, summary_df, **config)

# COMMAND ----------


