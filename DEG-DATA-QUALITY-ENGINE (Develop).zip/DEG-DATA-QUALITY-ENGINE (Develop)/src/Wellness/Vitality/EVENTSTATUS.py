# Databricks notebook source
# MAGIC %run ../../utils

# COMMAND ----------

# MAGIC %run ./wellness_utils

# COMMAND ----------

configure_spark()
config['asset_name'] = 'EVENTSTATUS'
df = read_asset(**config)
df = clean(df)
df = df.filter(df['sys_eff_to'] == '9999-12-31')

# COMMAND ----------

#Uniqueness
df = check_row_uniqueness(df, df.columns)

# COMMAND ----------

summary_df = get_summary(df, threshold_scores, **config)
failed_rows_df = get_failed_rows(df)
save_parquet_results(failed_rows_df, summary_df, **config)
