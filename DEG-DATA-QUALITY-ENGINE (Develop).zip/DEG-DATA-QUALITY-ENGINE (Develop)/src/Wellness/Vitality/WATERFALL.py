# Databricks notebook source
# MAGIC %run ../../utils

# COMMAND ----------

# MAGIC %run ./wellness_utils

# COMMAND ----------

configure_spark()
config['asset_name'] = 'WATERFALL'
df = read_asset(**config)
df = df.filter(df['WD_ACTUAL_DATE'] == '9999-12-31')
df = df.filter(~df['EMPLOYEE_NO'].startswith('HER999'))
df = df.filter((df['BRANCH'] != 'JHDIST') & (df['BRANCH'] != 'JHTEST')& (df['BRANCH'] != 'SIGCLUB'))

# COMMAND ----------

#COMPLETENESS
df = completeness_check(df, "POLICY_YEAR")

df = df.withColumn('Completeness: FIRST_ANDROID_DATE, FIRST_IOS_DATE', 
    f.when((df['FIRST_APP_LOGIN_DATE'].isNotNull()) & ((df['FIRST_ANDROID_DATE'].isNotNull()) | (df['FIRST_IOS_DATE'].isNotNull()) ), 'pass: Must Contain Non Null Values for First IOS Date or First Android Date when FIRST_APP_LOGIN_DATE is Not Null')
    .when((df['FIRST_APP_LOGIN_DATE'].isNull()) & ((df['FIRST_ANDROID_DATE'].isNull()) & (df['FIRST_IOS_DATE'].isNull()) ), 'pass: Must Contain Non Null Values for First IOS Date or First Android Date when FIRST_APP_LOGIN_DATE is Not Null')
    .when((df['FIRST_APP_LOGIN_DATE'].isNull()) & ((df['FIRST_IOS_DATE'].isNotNull()) |(df['FIRST_ANDROID_DATE'].isNotNull())), 'fail: Must Contain Non Null Values for First IOS Date or First Android Date when FIRST_APP_LOGIN_DATE is Not Null')
    .otherwise('fail: Must Contain Non Null Values for First IOS Date or First Android Date when FIRST_APP_LOGIN_DATE is Not Null'))

#UNIQUENESS

#CONFORMITY
df = df.withColumn('Conformity: POLICY_YEAR', f.when(df['POLICY_YEAR'].rlike(r'^[0-9]{1,2}$'), 'pass: Must Contain Single Digit Value').when(df['POLICY_YEAR'].isNull(), 'pass: Must Contain Single Digit Value').otherwise('fail: Must Contain Single Digit Value'))

df = df.withColumn('Conformity: FIRST_ANDROID_DATE', f.when(df['FIRST_ANDROID_DATE'].rlike(r'\d{4}-\d{2}-\d{2}'),'pass: Must Adhere To Expected Format YYYY-MM-DD').when(df['FIRST_ANDROID_DATE'].isNull(), 'pass: Must Adhere To Expected Format YYYY-MM-DD').otherwise('fail: Must Adhere To Expected Format YYYY-MM-DD'))

df = df.withColumn('Conformity: FIRST_IOS_DATE', f.when(df['FIRST_IOS_DATE'].rlike(r'\d{4}-\d{2}-\d{2}'),'pass: Must Adhere To Expected Format YYYY-MM-DD').when(df['FIRST_IOS_DATE'].isNull(), 'pass: Must Adhere To Expected Format YYYY-MM-DD').otherwise('fail: Must Adhere To Expected Format YYYY-MM-DD'))

#CONSISTENCY

#ACCURACY
df = df.withColumn('Accuracy: POLICY_YEAR', f.when((df['POLICY_YEAR'].cast('double') >= 1) & ((df['POLICY_YEAR']).cast('double') <= 10), "pass: Must Contain Number Between 1-10").when(df['POLICY_YEAR'].isNull(), 'pass: No Entry').otherwise('fail: Must Contain Number Between 1-10'))

df = df.withColumn('Accuracy: FIRST_ANDROID_DATE', f.when(df['FIRST_ANDROID_DATE'] <= TIMESTAMP[:10], 'pass: Must Not Contain Future Date').when(df['FIRST_ANDROID_DATE'].isNull(), 'pass: No Entry').otherwise('fail: Must Not Contain Future Date'))

df = df.withColumn('Accuracy: FIRST_IOS_DATE', f.when(df['FIRST_IOS_DATE'] <= TIMESTAMP[:10], 'pass: Must Not Contain Future Date').when(df['FIRST_IOS_DATE'].isNull(), 'pass: No Entry').otherwise('fail: Must Not Contain Future Date'))

# COMMAND ----------

summary_df = get_summary(df, threshold_scores, **config)
failed_rows_df = get_failed_rows(df)
save_parquet_results(failed_rows_df, summary_df, **config)
