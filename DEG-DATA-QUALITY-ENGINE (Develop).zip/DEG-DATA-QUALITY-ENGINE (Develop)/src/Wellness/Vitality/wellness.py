# Databricks notebook source
# MAGIC %run ../../utils

# COMMAND ----------

# MAGIC %run ../../rules

# COMMAND ----------

# MAGIC %run ./wellness_utils

# COMMAND ----------

df1 = uc_read('attributes')
df2 = uc_read('event_lookup')
df3 = uc_read('eventstatus')
df4 = uc_read('mall')
df5 = uc_read('memberdetails')
df6 = uc_read('waterfall')
df7 = uc_read('events')

df1 = df1.filter(df1['ATTRIBUTE_DESC']== "Body Mass Index (BMI)")
df1 = df1.withColumn('ATTRIBUTE_VALUE_BMI', df1['ATTRIBUTE_VALUE'])
df1 = df1.filter(df1['sys_eff_to'] == '9999-12-31')

df2 = df2.filter(df2['sys_eff_to'] == '9999-12-31')
df2 = df2.join(df7.select('DET_CATEGORY_ID'), df2['EVENT_ID'] == df7['DET_CATEGORY_ID'], 'inner')
df2 = clean(df2)

df3 = clean(df3)
df3 = df3.filter(df3['sys_eff_to'] == '9999-12-31')
df4 = df4.filter(df4['sys_eff_to'] == '9999-12-31')
df5 = df5.filter(df5['sys_eff_to'] == '9999-12-31')

df6 = df6.filter(df6['WD_ACTUAL_DATE'] == '9999-12-31')
df6 = df6.filter(~df6['EMPLOYEE_NO'].startswith('HER999'))
df6 = df6.filter((df6['BRANCH'] != 'JHDIST') & (df6['BRANCH'] != 'JHTEST')& (df6['BRANCH'] != 'SIGCLUB'))

# COMMAND ----------

#ATTRIBUTES
df1 = completeness_check(df1, 'ATTRIBUTE_VALUE_BMI')
df1 = conformity_check_value_integer(df1, 'ATTRIBUTE_VALUE_BMI')
df1 = accuarcy_between(df1, 'ATTRIBUTE_VALUE_BMI', 0, 60)

#EVENT_LOOKUP
df2 = completeness_check(df2, 'EVENT_ID')

df2 = df2.withColumn('Conformity: EVENT_ID', f.when((df2['EVENT_ID'].rlike(r'\d{3,4}')) | (df2['EVENT_ID'].isNull()),'pass: must contain 3-4 digit number').otherwise('fail: must contain 3-4 digit number'))

df2 = df2.withColumn('Consistency: EVENT_ID', f.when((df2['EVENT_ID'].isin(df2["DET_CATEGORY_ID"])) | (df2['EVENT_ID'].isNull()), 'pass: EVENT_ID must exist in DEF_CATEGORY_ID').otherwise('fail: EVENT_ID must exist in DEF_CATEGORY_ID'))

#EVENTSTATUS
df3 = check_row_uniqueness(df3, df3.columns)

#MALL
for column in ['JH_DISCOUNT_PERCENTAGE', 'JH_RETAIL_PRICE', 'TOTAL_COST']:
    df4 = completeness_check(df4, column, 0.0)
    df4 = conformity_check_value_integer(df4, column)

df4 = df4.withColumn('TOTAL_COST', f.col('TOTAL_COST').cast('float'))
df4 = df4.withColumn('JH_DISCOUNT_PERCENTAGE', f.col('JH_DISCOUNT_PERCENTAGE').cast('float'))
df4 = df4.withColumn('JH_RETAIL_PRICE', f.col('JH_RETAIL_PRICE').cast('float'))
df4 = df4.withColumn('Accuracy: TOTAL_COST', check_mall_total_cost(df4['TOTAL_COST'], df4['JH_DISCOUNT_PERCENTAGE'], df4['JH_RETAIL_PRICE']))

#MEMBERDETAILS
df5 = completeness_check(df5, 'PROGRAM_YEAR_START')
df5 = completeness_check(df5, 'PROGRAM_YEAR_END')

df5 = uniqueness_check(df5,['EMPLOYEE_NO', 'PROGRAM_YEAR_START','PROGRAM_YEAR_END'])

df5 = conformity_datetime(df5,'PROGRAM_YEAR_START')
df5 = conformity_datetime(df5,'PROGRAM_YEAR_END')
df5 = accuracy_date(df5, 'PROGRAM_YEAR_START')
df5 = accuracy_date(df5, 'PROGRAM_YEAR_END')

#WATERFALL
df6 = completeness_check(df6, "POLICY_YEAR")
df6 = conformity_datetime(df6,'FIRST_IOS_DATE')
df6 = conformity_datetime(df6,'FIRST_ANDROID_DATE')
df6 = conformity_check_value_integer(df6, 'POLICY_YEAR')
df6 = accuarcy_between(df6, 'POLICY_YEAR', 1,10)
df6 = accuracy_date(df6, 'FIRST_IOS_DATE')
df6 = accuracy_date(df6, 'FIRST_ANDROID_DATE')

# COMMAND ----------

config['asset_name'] = 'attributes'
s1 = get_summary(df1)
config['asset_name'] = 'event_lookup'
s2 = get_summary(df2)
config['asset_name'] = 'eventstatus'
s3 = get_summary(df3)
config['asset_name'] = 'mall'
s4 = get_summary(df4)
config['asset_name'] = 'memberdetails'
s5 = get_summary(df5)
config['asset_name'] = 'waterfall'
s6 = get_summary(df6)
summary = s1.union(s2).union(s3).union(s4).union(s5).union(s6)
uc_write(summary)