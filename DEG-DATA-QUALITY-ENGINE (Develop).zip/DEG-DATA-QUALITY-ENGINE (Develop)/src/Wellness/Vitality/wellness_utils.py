# Databricks notebook source
# MAGIC %run ../../utils

# COMMAND ----------

config['work_stream'] = 'wellness'
config['data_system'] = 'vitality'
config['data_owner'] = 'Lindsay Hanson'
config['business_unit'] = 'Life (US)'
config['data_domain'] = 'wellness'
config['rule_owner'] = 'Halen Ganley'
config['asset_name'] = ''

# COMMAND ----------

config = {
"container": 'gold',
"parent_dir": 'vitality/parquet/dbo/',
"asset_name": '',
"work_stream": "Wellness",
"data_system": "Vitality"
}

events_config = {
"container": 'gold',
"parent_dir": 'vitality/parquet/dbo/',
"asset_name": 'EVENTS',
"work_stream": "Wellness",
"data_system": "Vitality"
}

# COMMAND ----------

def value_counts(column):
    value_counts_df = df.groupBy(column).count().orderBy(f.col("Count").desc())
    display(value_counts_df)
    return value_counts_df

def uc_read(asset):
    df = spark.sql(f"SELECT * FROM usdo_prod_catalog.silver_vitality.{asset}")
    config['parent_dir'] = f"usdo_prod_catalog.silver_vitality.{asset}" 
    config['asset_name'] = asset
    return df

# COMMAND ----------

threshold_scores = {
    #EVENT_LOOKUP
    'EVENT_ID': [
        {'Rule':'Must Contain Non Null Value', 'Threshold': 1},
        {'Rule':'Must Contain 3-4 Digit Number', 'Threshold': 1},
        {'Rule':'EVENT_ID Must Exist in DEF_CATEGORY_ID', 'Threshold': 1}
    ],
    #ATTRIBUTES
    'ATTRIBUTE_VALUE_BMI': [
        {'Rule':'Must Contain Non Null Value', 'Threshold': 0.99},
        {'Rule':'Must Contain Numeric Value', 'Threshold': 0.99},
        {'Rule':'BMI Must Be Between 0 And 60', 'Threshold': 0.99}
    ],
    #EVENTSTATUS
    'All Columns Included': [
        {'Rule':'Must Contain Unique Row', 'Threshold': 1},
    ],
    #MALL
    'TOTAL_COST': [
        {'Rule':'Must Contain Non Null Value', 'Threshold': 0.90},
        {'Rule':'Must Contain Numeric Value', 'Threshold': 0.90},
        # {'Rule':'Total Cost Must Equal retail_price*(1-(discount/100))', 'Threshold': 0.90},
        {'Rule':'Total Cost Must Equal retail_price*(1-(discount/100))', 'Threshold': 0.50},
    ],'JH_DISCOUNT_PERCENTAGE': [
        {'Rule':'Must Contain Non Null Value', 'Threshold': 0.90},
        {'Rule':'Must Contain Numeric Value', 'Threshold': 0.90},
    ],'JH_RETAIL_PRICE': [
        {'Rule':'Must Contain Non Null Value', 'Threshold': 0.90},
        {'Rule':'Must Contain Numeric Value', 'Threshold': 0.90},
    ],
    #MEMBERDETAILS
    # 'PROGRAM_YEAR_START': [
    #     {'Rule':'Must Contain Non Null Value', 'Threshold': 0.75},
    #     {'Rule':'Must Adhere to Expected Format YYYY-MM-DD', 'Threshold': 0.75},
    #     {'Rule':'Must Be Before Today Or Be A System Default Value', 'Threshold': 0.75},
    # ],'PROGRAM_YEAR_END': [
    #     {'Rule':'Must Contain Non Null Value', 'Threshold': 0.75},
    #     {'Rule':'Must Adhere to Expected Format YYYY-MM-DD', 'Threshold': 0.75},
    #     {'Rule':'Must Be Before Today Or Be A System Default Value', 'Threshold': 0.75},
    # ],'EMPLOYEE_NO, PROGRAM_YEAR_START, PROGRAM_YEAR_END': [
    #     {'Rule':'Must Contain Unique Row', 'Threshold': 0.75},
    # ],
    #WATERFALL
    'FIRST_ANDROID_DATE': [
        {'Rule':'Must Contain Non Null Value', 'Threshold': 0.99},
        {'Rule':'Must Adhere To Expected Format YYYY-MM-DD', 'Threshold': 0.99},
        {'Rule':'Must Not Contain Future Date', 'Threshold': 0.99},
    ],'FIRST_IOS_DATE': [
        {'Rule':'Must Contain Non Null Value', 'Threshold': 0.99},
        {'Rule':'Must Adhere To Expected Format YYYY-MM-DD', 'Threshold': 0.99},
        {'Rule':'Must Not Contain Future Date', 'Threshold': 0.99},
    ],'FIRST_ANDROID_DATE, FIRST_IOS_DATE': [
        {'Rule':'Must Contain Non Null Values for First IOS Date or First Android Date when FIRST_APP_LOGIN_DATE is Not Null', 'Threshold': 0.99},
    ],'POLICY_YEAR': [
        {'Rule':'Must Contain Non Null Value', 'Threshold': 0.99},
        {'Rule':'Must Contain Single Digit Value', 'Threshold': 0.99},
        {'Rule':'Must Contain Number Between 1-10', 'Threshold': 0.99},
    ],}

# COMMAND ----------

def clean(df, columns=None):
    if columns == None: columns = df.columns
    for column in columns:
        df = df.withColumn(column, f.ltrim(f.rtrim(df[column])))
        df = df.withColumn(column, f.when(f.col(column) == '\0', None)
            .when(f.col(column) == '', None)
            .otherwise(f.col(column)))
    return df

# COMMAND ----------

@f.udf
def check_mall_total_cost(total_cost, discount, retail_price):
    try:
        if retail_price * (1-(discount/100)) == total_cost:
            return 'pass: Total Cost Must Equal retail_price*(1-(discount/100))'
        return 'fail: Total Cost Must Equal retail_price*(1-(discount/100))'
    except: 
        return 'fail: Total Cost Must Equal retail_price*(1-(discount/100))'

# COMMAND ----------

#EVENTSTATUS
def check_row_uniqueness(df, key_columns):
    if len(key_columns) == len(df.columns): columns_names = 'All Columns Included'
    else: columns_names = ', '.join(key_columns)
    concat_col = f.concat_ws("_", *key_columns)
    df = df.withColumn('row_key', concat_col)
    distinct_df = df.select("row_key").distinct()
    df = df.join(distinct_df, 'row_key', "left_outer")
    df= df.withColumn(f"Uniqueness: " + columns_names, f.when(f.col("row_key").isNotNull(), 'pass: Must Contain Unique Row').otherwise('fail: Must Contain Unique Row'))
    df = df.drop('row_key')
    return df