# Databricks notebook source
# MAGIC %run ../../utils

# COMMAND ----------

# MAGIC %run ./wellness_utils

# COMMAND ----------

configure_spark()
config['asset_name'] = 'MEMBERDETAILS'
df = read_asset(**config)
df = clean(df)
df = df.filter(df['sys_eff_to'] == '9999-12-31')

# COMMAND ----------

#COMPLETENESS
df = completeness_check(df, 'PROGRAM_YEAR_START')
df = completeness_check(df, 'PROGRAM_YEAR_END')

#UNIQUENESS
df = uniqueness_check(df,['EMPLOYEE_NO', 'PROGRAM_YEAR_START','PROGRAM_YEAR_END'])

#CONFORMITY
df = df.withColumn('Conformity: PROGRAM_YEAR_START', f.when(df['PROGRAM_YEAR_START'].rlike(r'\d{4}-\d{2}-\d{2}'),'pass: Must Adhere to Expected Format YYYY-MM-DD').when(df['PROGRAM_YEAR_START'].isNull(), 'pass: Must Adhere to Expected Format YYYY-MM-DD').otherwise('fail: Must Adhere to Expected Format YYYY-MM-DD'))

df = df.withColumn('Conformity: PROGRAM_YEAR_END', f.when(df['PROGRAM_YEAR_END'].rlike(r'\d{4}-\d{2}-\d{2}'),'pass: Must Adhere to Expected Format YYYY-MM-DD').when(df['PROGRAM_YEAR_END'].isNull(), 'pass: Must Adhere to Expected Format YYYY-MM-DD').otherwise('fail: Must Adhere to Expected Format YYYY-MM-DD'))

#ACCURACY
df = df.withColumn('Accuracy: PROGRAM_YEAR_START', f.when(df['PROGRAM_YEAR_START'] <= TIMESTAMP[:10], 'pass: Must Be Before Today Or Be A System Default Value').when(df['PROGRAM_YEAR_START'] > TIMESTAMP[:10], 'fail: Must Be Before Today Or Be A System Default Value').otherwise('fail: Must Be Before Today Or Be A System Default Value'))

df = df.withColumn('Accuracy: PROGRAM_YEAR_END', f.when(df['PROGRAM_YEAR_END'] <= TIMESTAMP[:10], 'pass: Must Be Before Today Or Be A System Default Value').when(df['PROGRAM_YEAR_END'] > TIMESTAMP[:10], 'fail: Must Be Before Today Or Be A System Default Value').otherwise('fail: Must Be Before Today Or Be A System Default Value'))

# COMMAND ----------

summary_df = get_summary(df, threshold_scores, **config)
failed_rows_df = get_failed_rows(df)
save_parquet_results(failed_rows_df, summary_df, **config)
