# Databricks notebook source
# MAGIC %run ../../utils

# COMMAND ----------

# MAGIC %run ../../rules

# COMMAND ----------

# MAGIC %sql
# MAGIC select distinct cntry from usdo_prod_catalog.silver_isam.ru_user_profile

# COMMAND ----------


df = uc_read('silver_isam', 'ru_user_profile')
df = df.orderBy('isam_uid')
display(df)

# COMMAND ----------

#COMPLETENESS
completeness_check_columns = ['ADDR_LINE_1', 'City', 'STATE', 'ZIP']
for column in df.columns:
    df = completeness_check(df, column)


# COMMAND ----------

config['asset_name'] = 'ru_user_profile'
summary = get_summary(df)
display(summary)
#uc_write(summary)
