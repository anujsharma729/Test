# Databricks notebook source
# DBTITLE 1,Run utils
# MAGIC %run ../utils

# COMMAND ----------

# DBTITLE 1,Run rules
# MAGIC %run ../rules

# COMMAND ----------

# DBTITLE 1,Run end-matter
# MAGIC %run ./end-matter

# COMMAND ----------

# DBTITLE 1,Main
config['asset_name']    = 'reg_user_reg_info'
config['data_system']   = 'ciam'
config['data_owner']    = 'Teresa Hayes, Amy Miskavitch, Charles Wiegersma'
config['business_unit'] = 'Cross Business Unit'
config['data_domain']   = 'Central Registration'
config['rule_owner']    = 'Prashanth Krotha'
config['work_stream']   = 'data consolidation'

df = uc_read('silver_isam', 'reg_user_reg_info')

US_STATES_FULL = [
    'Alabama', 'Alaska', 'Arizona', 'Arkansas', 'California', 'Colorado', 'Connecticut', 'Delaware',
    'Florida', 'Georgia', 'Hawaii', 'Idaho', 'Illinois', 'Indiana', 'Iowa', 'Kansas', 'Kentucky',
    'Louisiana', 'Maine', 'Maryland', 'Massachusetts', 'Michigan', 'Minnesota', 'Mississippi',
    'Missouri', 'Montana', 'Nebraska', 'Nevada', 'New Hampshire', 'New Jersey', 'New Mexico',
    'New York', 'North Carolina', 'North Dakota', 'Ohio', 'Oklahoma', 'Oregon', 'Pennsylvania',
    'Rhode Island', 'South Carolina', 'South Dakota', 'Tennessee', 'Texas', 'Utah', 'Vermont',
    'Virginia', 'Washington', 'West Virginia', 'Wisconsin', 'Wyoming',
    'American Samoa', 'District of Columbia', 'Guam', 'Northern Mariana Islands', 'Puerto Rico',
    'Virgin Islands', 'Foreign', 'Foreign Address'
]


def conformity_state(df, column):
    df = df.withColumn(f'Conformity: {column}', f.when(df[column].isin(US_STATES), 'pass: must contain US state code or Canadian province')
        .when(df[column].isin(CAN_PROVINCES), 'pass: must contain US state code or Canadian province')
        .when(df[column].isin(US_STATES_FULL), 'pass: must contain US state code or Canadian province')
        .when(df[column].rlike(r'\d'), 'fail: must contain US state code or Canadian province')
        .when(df[column].isNull(), 'pass: must contain US state code or Canadian province')
        .otherwise('fail: must contain US state code or Canadian province'))
    return df


def conformity_postalcode_us(df, column):
    df = df.withColumn(f'Conformity: {column}',
        f.when(f.col(column).rlike(r'^\d{5}$'), 'pass: must adhere to US postal code format')
        .when(f.col(column).rlike(r'^\d{9}$'), 'pass: must adhere to US postal code format')
        .when(f.col(column).rlike(r'^\d{5}-\d{4}$'), 'pass: must adhere to US postal code format')
        .when(df[column].isNull(), 'pass: must adhere to US postal code format')
        .when(df['STATE'] == 'Foreign', 'pass: must adhere to US postal code format')
        .when(df['STATE'] == 'Foreign Address', 'pass: must adhere to US postal code format')
        .otherwise('fail: must adhere to US postal code format'))
    return df

df = completeness_check(df, 'CREATED_BY_USRID', [''])
df = completeness_check(df, 'CREATED_DT', [''])
df = completeness_check(df, 'LAST_UPD_BY_USRID', [''])
df = completeness_check(df, 'LAST_UPD_DT', [''])

df = df.withColumn('Accuracy: CREATED_DT', f.when((df['CREATED_DT'] <= df['LAST_UPD_DT']) | (df['CREATED_DT'].isNull()) | (df['LAST_UPD_DT'].isNull()), 'pass: must be less than or equal to LAST_UPD_DT').otherwise('fail: must be less than or equal to LAST_UPD_DT'))

df = df.withColumn('Accuracy: LAST_UPD_DT', f.when((df['LAST_UPD_DT'] >= df['CREATED_DT']) | (df['LAST_UPD_DT'].isNull()) | (df['CREATED_DT'].isNull()), 'pass: must be greater than or equal to CREATED_DT').otherwise('fail: must be greater than or equal to CREATED_DT'))

df = referential_integrity_check(df, 'reg_role_sid', 'silver_isam', 'reg_role', 'reg_role_sid')
df = referential_integrity_check(df, 'reg_entry_point_sid', 'silver_isam', 'reg_entry_point', 'reg_entry_point_sid')


df = conformity_addr1(df, 'ADDR_LN1')
df = conformity_addr2(df, 'ADDR_LN2')
df = conformity_city(df, 'CITY')
df = conformity_state(df, 'STATE')
df = conformity_postalcode_us(df, 'ZIP')
df = conformity_email(df, 'EMAIL')
df = conformity_phone(df, 'DAYTIME_PH_NUM')

summary = finish(df)
display(summary)