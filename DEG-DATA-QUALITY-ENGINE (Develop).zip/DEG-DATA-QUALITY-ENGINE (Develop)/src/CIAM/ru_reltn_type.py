# Databricks notebook source
# DBTITLE 1,Run utils
# MAGIC %run ../utils

# COMMAND ----------

# DBTITLE 1,Run rules
# MAGIC %run ../rules

# COMMAND ----------

# DBTITLE 1,Run end-matter
# MAGIC %run ./end-matter

# COMMAND ----------

# DBTITLE 1,Main
config['asset_name']    = 'ru_reltn_type'
config['data_system']   = 'ciam'
config['data_owner']    = 'Teresa Hayes, Amy Miskavitch, Charles Wiegersma'
config['business_unit'] = 'Cross Business Unit'
config['data_domain']   = 'Central Registration'
config['rule_owner']    = 'Prashanth Krotha'
config['work_stream']   = 'data consolidation'

df = uc_read('silver_isam', 'ru_reltn_type')

df = completeness_check(df, 'CREATED_BY_USRID', [''])
df = completeness_check(df, 'CREATED_DT', [''])
df = completeness_check(df, 'LAST_UPD_BY_USRID', [''])
df = completeness_check(df, 'LAST_UPD_DT', [''])

df = df.withColumn('Accuracy: CREATED_DT', f.when((df['CREATED_DT'] <= df['LAST_UPD_DT']) | (df['CREATED_DT'].isNull()) | (df['LAST_UPD_DT'].isNull()), 'pass: must be less than or equal to LAST_UPD_DT').otherwise('fail: must be less than or equal to LAST_UPD_DT'))

df = df.withColumn('Accuracy: LAST_UPD_DT', f.when((df['LAST_UPD_DT'] >= df['CREATED_DT']) | (df['LAST_UPD_DT'].isNull()) | (df['CREATED_DT'].isNull()), 'pass: must be greater than or equal to CREATED_DT').otherwise('fail: must be greater than or equal to CREATED_DT'))

df = uniqueness_check(df, 'RELTN_TYPE')
df = completeness_check(df, 'RELTN_TYPE', [''])

summary = finish(df)
display(summary)