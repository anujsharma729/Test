# Databricks notebook source
# MAGIC %run ../utils

# COMMAND ----------

def finish(df):
    summary = get_summary(df)

    summary = summary.withColumn("threshold", f.coalesce(f.col("threshold"), f.lit(1.0)))

    target_table = f"{ENV['catalog']}.data_quality.dq_summary"

    summary.createOrReplaceTempView("dq_summary_updates")

    spark.sql(f"""
        MERGE INTO {target_table} AS target
        USING dq_summary_updates AS source
        ON target.scan_date          = source.scan_date
        AND target.asset_name        = source.asset_name
        AND target.column_name       = source.column_name
        AND target.dimension         = source.dimension
        AND target.data_quality_rule = source.data_quality_rule
        AND target.source_system     = source.source_system
        AND target.workstream        = source.workstream
        WHEN MATCHED THEN UPDATE SET *
        WHEN NOT MATCHED THEN INSERT *
    """)

    print('Wrote the following to dq_summary')

    return summary