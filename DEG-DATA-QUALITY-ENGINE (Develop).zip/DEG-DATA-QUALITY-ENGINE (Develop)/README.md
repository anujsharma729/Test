# DEG-DATA-QUALITY-ENGINE

This repository contains a collection of data pipelines used to monitor data quality in the USDO enterprise data lake (EDL).  It is owned and managed by the US/John Hancock Data Enablement & Governance (DEG) team.  

## 🗂️ Repository Structure

**Core Code**
These files contain common constants and functions used throughout dq pipelines.  
```
src/
├── rules.ipynb
└── utils.py
```

**Specialized Components**
These folders contain code related to components of DQ monitoring outside of the standard pipelines or common code.  
```
src/
├── Power BI/
└── Primary Keys Data Quality Scanner/
```

****Workstream Folders**
These folders contain the notebooks which define individual dq pipelines.  
```
src/
├── Distributor/
├── Producer/
├── LTC_AntiFraud/
└── etc...
```

## 🧩 Pipeline Structure  


Pipelines are generally organized by table (1 notebook per target table).  Each pipeline reads the target into a dataframe, assesses the relevant rules against the data, calculates the scores, and saves the scores to a common output table: `usdo_(env)_catalog.data_quality.dq_summary`.  

> In some cases, the target table(s) must be filtered, joined, or otherwise transformed before the ruleset can be applied.  

## ✅ DQ Rule Assessment

Each dq rule is added to the dataframe as an additional column containing string starting with either 'pass' or 'fail', indicating each row's status relative to the rule. 

Once all rules have been assesed, the pipeline will call the `get_summary()` function, which aggregates the results into a dataframe of dq scores.  It then inserts that dataframe into the dq_summary table in the data lake.  The table `usdo_prod_catalog.data_quality.dq_summary` serves as the official record of active rules and their scores, which feeds our Power BI DQ Dashboards. 

## 🚀 Deployment & Running

The main branch of this repo is copied via our deploy pipeline (Jenkins) to the /Workspace/releases/ in the Databricks instance `ihub-cars-adb-prod`.  
Jobs are created in that instance and scheduled to run all production dq pipelines as needed (every wednesday for most pipelines, end-of-month for primary keys pipelines).  

---
