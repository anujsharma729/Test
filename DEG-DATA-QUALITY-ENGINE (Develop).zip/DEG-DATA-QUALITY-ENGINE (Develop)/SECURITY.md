# Security Policy
## Vulernability scanning
This repo is being monitored by Snyk on a daily basis.

## Reporting a vulnerability
To report a vulnerability on this repo, send an email to DEG_USDATAOFFICE@jhancock.com.

## Documentation
This security policy was created in accordance with the DevSecOps instructions detailed here: https://manulife-ets.atlassian.net/wiki/spaces/EC/pages/13098483967/GitHub+-+Repo+Security+Policy
