import json
import os
import sys

def pytest_sessionstart(session):
    proj_root = os.path.normpath(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    with open('parameters.json') as f:
        params = json.load(f)
    package_root = os.path.join(proj_root, params['src'])
    os.chdir(package_root)
    # add module locations needed for testing
    sys.path.append(package_root) # This is your Package Root
    sys.path.append(os.path.join(proj_root, 'tests'))
