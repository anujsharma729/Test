from pyspark.context import SparkContext
from pyspark.sql import SparkSession
from pyspark_test import assert_pyspark_df_equal
from src import utils

sc = SparkContext('local')
spark = SparkSession(sc)

def test_completeness_check():
    test_data = [{'first_name': 'Jo', 'last_name': 'Ca'},
                 {'first_name': 'Ma', 'last_name': 'Kr'},
                 {'first_name': None, 'last_name': None},
                 {'first_name': 'Bo', 'last_name': 'Og'},
                 {'first_name': 'Jo', 'last_name': 'Li'},
                 {'first_name': None, 'last_name': None}]
    test_df = spark.createDataFrame(test_data)
    expected_data = [{'first_name': 'Jo', 'last_name': 'Ca', 'Completeness: first_name': 'pass: Must Contain Non Null Value'},
                     {'first_name': 'Ma', 'last_name': 'Kr', 'Completeness: first_name': 'pass: Must Contain Non Null Value'},
                     {'first_name': None, 'last_name': None, 'Completeness: first_name': 'fail: Must Contain Non Null Value'},
                     {'first_name': 'Bo', 'last_name': 'Og', 'Completeness: first_name': 'pass: Must Contain Non Null Value'},
                     {'first_name': 'Jo', 'last_name': 'Li', 'Completeness: first_name': 'pass: Must Contain Non Null Value'},
                     {'first_name': None, 'last_name': None, 'Completeness: first_name': 'fail: Must Contain Non Null Value'}]
    expected_df = spark.createDataFrame(expected_data)
    result_df = utils.completeness_check(test_df,'first_name')
    assert_pyspark_df_equal(result_df, expected_df)


def test_uniqueness_check():
    test_data = [{'first_name': 'Jo', 'last_name': 'Ca'},
                 {'first_name': 'Ma', 'last_name': 'Kr'},
                 {'first_name': None, 'last_name': None},
                 {'first_name': 'Bo', 'last_name': 'Og'},
                 {'first_name': 'Jo', 'last_name': 'Li'},
                 {'first_name': None, 'last_name': None}]
    test_df = spark.createDataFrame(test_data)
    expected_data = [{'first_name': 'Jo', 'last_name': 'Ca', 'Uniqueness: first_name': 'fail: Must Contain Unique Value'},
                     {'first_name': 'Ma', 'last_name': 'Kr', 'Uniqueness: first_name': 'pass: Must Contain Unique Value'},
                     {'first_name': None, 'last_name': None, 'Uniqueness: first_name': 'fail: Must Contain Unique Value'},
                     {'first_name': 'Bo', 'last_name': 'Og', 'Uniqueness: first_name': 'pass: Must Contain Unique Value'},
                     {'first_name': 'Jo', 'last_name': 'Li', 'Uniqueness: first_name': 'fail: Must Contain Unique Value'},
                     {'first_name': None, 'last_name': None, 'Uniqueness: first_name': 'fail: Must Contain Unique Value'}]
    expected_df = spark.createDataFrame(expected_data)
    result_df = utils.uniqueness_check(test_df,'first_name')
    result_df = result_df.sort('first_name','last_name', ascending=[True, True]) 
    expected_df = expected_df.sort('first_name','last_name', ascending=[True, True])
    assert_pyspark_df_equal(result_df, expected_df)


def test_get_failed_rows():
    test_data = [{'first_name': 'Jo', 'last_name': 'Ca', 'Uniqueness: first_name': 'fail'},
                 {'first_name': 'Ma', 'last_name': 'Kr', 'Uniqueness: first_name': 'pass'},
                 {'first_name': None, 'last_name': None, 'Uniqueness: first_name': 'fail'},
                 {'first_name': 'Bo', 'last_name': 'Og', 'Uniqueness: first_name': 'pass'},
                 {'first_name': 'Jo', 'last_name': 'Li', 'Uniqueness: first_name': 'fail'},
                 {'first_name': None, 'last_name': None, 'Uniqueness: first_name': 'fail'}]
    test_df = spark.createDataFrame(test_data)
    expected_data = [{'first_name': 'Jo', 'last_name': 'Ca', 'Uniqueness: first_name': 'fail'},
                     {'first_name': None, 'last_name': None, 'Uniqueness: first_name': 'fail'},
                     {'first_name': 'Jo', 'last_name': 'Li', 'Uniqueness: first_name': 'fail'},
                     {'first_name': None, 'last_name': None, 'Uniqueness: first_name': 'fail'}]
    expected_df = spark.createDataFrame(expected_data)
    result_df = utils.get_failed_rows(test_df)
    result_df = result_df.sort('first_name','last_name', ascending=[True, True]) 
    expected_df = expected_df.sort('first_name','last_name', ascending=[True, True])
    assert_pyspark_df_equal(result_df, expected_df)


def test_consistency_check():
    # Create a mock dataframe
    data = [("John", "Doe", "John"), ("Jane", "Doe", "Jane"), ("John", "Smith", "Smith")]
    df = spark.createDataFrame(data, ["FirstName", "LastName", "CheckName"])

    # Set parameters
    ref_table_name = "ref_table"
    primary_key = "FirstName"
    foreign_key = "LastName"
    check_col1 = "FirstName"
    check_col2 = "CheckName"

    # Call the function
    result_df = utils.consistency_check(df, ref_table_name, primary_key, foreign_key, check_col1, check_col2)

    # Check if the output dataframe has the expected columns
    expected_columns = df.columns + [f'Consistency: {check_col1} must equal {ref_table_name}[{check_col2}] on {primary_key} = {ref_table_name}[{foreign_key}]']
    assert result_df.columns == expected_columns

    # Check if the output dataframe has the expected values
    expected_values = [("John", "Doe", "pass"), ("Jane", "Doe", "pass"), ("John", "Smith", "fail: [John] != [Smith]")]
    assert result_df.select("FirstName", "LastName", f'Consistency: {check_col1} must equal {ref_table_name}[{check_col2}] on {primary_key} = {ref_table_name}[{foreign_key}]').collect() == expected_values