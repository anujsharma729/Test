pipelinePythonContinuousIntegrationDocker(  
    [  
        propertiesFileName:'prod-ci.properties',
        jenkinsJobTimeOutInMinutes: 60
    ]
)
