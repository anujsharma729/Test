pipelinePythonContinuousIntegrationDocker(  
    [  
        propertiesFileName:'dev-ci.properties',
        jenkinsJobTimeOutInMinutes: 60
    ]
)
