pipelineDeployToDataBricksDocker(
  [
    propertiesFileName:'databricks-prod-deploy.properties',
    jenkinsJobTimeOutInMinutes: 60,
  ]
)
