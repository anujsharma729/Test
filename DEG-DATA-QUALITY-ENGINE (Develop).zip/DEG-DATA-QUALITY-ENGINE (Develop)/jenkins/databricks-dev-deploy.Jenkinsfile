pipelineDeployToDataBricksDocker(
  [
    propertiesFileName:'databricks-dev-deploy.properties',
    jenkinsJobTimeOutInMinutes: 60,
  ]
)
